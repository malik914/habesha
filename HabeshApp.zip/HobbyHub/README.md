# Habesha — React Native Social App

A cross-platform (iOS + Android) interest-based community app built with React Native + Firebase.

## Tech Stack
- **Frontend**: React Native (Expo)
- **Backend**: Firebase (Auth, Firestore, FCM)
- **Navigation**: React Navigation v6
- **State**: React Context + useReducer
- **Styling**: StyleSheet + custom design system

## Project Structure
```
Habesha/
├── src/
│   ├── screens/
│   │   ├── Auth/
│   │   │   ├── WelcomeScreen.jsx
│   │   │   ├── LoginScreen.jsx
│   │   │   └── RegisterScreen.jsx
│   │   ├── Main/
│   │   │   ├── FeedScreen.jsx
│   │   │   ├── MessagesScreen.jsx
│   │   │   ├── NotificationsScreen.jsx
│   │   │   └── ProfileScreen.jsx
│   │   └── Groups/
│   │       ├── GroupsDiscoverScreen.jsx
│   │       └── GroupDetailScreen.jsx
│   ├── components/
│   │   ├── PostCard.jsx
│   │   ├── UserAvatar.jsx
│   │   ├── MessageBubble.jsx
│   │   └── NotificationItem.jsx
│   ├── navigation/
│   │   ├── AppNavigator.jsx
│   │   └── TabNavigator.jsx
│   ├── firebase/
│   │   ├── config.js
│   │   ├── auth.js
│   │   ├── firestore.js
│   │   └── messaging.js
│   ├── context/
│   │   ├── AuthContext.jsx
│   │   └── AppContext.jsx
│   └── theme/
│       └── index.js
├── app.json
├── package.json
└── App.jsx
```

## Getting Started

### 1. Install dependencies
```bash
npx create-expo-app Habesha --template blank
cd Habesha
npm install @react-navigation/native @react-navigation/bottom-tabs @react-navigation/stack
npm install react-native-screens react-native-safe-area-context
npm install firebase
npm install @react-native-firebase/app @react-native-firebase/auth
npm install @react-native-firebase/firestore @react-native-firebase/messaging
npm install react-native-vector-icons
npm install expo-image-picker expo-notifications
```

### 2. Firebase Setup
1. Go to https://console.firebase.google.com
2. Create a new project called "Habesha"
3. Enable: Authentication (Email/Google), Firestore, Cloud Messaging
4. Download `google-services.json` (Android) and `GoogleService-Info.plist` (iOS)
5. Add credentials to `src/firebase/config.js`

### 3. Run the app
```bash
npx expo start
```

## Firestore Data Model

### Users Collection
```
users/{userId}
  - uid: string
  - displayName: string
  - email: string
  - photoURL: string
  - bio: string
  - interests: string[]
  - joinedGroups: string[]
  - createdAt: timestamp
```

### Groups Collection
```
groups/{groupId}
  - name: string
  - description: string
  - topic: string
  - coverImage: string
  - memberCount: number
  - members: string[]
  - createdBy: string
  - createdAt: timestamp
```

### Posts Collection
```
posts/{postId}
  - authorId: string
  - groupId: string
  - content: string
  - imageUrl?: string
  - likes: string[]
  - commentCount: number
  - createdAt: timestamp
```

### Messages Collection
```
conversations/{convId}
  - participants: string[]
  - lastMessage: string
  - lastMessageAt: timestamp

conversations/{convId}/messages/{msgId}
  - senderId: string
  - text: string
  - createdAt: timestamp
  - read: boolean
```

### Notifications Collection
```
notifications/{notifId}
  - userId: string
  - type: 'like' | 'comment' | 'follow' | 'message'
  - fromUserId: string
  - postId?: string
  - read: boolean
  - createdAt: timestamp
```

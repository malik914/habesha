# Habesha — App Store Submission Guide
## Google Play ($25 one-time) + Apple App Store ($99/year)

---

## 📋 Pre-submission Checklist

### App must be complete:
- [ ] All screens work without crashes
- [ ] No placeholder "Lorem ipsum" text
- [ ] App icon designed (1024x1024px)
- [ ] Splash screen designed
- [ ] Privacy Policy URL ready (required by both stores)
- [ ] Terms of Service URL ready
- [ ] Support email address ready

---

## 🏗️ Step 1 — Build with Expo EAS (Free)

### Install EAS CLI
```bash
npm install -g eas-cli
eas login
```

### Configure your project
```bash
eas build:configure
```

This creates `eas.json`. Use this config:

```json
{
  "cli": { "version": ">= 5.0.0" },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" }
    },
    "production": {
      "android": { "buildType": "aab" },
      "ios": { "resourceClass": "m-medium" }
    }
  },
  "submit": {
    "production": {}
  }
}
```

### Update app.json
```json
{
  "expo": {
    "name": "Habesha",
    "slug": "habesha",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#F8F6F2"
    },
    "ios": {
      "bundleIdentifier": "com.yourname.habesha",
      "buildNumber": "1",
      "supportsTablet": false,
      "infoPlist": {
        "NSCameraUsageDescription": "Used to take photos for your profile and posts",
        "NSPhotoLibraryUsageDescription": "Used to upload photos to your profile and posts",
        "NSMicrophoneUsageDescription": "Used for video recording"
      }
    },
    "android": {
      "package": "com.yourname.habesha",
      "versionCode": 1,
      "permissions": [
        "CAMERA",
        "READ_EXTERNAL_STORAGE",
        "WRITE_EXTERNAL_STORAGE",
        "NOTIFICATIONS"
      ]
    }
  }
}
```

### Build for production
```bash
# Android (AAB for Play Store)
eas build --platform android --profile production

# iOS (IPA for App Store)
eas build --platform ios --profile production

# Both at once
eas build --platform all --profile production
```

**Free EAS tier: 30 builds/month — more than enough.**

---

## 🤖 Step 2 — Google Play Store

### 2.1 Create Developer Account
1. Go to https://play.google.com/console
2. Pay **$25 one-time** fee
3. Complete identity verification (1–2 days)

### 2.2 Create your app
1. Click **"Create app"**
2. App name: `Habesha`
3. Default language: English
4. App or Game: **App**
5. Free or paid: **Free** (change later)

### 2.3 Store listing
Fill in these required fields:

| Field | Value |
|-------|-------|
| Short description | Connect with people who share your hobbies |
| Full description | See template below |
| App icon | 512x512 PNG |
| Feature graphic | 1024x500 PNG |
| Screenshots | 2–8 screenshots per device type |
| Category | Social |
| Tags | social, community, hobbies, interests |
| Email | your-support@email.com |
| Privacy Policy URL | https://yoursite.com/privacy |

**Full description template:**
```
Habesha — Find Your People

Connect with thousands of people who share your exact interests. Whether you're into photography, gaming, cooking, fitness, or anything else — there's a community waiting for you.

✨ Features:
• Personalized feed based on your interests
• Create and join interest-based groups
• Stories that disappear after 24 hours
• Short video Reels
• React to posts with emoji reactions
• Save posts to read later
• Real-time direct messaging
• Follow friends and discover new people
• Push notifications

Join Habesha today and find your people.
```

### 2.4 App content
- **Privacy Policy**: Required — create one at https://privacypolicygenerator.info
- **Target audience**: 13+ (or 18+ if you want)
- **Ads**: No ads
- **Content rating**: Complete the questionnaire (takes 5 min)

### 2.5 Upload and publish
1. Go to **Release → Production → Create new release**
2. Upload your `.aab` file from EAS build
3. Write release notes: `Initial release of Habesha`
4. Click **Review release** then **Start rollout to production**
5. ⏳ Review takes **1–3 business days**

---

## 🍎 Step 3 — Apple App Store

### 3.1 Create Developer Account
1. Go to https://developer.apple.com
2. Pay **$99/year** fee
3. Complete enrollment (can take 24–48 hours)

### 3.2 Create App ID
1. Go to Certificates, Identifiers & Profiles
2. Click **Identifiers → +**
3. Select **App IDs → App**
4. Bundle ID: `com.yourname.habesha`
5. Capabilities: Enable **Push Notifications**

### 3.3 App Store Connect
1. Go to https://appstoreconnect.apple.com
2. Click **My Apps → +**
3. Platform: iOS, Name: Habesha
4. Bundle ID: select what you created

### 3.4 App information

| Field | Value |
|-------|-------|
| Name | Habesha |
| Subtitle | Find your hobby community |
| Category | Social Networking |
| Age Rating | 12+ |
| Privacy Policy URL | https://yoursite.com/privacy |
| Support URL | https://yoursite.com/support |

### 3.5 Screenshots required
- **6.7" iPhone** (iPhone 15 Pro Max): 1290 x 2796px — **required**
- **5.5" iPhone** (iPhone 8 Plus): 1242 x 2208px — required
- **iPad Pro 12.9"**: 2048 x 2732px — if supporting iPad

**Take screenshots using Expo + iOS Simulator:**
```bash
# Run on iOS simulator
npx expo start --ios
# Use Cmd+S to screenshot in simulator
```

### 3.6 Submit for review
1. Select your build under **Build** section
2. Fill in **Export Compliance**: No encryption (standard HTTPS only)
3. Answer **Advertising Identifier**: No (unless using ads)
4. Click **Add for Review** → **Submit to App Review**
5. ⏳ Review takes **1–7 business days** (avg 1–2 days now)

### 3.7 Common rejection reasons (avoid these!)
- ❌ Crashes on launch — test thoroughly before submitting
- ❌ Broken login/signup — test the full auth flow
- ❌ Missing privacy policy — must be a real URL
- ❌ Placeholder content — remove all "Lorem ipsum"
- ❌ Asking for permissions not needed — only request camera/photos when used
- ❌ Payments outside IAP — all digital goods must use Apple IAP

---

## 🔒 Step 4 — Deploy Firebase Security Rules

```bash
# Install Firebase CLI
npm install -g firebase-tools
firebase login

# Initialize in your project (if not done)
firebase init firestore
firebase init storage

# Deploy rules
firebase deploy --only firestore:rules
firebase deploy --only storage
firebase deploy --only firestore:rules,storage
```

---

## 📊 Step 5 — Required Legal Pages

### Privacy Policy (required by both stores)
Use https://privacypolicygenerator.info or https://app-privacy-policy-generator.nisrulz.com

Must mention:
- What data you collect (email, name, photos, usage data)
- Firebase/Google as data processor
- How users can delete their account
- Contact email

### Terms of Service
Use https://www.termsofservicegenerator.net

### Host them for free
- GitHub Pages: https://pages.github.com
- Notion page (make public)
- Carrd.co (free tier)

---

## 🚀 Launch Timeline

| Week | Task |
|------|------|
| Week 1 | Polish app, fix all bugs, test on real devices |
| Week 2 | Design assets (icon, screenshots, store graphics) |
| Week 3 | Submit to Google Play, wait for review |
| Week 4 | Submit to App Store, write launch blog/social posts |
| Week 5 | **LIVE ON BOTH STORES** 🎉 |

---

## 💡 Post-Launch Tips

1. **Ask for reviews early** — prompt users to rate after a positive action
2. **Reply to all reviews** — especially negative ones
3. **Monitor crashes** — use Expo's built-in error reporting
4. **Update regularly** — stores favor apps updated frequently
5. **ASO (App Store Optimization)** — use keywords people search for in your title/description

---

## 🆘 Help Resources

- Expo EAS Docs: https://docs.expo.dev/eas/
- Google Play Help: https://support.google.com/googleplay/android-developer
- App Store Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- Firebase Console: https://console.firebase.google.com

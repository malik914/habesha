// functions/index.js
// Habesha — Firebase Cloud Functions
// Deploy: firebase deploy --only functions
//
// Setup:
//   cd functions
//   npm install
//   firebase deploy --only functions

const functions = require('firebase-functions');
const admin     = require('firebase-admin');

admin.initializeApp();

const db      = admin.firestore();
const storage = admin.storage();

// ═══════════════════════════════════════════════════════════════════
// 🔔 PUSH NOTIFICATIONS
// ═══════════════════════════════════════════════════════════════════

// Helper: send Expo push notification
const sendExpoPush = async (token, title, body, data = {}) => {
  if (!token || !token.startsWith('ExponentPushToken')) return;
  try {
    await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: token, title, body, data, sound: 'default', badge: 1 }),
    });
  } catch (e) {
    console.error('Push send error:', e);
  }
};

// Helper: get push token for a user
const getUserToken = async (userId) => {
  const doc = await db.collection('users').doc(userId).get();
  return doc.exists ? doc.data().expoPushToken : null;
};

// ── Trigger: New notification document ───────────────────────────
exports.onNotificationCreated = functions.firestore
  .document('notifications/{notifId}')
  .onCreate(async (snap) => {
    const notif = snap.data();
    if (!notif.userId || !notif.fromUserName) return;

    const token = await getUserToken(notif.userId);
    if (!token) return;

    // Check user notification preferences
    const userDoc = await db.collection('users').doc(notif.userId).get();
    const prefs   = userDoc.data()?.notifPrefs || {};

    const titleMap = {
      like:    `${notif.fromUserName} reacted to your post`,
      comment: `${notif.fromUserName} commented on your post`,
      follow:  `${notif.fromUserName} started following you`,
      message: `${notif.fromUserName} sent you a message`,
      mention: `${notif.fromUserName} mentioned you`,
      group:   'New post in your group',
    };

    const prefKey = notif.type === 'like' ? 'likes'
      : notif.type === 'comment'  ? 'comments'
      : notif.type === 'follow'   ? 'follows'
      : notif.type === 'message'  ? 'messages'
      : 'groupPosts';

    // Respect notification preferences
    if (prefs[prefKey] === false) return;

    const title = titleMap[notif.type] || 'New notification';
    await sendExpoPush(token, 'Habesha', title, {
      type: notif.type,
      postId: notif.postId || null,
      fromUserId: notif.fromUserId || null,
    });
  });

// ── Trigger: New direct message ───────────────────────────────────
exports.onMessageCreated = functions.firestore
  .document('conversations/{convId}/messages/{msgId}')
  .onCreate(async (snap, context) => {
    const msg  = snap.data();
    const conv = await db.collection('conversations').doc(context.params.convId).get();
    if (!conv.exists) return;

    const { participants } = conv.data();
    const recipientId = participants.find((p) => p !== msg.senderId);
    if (!recipientId) return;

    // Check message notification preference
    const userDoc = await db.collection('users').doc(recipientId).get();
    if (userDoc.data()?.notifPrefs?.messages === false) return;

    const senderDoc = await db.collection('users').doc(msg.senderId).get();
    const senderName = senderDoc.data()?.displayName || 'Someone';

    const token = await getUserToken(recipientId);
    if (!token) return;

    await sendExpoPush(token, senderName, msg.text?.slice(0, 100) || 'Sent you a message', {
      type:           'message',
      conversationId: context.params.convId,
      fromUserName:   senderName,
    });
  });

// ═══════════════════════════════════════════════════════════════════
// ✅ VERIFIED BADGE GRANTING (Admin only — cannot be done client-side)
// ═══════════════════════════════════════════════════════════════════

// Callable function: grant verified badge
// Only callable by users with admin: true in their Firestore document
exports.grantVerifiedBadge = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Must be signed in');

  // Check if caller is admin
  const callerDoc = await db.collection('users').doc(context.auth.uid).get();
  if (!callerDoc.data()?.admin) {
    throw new functions.https.HttpsError('permission-denied', 'Admins only');
  }

  const { targetUserId, grant = true } = data;
  if (!targetUserId) throw new functions.https.HttpsError('invalid-argument', 'targetUserId required');

  await db.collection('users').doc(targetUserId).update({ verified: grant });

  return { success: true, userId: targetUserId, verified: grant };
});

// Callable function: grant admin role
exports.grantAdminRole = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Must be signed in');

  const callerDoc = await db.collection('users').doc(context.auth.uid).get();
  if (!callerDoc.data()?.superAdmin) {
    throw new functions.https.HttpsError('permission-denied', 'Super admins only');
  }

  await db.collection('users').doc(data.targetUserId).update({ admin: true });
  return { success: true };
});

// ═══════════════════════════════════════════════════════════════════
// 🧹 CLEANUP FUNCTIONS (Scheduled)
// ═══════════════════════════════════════════════════════════════════

// Run every hour: delete expired stories
exports.cleanupExpiredStories = functions.pubsub
  .schedule('every 1 hours')
  .onRun(async () => {
    const now = admin.firestore.Timestamp.now();
    const expiredStories = await db.collection('stories')
      .where('expiresAt', '<=', now)
      .limit(500)
      .get();

    if (expiredStories.empty) {
      console.log('No expired stories to clean up');
      return;
    }

    const batch = db.batch();
    const storageDeletes = [];

    expiredStories.docs.forEach((doc) => {
      const story = doc.data();
      batch.delete(doc.ref);

      // Also delete from Storage
      if (story.mediaUrl) {
        const path = decodeURIComponent(
          story.mediaUrl.split('/o/')[1]?.split('?')[0] || ''
        );
        if (path) {
          storageDeletes.push(
            storage.bucket().file(path).delete().catch(() => {})
          );
        }
      }
    });

    await Promise.all([batch.commit(), ...storageDeletes]);
    console.log(`Deleted ${expiredStories.docs.length} expired stories`);
  });

// Run every day at midnight: clean up old notifications (keep 30 days)
exports.cleanupOldNotifications = functions.pubsub
  .schedule('every 24 hours')
  .onRun(async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(
      Date.now() - 30 * 24 * 60 * 60 * 1000
    );
    const old = await db.collection('notifications')
      .where('createdAt', '<=', cutoff)
      .limit(1000)
      .get();

    if (old.empty) return;
    const batch = db.batch();
    old.docs.forEach((doc) => batch.delete(doc.ref));
    await batch.commit();
    console.log(`Deleted ${old.docs.length} old notifications`);
  });

// Run every day: recalculate trending hashtags score
exports.updateHashtagTrending = functions.pubsub
  .schedule('every 24 hours')
  .onRun(async () => {
    const cutoff = admin.firestore.Timestamp.fromMillis(
      Date.now() - 7 * 24 * 60 * 60 * 1000
    );
    const recentPosts = await db.collection('posts')
      .where('createdAt', '>=', cutoff)
      .get();

    const tagCounts = {};
    recentPosts.docs.forEach((doc) => {
      const hashtags = doc.data().hashtags || [];
      hashtags.forEach((tag) => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });

    const batch = db.batch();
    Object.entries(tagCounts).forEach(([tag, count]) => {
      batch.set(db.collection('hashtags').doc(tag), {
        tag,
        weeklyCount: count,
        lastUpdated: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    });
    await batch.commit();
    console.log(`Updated trending scores for ${Object.keys(tagCounts).length} hashtags`);
  });

// ═══════════════════════════════════════════════════════════════════
// 🚨 MODERATION
// ═══════════════════════════════════════════════════════════════════

// Trigger: new report submitted — auto-flag if 3+ reports
exports.onReportCreated = functions.firestore
  .document('reports/{reportId}')
  .onCreate(async (snap) => {
    const report = snap.data();
    if (!report.targetId || !report.targetType) return;

    // Count reports on this target
    const reports = await db.collection('reports')
      .where('targetId', '==', report.targetId)
      .where('status', '==', 'pending')
      .get();

    const count = reports.size;

    if (count >= 3) {
      // Auto-flag content for review
      if (report.targetType === 'post') {
        await db.collection('posts').doc(report.targetId).update({
          flagged: true,
          flaggedAt: admin.firestore.FieldValue.serverTimestamp(),
          reportCount: count,
        });
      } else if (report.targetType === 'user') {
        await db.collection('users').doc(report.targetId).update({
          flagged: true,
          flaggedAt: admin.firestore.FieldValue.serverTimestamp(),
          reportCount: count,
        });
      }
      console.log(`Auto-flagged ${report.targetType} ${report.targetId} with ${count} reports`);
    }
  });

// Callable: admin review a report
exports.resolveReport = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Must be signed in');

  const callerDoc = await db.collection('users').doc(context.auth.uid).get();
  if (!callerDoc.data()?.admin) {
    throw new functions.https.HttpsError('permission-denied', 'Admins only');
  }

  const { reportId, action, targetId, targetType } = data;
  // action: 'dismiss' | 'remove_content' | 'ban_user'

  await db.collection('reports').doc(reportId).update({
    status:     action === 'dismiss' ? 'dismissed' : 'resolved',
    resolvedAt: admin.firestore.FieldValue.serverTimestamp(),
    resolvedBy: context.auth.uid,
    action,
  });

  if (action === 'remove_content' && targetType === 'post') {
    await db.collection('posts').doc(targetId).delete();
  }

  if (action === 'ban_user') {
    await db.collection('users').doc(targetId).update({ banned: true, bannedAt: admin.firestore.FieldValue.serverTimestamp() });
    await admin.auth().updateUser(targetId, { disabled: true });
  }

  return { success: true };
});

// ═══════════════════════════════════════════════════════════════════
// 📊 ANALYTICS AGGREGATION
// ═══════════════════════════════════════════════════════════════════

// Trigger: when a post is liked/reacted, update author's total engagement
exports.onPostEngagement = functions.firestore
  .document('posts/{postId}')
  .onUpdate(async (change) => {
    const before = change.before.data();
    const after  = change.after.data();

    const beforeLikes = before.likes?.length || 0;
    const afterLikes  = after.likes?.length  || 0;

    if (beforeLikes === afterLikes) return; // no like change

    const diff = afterLikes - beforeLikes;
    if (diff === 0) return;

    // Update author's total likes count
    await db.collection('users').doc(after.authorId).update({
      totalLikesReceived: admin.firestore.FieldValue.increment(diff),
    });
  });

// ── User deletion cleanup ─────────────────────────────────────────
exports.onUserDeleted = functions.auth.user().onDelete(async (user) => {
  const uid = user.uid;
  const batch = db.batch();

  // Delete user document
  batch.delete(db.collection('users').doc(uid));

  // Delete their username
  const usernameSnap = await db.collection('usernames')
    .where('uid', '==', uid).limit(1).get();
  usernameSnap.docs.forEach((d) => batch.delete(d.ref));

  await batch.commit();

  // Delete their storage files
  try {
    await storage.bucket().deleteFiles({ prefix: `avatars/${uid}` });
    await storage.bucket().deleteFiles({ prefix: `posts/${uid}/` });
    await storage.bucket().deleteFiles({ prefix: `stories/${uid}/` });
  } catch (e) {
    console.error('Storage cleanup error:', e);
  }

  console.log(`Cleaned up data for deleted user ${uid}`);
});

// scripts/seed.js
// Habesha — Data Seeding Script
// Run: node scripts/seed.js
//
// Prerequisites:
//   npm install firebase-admin
//   Set GOOGLE_APPLICATION_CREDENTIALS env var to your service account key
//   Download from: Firebase Console → Project Settings → Service Accounts

const admin = require('firebase-admin');

// Initialize with service account
const serviceAccount = require('./service-account-key.json'); // download from Firebase Console
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });

const db = admin.firestore();

// ─── SEED DATA ────────────────────────────────────────────────────

const GROUPS = [
  // Photography
  { name: 'Street Photography Club',     topic: 'photography', description: 'Capturing life in the streets. Share your best urban shots, compositions, and stories behind the lens.', emoji: '📷', privacy: 'public' },
  { name: 'Portrait Masters',            topic: 'photography', description: 'Dedicated to the art of portrait photography. Lighting, posing, and connecting with your subjects.', emoji: '📷', privacy: 'public' },
  { name: 'Nature & Wildlife Shots',     topic: 'photography', description: 'From macro insects to sweeping landscapes. Share your adventures in nature photography.', emoji: '📷', privacy: 'public' },

  // Gaming
  { name: 'Indie Game Dev Corner',       topic: 'gaming', description: 'A community for indie game developers and enthusiasts. Share your projects, get feedback, and find collaborators.', emoji: '🕹️', privacy: 'public' },
  { name: 'Retro Gaming Society',        topic: 'gaming', description: 'Celebrating the golden age of video games. NES, SNES, Genesis, PS1 — if it\'s classic, it belongs here.', emoji: '🕹️', privacy: 'public' },
  { name: 'PC Master Race',             topic: 'gaming', description: 'PC gaming builds, benchmarks, mods, and discussions. Share your setups and help others optimize their rigs.', emoji: '🕹️', privacy: 'public' },

  // Cooking
  { name: 'Home Chefs United',          topic: 'cooking', description: 'Share recipes, cooking tips, and food photos. From weeknight dinners to weekend feasts.', emoji: '🧑‍🍳', privacy: 'public' },
  { name: 'Baking & Pastry Arts',       topic: 'cooking', description: 'Bread, cakes, pastries, and everything in between. Post your creations and swap recipes.', emoji: '🧑‍🍳', privacy: 'public' },
  { name: 'Plant-Based Kitchen',        topic: 'cooking', description: 'Vegan and vegetarian cooking made exciting. Prove that plant-based food can be incredible.', emoji: '🧑‍🍳', privacy: 'public' },

  // Fitness
  { name: 'Morning Run Club',           topic: 'fitness', description: 'Early risers and running enthusiasts. Share your routes, times, and motivation for those 5am runs.', emoji: '🏃', privacy: 'public' },
  { name: 'Home Workout Warriors',      topic: 'fitness', description: 'No gym? No problem. Share effective home workouts, bodyweight routines, and minimal equipment exercises.', emoji: '🏃', privacy: 'public' },
  { name: 'Yoga & Mindfulness',         topic: 'fitness', description: 'Yoga flows, meditation practices, and mindfulness tips. For beginners and experienced practitioners alike.', emoji: '🏃', privacy: 'public' },

  // Music
  { name: 'Bedroom Producers',          topic: 'music', description: 'Making music from home studios. Share your beats, tracks, production tips, and gear recommendations.', emoji: '🎸', privacy: 'public' },
  { name: 'Guitar Circle',             topic: 'music', description: 'Acoustic, electric, classical — all guitars welcome. Tabs, techniques, gear talk, and jam sessions.', emoji: '🎸', privacy: 'public' },
  { name: 'Vinyl Records Collectors',  topic: 'music', description: 'For those who believe music sounds better on vinyl. Show your collection and share rare finds.', emoji: '🎸', privacy: 'public' },

  // Travel
  { name: 'Solo Travelers Network',     topic: 'travel', description: 'Tips, stories, and advice for those who love to explore the world alone. Connect with fellow solo adventurers.', emoji: '🗺️', privacy: 'public' },
  { name: 'Budget Travel Hacks',        topic: 'travel', description: 'See the world without breaking the bank. Share deals, tips, and creative ways to travel more for less.', emoji: '🗺️', privacy: 'public' },
  { name: 'Van Life & Road Trips',      topic: 'travel', description: 'Life on the road, van conversions, campsite reviews, and open highway adventures.', emoji: '🗺️', privacy: 'public' },

  // Art
  { name: 'Digital Art Studio',         topic: 'art', description: 'Digital illustration, concept art, and design. Share your work, tools, and tutorials for all skill levels.', emoji: '🖼️', privacy: 'public' },
  { name: 'Watercolor Society',         topic: 'art', description: 'The beautiful, unpredictable world of watercolor. Share your paintings, techniques, and color palettes.', emoji: '🖼️', privacy: 'public' },
  { name: 'Sketch & Draw Daily',        topic: 'art', description: 'Daily sketching challenges and drawings. Build a habit of drawing with our supportive community.', emoji: '🖼️', privacy: 'public' },

  // Tech
  { name: 'Open Source Builders',       topic: 'tech', description: 'Building in the open. Share your OSS projects, find contributors, and discuss open source culture.', emoji: '🖥️', privacy: 'public' },
  { name: 'AI & Machine Learning',      topic: 'tech', description: 'Exploring artificial intelligence and ML. Papers, projects, tools, and discussions about the AI revolution.', emoji: '🖥️', privacy: 'public' },
  { name: 'Web Dev Community',          topic: 'tech', description: 'Frontend, backend, full-stack. JavaScript, Python, Go — all developers welcome. Share projects and ask questions.', emoji: '🖥️', privacy: 'public' },

  // Nature
  { name: 'Hiking & Trail Running',     topic: 'nature', description: 'Trail reports, gear reviews, and photos from the outdoors. Find new routes and connect with other hikers.', emoji: '🌳', privacy: 'public' },
  { name: 'Urban Gardening',            topic: 'nature', description: 'Growing food and plants in small spaces, balconies, and backyards. Share your harvests and gardening tips.', emoji: '🌳', privacy: 'public' },

  // Reading
  { name: 'Science Fiction Bookclub',   topic: 'reading', description: 'Exploring the future through sci-fi. Monthly reads, author discussions, and recommendations.', emoji: '📖', privacy: 'public' },
  { name: 'Nonfiction Deep Dives',      topic: 'reading', description: 'For those who read to learn. Share book summaries, key ideas, and recommendations across all nonfiction genres.', emoji: '📖', privacy: 'public' },

  // Film
  { name: 'Cinema Lovers Club',         topic: 'film', description: 'Reviews, recommendations, and discussions about movies from all eras and genres. No spoilers without warnings!', emoji: '🎥', privacy: 'public' },
  { name: 'Filmmaking & Cinematography',topic: 'film', description: 'For aspiring and professional filmmakers. Techniques, gear, short films, and industry discussions.', emoji: '🎥', privacy: 'public' },

  // Sports
  { name: 'Amateur Football League',    topic: 'sports', description: 'Organising and discussing amateur football. Find games, share highlights, and connect with local players.', emoji: '🏅', privacy: 'public' },
];

const SAMPLE_POSTS = [
  { content: 'Just finished a 10km morning run! Personal best this month 🎉 Who else is training for a 5K? Drop your times below!', topic: 'fitness' },
  { content: 'Made sourdough bread from scratch today. The crust came out perfectly crispy. Took 3 failed attempts to get here but so worth it! 🍞', topic: 'cooking' },
  { content: 'Captured this incredible golden hour shot in the city. Sometimes you just have to wait for the light. #streetphotography #goldenhour', topic: 'photography' },
  { content: 'Finally beat Dark Souls after 80 hours. The satisfaction is unreal. What game took you the longest to finish?', topic: 'gaming' },
  { content: 'Just got back from 3 weeks solo traveling through Southeast Asia on $40/day. Happy to share my full budget breakdown!', topic: 'travel' },
  { content: 'Released my first EP on Spotify today! 2 years of bedroom production finally out in the world. Link in bio 🎵', topic: 'music' },
  { content: 'New digital illustration I finished this week. Took about 12 hours in Procreate. Still learning but loving the progress!', topic: 'art' },
  { content: 'Launched my open source project on GitHub and it hit 100 stars overnight! The dev community never ceases to amaze me.', topic: 'tech' },
  { content: 'Found the most incredible hidden waterfall on a trail near my city. Only 45 minute hike. Nature has so many secrets!', topic: 'nature' },
  { content: 'Just finished Project Hail Mary by Andy Weir — possibly the best sci-fi I\'ve read in years. The friendship at the core of it is just 🤌', topic: 'reading' },
];

// ─── SEEDING FUNCTIONS ────────────────────────────────────────────

async function seedGroups() {
  console.log('🌱 Seeding groups...');
  const batch = db.batch();
  const createdGroupIds = {};

  for (const group of GROUPS) {
    const ref = db.collection('groups').doc();
    batch.set(ref, {
      ...group,
      memberCount: Math.floor(Math.random() * 200) + 10, // random 10–210
      members:     [],
      createdBy:   'system',
      createdAt:   admin.firestore.FieldValue.serverTimestamp(),
    });
    createdGroupIds[group.topic] = createdGroupIds[group.topic] || [];
    createdGroupIds[group.topic].push(ref.id);
  }

  await batch.commit();
  console.log(`✅ Created ${GROUPS.length} groups`);
  return createdGroupIds;
}

async function seedPosts(groupIds) {
  console.log('📝 Seeding sample posts...');
  const batch = db.batch();

  for (const post of SAMPLE_POSTS) {
    const groupsForTopic = groupIds[post.topic] || [];
    const groupId = groupsForTopic[0];
    if (!groupId) continue;

    const ref = db.collection('posts').doc();
    batch.set(ref, {
      authorId:       'system',
      authorName:     'Habesha Team',
      authorUsername: 'habesha',
      authorVerified: true,
      groupId,
      groupTopic:     post.topic,
      groupName:      GROUPS.find((g) => g.topic === post.topic)?.name || '',
      content:        post.content,
      imageUrl:       null,
      likes:          [],
      reactions:      {},
      commentCount:   0,
      viewCount:      Math.floor(Math.random() * 500) + 50,
      createdAt:      admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  await batch.commit();
  console.log(`✅ Created ${SAMPLE_POSTS.length} sample posts`);
}

async function createSystemUser() {
  console.log('👤 Creating system user...');
  await db.collection('users').doc('system').set({
    uid:              'system',
    displayName:      'Habesha Team',
    displayNameLower: 'habesha team',
    username:         'habesha',
    email:            'team@habesha.app',
    photoURL:         null,
    bio:              'Welcome to Habesha! 🌟 ኢትዮጵያዊ community — Connect, Share, Belong.',
    interests:        ['photography', 'gaming', 'cooking', 'music', 'travel', 'tech'],
    joinedGroups:     [],
    followersCount:   0,
    followingCount:   0,
    verified:         true,
    admin:            false,
    onboardingComplete: true,
    createdAt:        admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });

  // Reserve the @habesha username
  await db.collection('usernames').doc('habesha').set({
    uid:       'system',
    claimedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  console.log('✅ System user created');
}

async function seedHashtags() {
  console.log('#️⃣  Seeding popular hashtags...');
  const tags = [
    { tag: 'photography', count: 1200 },
    { tag: 'gaming',      count: 980  },
    { tag: 'cooking',     count: 750  },
    { tag: 'travel',      count: 640  },
    { tag: 'fitness',     count: 590  },
    { tag: 'music',       count: 520  },
    { tag: 'art',         count: 480  },
    { tag: 'tech',        count: 430  },
    { tag: 'nature',      count: 380  },
    { tag: 'reading',     count: 310  },
    { tag: 'film',        count: 280  },
    { tag: 'sports',      count: 260  },
  ];

  const batch = db.batch();
  for (const { tag, count } of tags) {
    batch.set(db.collection('hashtags').doc(tag), {
      tag,
      count,
      weeklyCount: Math.floor(count * 0.3),
      lastUsed: admin.firestore.FieldValue.serverTimestamp(),
      postIds: [],
    });
  }
  await batch.commit();
  console.log(`✅ Seeded ${tags.length} hashtags`);
}

// ─── MAIN ─────────────────────────────────────────────────────────

async function main() {
  console.log('\n🚀 Starting Habesha data seeding...\n');

  try {
    await createSystemUser();
    const groupIds = await seedGroups();
    await seedPosts(groupIds);
    await seedHashtags();

    console.log('\n✅ Seeding complete! Your app now has:');
    console.log(`   • ${GROUPS.length} interest groups`);
    console.log(`   • ${SAMPLE_POSTS.length} sample posts`);
    console.log(`   • 12 trending hashtags`);
    console.log(`   • 1 verified system account\n`);
  } catch (err) {
    console.error('❌ Seeding error:', err);
    process.exit(1);
  }

  process.exit(0);
}

main();

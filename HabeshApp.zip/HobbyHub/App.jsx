// App.jsx — Root entry point
import React from 'react';
import { StatusBar } from 'react-native';
import { AuthProvider } from './src/context/AuthContext';
import { ToastProvider } from './src/components/Toast';
import ErrorBoundary from './src/components/ErrorBoundary';
import OfflineBanner from './src/components/OfflineBanner';
import AppNavigator from './src/navigation/AppNavigator';

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ToastProvider>
          <StatusBar barStyle="dark-content" />
          <OfflineBanner />
          <AppNavigator />
        </ToastProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

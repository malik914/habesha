// src/utils/appUtils.js
// Deep links + App rating prompt + Native share sheet
// Install: npx expo install expo-linking expo-store-review expo-sharing

import * as Linking   from 'expo-linking';
import * as StoreReview from 'expo-store-review';
import * as Sharing   from 'expo-sharing';
import { Share, Platform } from 'react-native';
import AsyncStorage   from '@react-native-async-storage/async-storage';

// ── DEEP LINKS ────────────────────────────────────────────────────
// Add to app.json:
// "scheme": "habesha",
// "intentFilters": [{ "action": "VIEW", "data": [{ "scheme": "habesha" }] }]

export const DEEP_LINK_PREFIX = Linking.createURL('/');

export const createDeepLink = {
  profile:  (username)   => `habesha://profile/${username}`,
  post:     (postId)     => `habesha://post/${postId}`,
  group:    (groupId)    => `habesha://group/${groupId}`,
  hashtag:  (tag)        => `habesha://hashtag/${tag}`,
  invite:   (groupId)    => `https://habesha.app/join/${groupId}`,
};

// Parse incoming deep link
export const handleDeepLink = (url, navigation) => {
  if (!url) return;
  const { path, queryParams } = Linking.parse(url);
  const segments = path?.split('/').filter(Boolean) || [];

  switch (segments[0]) {
    case 'profile':  return navigation.navigate('UserProfile', { userId: segments[1] });
    case 'post':     return navigation.navigate('Feed');
    case 'group':    return navigation.navigate('GroupDetail', { groupId: segments[1] });
    case 'hashtag':  return navigation.navigate('Hashtag', { tag: segments[1] });
    case 'join':     return navigation.navigate('GroupDetail', { groupId: segments[1] });
    default: return;
  }
};

// Hook to handle deep links
export const useDeepLinks = (navigationRef) => {
  const { useEffect } = require('react');

  useEffect(() => {
    // Handle app opened from deep link
    Linking.getInitialURL().then((url) => {
      if (url && navigationRef?.current) handleDeepLink(url, navigationRef.current);
    });

    // Handle deep links while app is open
    const sub = Linking.addEventListener('url', ({ url }) => {
      if (url && navigationRef?.current) handleDeepLink(url, navigationRef.current);
    });

    return () => sub.remove();
  }, [navigationRef]);
};


// ── APP RATING PROMPT ─────────────────────────────────────────────
const RATING_STORAGE_KEY = '@habesha_rating_shown';
const SESSIONS_BEFORE_PROMPT = 5;
const DAYS_BEFORE_RETRY = 30;

export const trackSession = async () => {
  try {
    const data = await AsyncStorage.getItem(RATING_STORAGE_KEY);
    const state = data ? JSON.parse(data) : { sessions: 0, lastShown: null, neverShow: false };

    if (state.neverShow) return;

    state.sessions += 1;
    await AsyncStorage.setItem(RATING_STORAGE_KEY, JSON.stringify(state));
  } catch (e) { console.error(e); }
};

export const maybeRequestReview = async () => {
  try {
    const available = await StoreReview.isAvailableAsync();
    if (!available) return;

    const data = await AsyncStorage.getItem(RATING_STORAGE_KEY);
    const state = data ? JSON.parse(data) : { sessions: 0, lastShown: null, neverShow: false };

    if (state.neverShow) return;
    if (state.sessions < SESSIONS_BEFORE_PROMPT) return;

    if (state.lastShown) {
      const daysSince = (Date.now() - state.lastShown) / (1000 * 60 * 60 * 24);
      if (daysSince < DAYS_BEFORE_RETRY) return;
    }

    await StoreReview.requestReview();
    state.lastShown = Date.now();
    state.sessions  = 0;
    await AsyncStorage.setItem(RATING_STORAGE_KEY, JSON.stringify(state));
  } catch (e) { console.error(e); }
};


// ── NATIVE SHARE SHEET ────────────────────────────────────────────
export const sharePost = async (post) => {
  try {
    const url = createDeepLink.post(post.id);
    await Share.share({
      title:   `Check out this post on Habesha`,
      message: Platform.OS === 'android'
        ? `${post.content?.slice(0, 100) || 'Check this out!'}\n\n${url}`
        : post.content?.slice(0, 100) || 'Check this out!',
      url,
    });
  } catch (e) {
    if (e.message !== 'The user did not share') console.error(e);
  }
};

export const shareProfile = async (profile) => {
  try {
    const url = createDeepLink.profile(profile.username || profile.uid);
    await Share.share({
      title:   `${profile.displayName} on Habesha`,
      message: Platform.OS === 'android' ? `Follow ${profile.displayName} on Habesha!\n${url}` : `Follow ${profile.displayName} on Habesha!`,
      url,
    });
  } catch (e) { console.error(e); }
};

export const shareGroup = async (group) => {
  try {
    const url = createDeepLink.invite(group.id);
    await Share.share({
      title:   `Join ${group.name} on Habesha`,
      message: `Join the "${group.name}" group on Habesha!\n${url}`,
      url,
    });
  } catch (e) { console.error(e); }
};

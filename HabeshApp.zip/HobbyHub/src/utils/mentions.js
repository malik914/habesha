// src/utils/mentions.js
// @mention system: parsing, autocomplete, and notifications

import { collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase/config';
import { createNotification } from '../firebase/firestore';

// ── Parse mentions from text ──────────────────────────────────────
export const extractMentions = (text = '') => {
  const matches = text.match(/@([a-zA-Z0-9_]{3,20})/g) || [];
  return [...new Set(matches.map((m) => m.slice(1).toLowerCase()))];
};

// ── Resolve @usernames → user IDs ────────────────────────────────
export const resolveMentions = async (usernames) => {
  if (!usernames.length) return [];
  const results = [];
  // Batch in groups of 10 (Firestore 'in' limit)
  for (let i = 0; i < usernames.length; i += 10) {
    const chunk = usernames.slice(i, i + 10);
    const snap = await getDocs(
      query(collection(db, 'usernames'),
        where('__name__', 'in', chunk))
    );
    snap.docs.forEach((d) => results.push({ username: d.id, uid: d.data().uid }));
  }
  return results;
};

// ── Send mention notifications ────────────────────────────────────
export const notifyMentions = async (text, fromUserId, fromUserName, postId) => {
  const usernames = extractMentions(text);
  if (!usernames.length) return;
  const resolved = await resolveMentions(usernames);
  await Promise.all(
    resolved
      .filter((u) => u.uid !== fromUserId) // don't notify self
      .map((u) =>
        createNotification({
          userId: u.uid,
          type: 'mention',
          fromUserId,
          fromUserName,
          postId,
        })
      )
  );
};

// ── Autocomplete suggestions ──────────────────────────────────────
export const getMentionSuggestions = async (prefix, limitCount = 5) => {
  if (!prefix || prefix.length < 2) return [];
  const snap = await getDocs(
    query(
      collection(db, 'users'),
      where('displayNameLower', '>=', prefix.toLowerCase()),
      where('displayNameLower', '<=', prefix.toLowerCase() + '\uf8ff'),
      limit(limitCount),
    )
  );
  return snap.docs.map((d) => ({
    uid:         d.data().uid,
    displayName: d.data().displayName,
    username:    d.data().username,
    photoURL:    d.data().photoURL,
  }));
};


// ── MentionInput Component ────────────────────────────────────────
// Drop-in replacement for TextInput that shows @mention autocomplete
import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity,
  StyleSheet, Image,
} from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

export function MentionInput({ value, onChangeText, placeholder, style, maxLength, multiline, autoFocus }) {
  const [suggestions, setSugs] = useState([]);
  const [mentionStart, setStart] = useState(-1);
  const debounceRef = useRef(null);

  const handleChange = useCallback((text) => {
    onChangeText(text);

    // Find active @mention being typed
    const cursorPos = text.length;
    const lastAt = text.lastIndexOf('@', cursorPos);

    if (lastAt !== -1) {
      const fragment = text.slice(lastAt + 1, cursorPos);
      if (fragment.length >= 1 && !/\s/.test(fragment)) {
        setStart(lastAt);
        clearTimeout(debounceRef.current);
        debounceRef.current = setTimeout(async () => {
          const sugs = await getMentionSuggestions(fragment);
          setSugs(sugs);
        }, 300);
        return;
      }
    }
    setSugs([]);
    setStart(-1);
  }, [onChangeText]);

  const insertMention = (user) => {
    const before = value.slice(0, mentionStart);
    const after  = value.slice(value.length); // after cursor
    const newText = `${before}@${user.username || user.displayName} `;
    onChangeText(newText);
    setSugs([]);
    setStart(-1);
  };

  return (
    <View style={mi.wrap}>
      {suggestions.length > 0 && (
        <View style={mi.suggestions}>
          {suggestions.map((u) => (
            <TouchableOpacity key={u.uid} style={mi.suggestion} onPress={() => insertMention(u)}>
              {u.photoURL
                ? <Image source={{ uri: u.photoURL }} style={mi.sugAvatar} />
                : <View style={mi.sugAvatarFallback}><Text style={mi.sugAvatarTxt}>{u.displayName?.[0]}</Text></View>
              }
              <View>
                <Text style={mi.sugName}>{u.displayName}</Text>
                {u.username && <Text style={mi.sugUsername}>@{u.username}</Text>}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      )}
      <TextInput
        style={style}
        value={value}
        onChangeText={handleChange}
        placeholder={placeholder}
        placeholderTextColor={colors.textMuted}
        maxLength={maxLength}
        multiline={multiline}
        autoFocus={autoFocus}
      />
    </View>
  );
}

const mi = StyleSheet.create({
  wrap: { position: 'relative' },
  suggestions: {
    position: 'absolute', bottom: '100%', left: 0, right: 0,
    backgroundColor: colors.surfaceHigh, borderRadius: borderRadius.lg,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
    zIndex: 100, ...shadows.lg,
  },
  suggestion: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  sugAvatar: { width: 36, height: 36, borderRadius: 18 },
  sugAvatarFallback: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  sugAvatarTxt: { color: '#fff', fontWeight: '700' },
  sugName: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold, color: colors.textPrimary },
  sugUsername: { fontSize: typography.fontSize.xs, color: colors.textMuted },
});

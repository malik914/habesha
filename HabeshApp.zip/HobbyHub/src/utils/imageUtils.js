// src/utils/imageUtils.js
// Image compression before upload + full-screen viewer
// Install: npx expo install expo-image-manipulator expo-sharing

import * as ImageManipulator from 'expo-image-manipulator';
import * as Sharing from 'expo-sharing';

// ── Compress image before upload ──────────────────────────────────
/**
 * Compress and resize an image before uploading.
 * Reduces file size by ~70% while keeping good quality.
 */
export const compressImage = async (uri, options = {}) => {
  const {
    maxWidth  = 1200,
    maxHeight = 1200,
    quality   = 0.75,
    format    = ImageManipulator.SaveFormat.JPEG,
  } = options;

  try {
    const result = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: maxWidth, height: maxHeight } }],
      { compress: quality, format }
    );
    return result.uri;
  } catch (e) {
    console.warn('Image compression failed, using original:', e);
    return uri; // fallback to original
  }
};

// Avatar: smaller, square crop
export const compressAvatar = (uri) =>
  compressImage(uri, { maxWidth: 400, maxHeight: 400, quality: 0.8 });

// Post image: medium quality
export const compressPostImage = (uri) =>
  compressImage(uri, { maxWidth: 1080, maxHeight: 1080, quality: 0.78 });

// Story: slightly lower quality is fine
export const compressStoryImage = (uri) =>
  compressImage(uri, { maxWidth: 1080, maxHeight: 1920, quality: 0.72 });


// ── Full-screen image viewer component ────────────────────────────
import React, { useRef, useState } from 'react';
import {
  Modal, View, Image, StyleSheet, TouchableOpacity,
  Dimensions, Animated, StatusBar, Text, Share,
} from 'react-native';
import { colors, spacing } from '../theme';

const { width: W, height: H } = Dimensions.get('window');

export function ImageViewer({ uri, visible, onClose, caption, authorName }) {
  const scaleAnim  = useRef(new Animated.Value(1)).current;
  const opacAnim   = useRef(new Animated.Value(0)).current;
  const [showInfo, setShowInfo] = useState(true);

  React.useEffect(() => {
    if (visible) {
      Animated.timing(opacAnim, { toValue: 1, duration: 250, useNativeDriver: true }).start();
    }
  }, [visible]);

  const handleShare = async () => {
    try {
      await Share.share({ url: uri, message: caption || '' });
    } catch (e) { console.error(e); }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <StatusBar hidden />
      <Animated.View style={[iv.container, { opacity: opacAnim }]}>
        {/* Background tap to dismiss */}
        <TouchableOpacity style={StyleSheet.absoluteFillObject} onPress={onClose} activeOpacity={1} />

        {/* Image */}
        <Animated.Image
          source={{ uri }}
          style={[iv.image, { transform: [{ scale: scaleAnim }] }]}
          resizeMode="contain"
        />

        {/* Top bar */}
        <View style={iv.topBar}>
          <TouchableOpacity style={iv.closeBtn} onPress={onClose}>
            <Text style={iv.closeTxt}>✕</Text>
          </TouchableOpacity>
          <TouchableOpacity style={iv.shareBtn} onPress={handleShare}>
            <Text style={iv.shareTxt}>↗️</Text>
          </TouchableOpacity>
        </View>

        {/* Bottom info */}
        {(caption || authorName) && showInfo && (
          <TouchableOpacity style={iv.bottomInfo} onPress={() => setShowInfo(false)} activeOpacity={0.8}>
            {authorName && <Text style={iv.infoAuthor}>{authorName}</Text>}
            {caption && <Text style={iv.infoCaption} numberOfLines={3}>{caption}</Text>}
          </TouchableOpacity>
        )}
      </Animated.View>
    </Modal>
  );
}

const iv = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'rgba(0,0,0,0.97)', justifyContent: 'center', alignItems: 'center' },
  image: { width: W, height: H * 0.75 },
  topBar: { position: 'absolute', top: 50, left: 0, right: 0, flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: spacing.xl },
  closeBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(255,255,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  closeTxt: { color: '#fff', fontSize: 18, fontWeight: '700' },
  shareBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(255,255,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  shareTxt: { fontSize: 20 },
  bottomInfo: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.7)', padding: spacing.xl, gap: spacing.xs },
  infoAuthor: { color: '#fff', fontWeight: '700', fontSize: 14 },
  infoCaption: { color: 'rgba(255,255,255,0.75)', fontSize: 13, lineHeight: 18 },
});

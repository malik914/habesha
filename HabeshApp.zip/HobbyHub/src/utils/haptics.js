// src/utils/haptics.js
// Centralized haptic feedback — import this everywhere instead of raw expo-haptics
// Install: npx expo install expo-haptics

import * as Haptics from 'expo-haptics';

export const haptic = {
  // Light tap — buttons, toggles, selections
  light: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),

  // Medium — confirm actions, tab switches
  medium: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium),

  // Heavy — important actions (delete, publish)
  heavy: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy),

  // Success — post submitted, follow confirmed
  success: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success),

  // Warning — approaching limit, privacy change
  warning: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning),

  // Error — failed action, wrong password
  error: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error),

  // Selection — scrolling through options
  select: () => Haptics.selectionAsync(),
};

// src/payments/RevenueCat.js
// Setup: npm install react-native-purchases
// iOS: npx pod-install
// Docs: https://docs.revenuecat.com/docs/react-native

import Purchases, { LOG_LEVEL } from 'react-native-purchases';
import { Platform } from 'react-native';

// 🔴 Replace with your RevenueCat API keys (free at revenuecat.com)
const API_KEYS = {
  ios: 'appl_YOUR_IOS_KEY',
  android: 'goog_YOUR_ANDROID_KEY',
};

// Premium entitlement identifier (set in RevenueCat dashboard)
export const ENTITLEMENT_ID = 'premium';

// Product identifiers (set in App Store Connect / Google Play)
export const PRODUCTS = {
  MONTHLY: 'habesha_premium_monthly',
  YEARLY: 'habesha_premium_yearly',
};

/**
 * Initialize RevenueCat — call once on app start, after user logs in
 */
export const initRevenueCat = async (userId) => {
  if (__DEV__) {
    Purchases.setLogLevel(LOG_LEVEL.DEBUG);
  }

  const apiKey = Platform.OS === 'ios' ? API_KEYS.ios : API_KEYS.android;
  await Purchases.configure({ apiKey, appUserID: userId });
};

/**
 * Get available subscription packages
 * Returns array of { product, packageType, identifier }
 */
export const getOfferings = async () => {
  try {
    const offerings = await Purchases.getOfferings();
    if (offerings.current?.availablePackages?.length > 0) {
      return offerings.current.availablePackages;
    }
    return [];
  } catch (e) {
    console.error('RevenueCat getOfferings error:', e);
    return [];
  }
};

/**
 * Purchase a package
 * @param {object} pkg - Package from getOfferings()
 * @returns {{ success, customerInfo, error }}
 */
export const purchasePackage = async (pkg) => {
  try {
    const { customerInfo } = await Purchases.purchasePackage(pkg);
    const isPremium = customerInfo.entitlements.active[ENTITLEMENT_ID] !== undefined;
    return { success: isPremium, customerInfo, error: null };
  } catch (e) {
    if (!e.userCancelled) {
      console.error('Purchase error:', e);
    }
    return { success: false, customerInfo: null, error: e };
  }
};

/**
 * Restore previous purchases (required by App Store / Play Store)
 */
export const restorePurchases = async () => {
  try {
    const customerInfo = await Purchases.restorePurchases();
    const isPremium = customerInfo.entitlements.active[ENTITLEMENT_ID] !== undefined;
    return { success: isPremium, customerInfo, error: null };
  } catch (e) {
    return { success: false, customerInfo: null, error: e };
  }
};

/**
 * Check if current user has premium access
 */
export const checkPremiumStatus = async () => {
  try {
    const customerInfo = await Purchases.getCustomerInfo();
    return customerInfo.entitlements.active[ENTITLEMENT_ID] !== undefined;
  } catch (e) {
    return false;
  }
};


// ─── Paywall Screen ────────────────────────────────────────────────────────
// src/screens/PaywallScreen.jsx

import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, TouchableOpacity,
  ActivityIndicator, Alert, ScrollView,
} from 'react-native';
import { getOfferings, purchasePackage, restorePurchases, PRODUCTS } from './RevenueCat';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

const PREMIUM_FEATURES = [
  { icon: '✨', text: 'Create unlimited groups' },
  { icon: '🚫', text: 'Ad-free experience' },
  { icon: '📌', text: 'Pin posts and messages' },
  { icon: '🎨', text: 'Exclusive profile themes' },
  { icon: '📊', text: 'Group analytics & insights' },
  { icon: '⚡', text: 'Priority support' },
];

export default function PaywallScreen({ onClose, onSuccess }) {
  const [packages, setPackages] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const [restoring, setRestoring] = useState(false);

  useEffect(() => {
    getOfferings().then((pkgs) => {
      setPackages(pkgs);
      // Default select yearly if available
      const yearly = pkgs.find((p) => p.identifier === PRODUCTS.YEARLY) || pkgs[0];
      setSelected(yearly);
      setLoading(false);
    });
  }, []);

  const handlePurchase = async () => {
    if (!selected) return;
    setPurchasing(true);
    const { success, error } = await purchasePackage(selected);
    setPurchasing(false);
    if (success) {
      Alert.alert('🎉 Welcome to Premium!', 'Enjoy all the premium features of Habesha.');
      onSuccess?.();
    } else if (error && !error.userCancelled) {
      Alert.alert('Purchase failed', error.message);
    }
  };

  const handleRestore = async () => {
    setRestoring(true);
    const { success } = await restorePurchases();
    setRestoring(false);
    if (success) {
      Alert.alert('Restored!', 'Your premium subscription has been restored.');
      onSuccess?.();
    } else {
      Alert.alert('No subscription found', 'No active subscription found for this account.');
    }
  };

  return (
    <SafeAreaView style={paywallStyles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Close */}
        {onClose && (
          <TouchableOpacity style={paywallStyles.closeBtn} onPress={onClose}>
            <Text style={paywallStyles.closeBtnText}>✕</Text>
          </TouchableOpacity>
        )}

        {/* Hero */}
        <View style={paywallStyles.hero}>
          <Text style={paywallStyles.crown}>👑</Text>
          <Text style={paywallStyles.heroTitle}>Habesha Premium</Text>
          <Text style={paywallStyles.heroSubtitle}>
            Unlock everything and support the community
          </Text>
        </View>

        {/* Features */}
        <View style={paywallStyles.features}>
          {PREMIUM_FEATURES.map(({ icon, text }) => (
            <View key={text} style={paywallStyles.featureRow}>
              <Text style={paywallStyles.featureIcon}>{icon}</Text>
              <Text style={paywallStyles.featureText}>{text}</Text>
            </View>
          ))}
        </View>

        {/* Packages */}
        {loading ? (
          <ActivityIndicator size="large" color={colors.primary} style={{ marginVertical: 40 }} />
        ) : (
          <View style={paywallStyles.packages}>
            {packages.map((pkg) => {
              const isSelected = selected?.identifier === pkg.identifier;
              const isYearly = pkg.product.identifier === PRODUCTS.YEARLY;
              return (
                <TouchableOpacity
                  key={pkg.identifier}
                  style={[paywallStyles.package, isSelected && paywallStyles.packageSelected]}
                  onPress={() => setSelected(pkg)}
                  activeOpacity={0.8}
                >
                  {isYearly && (
                    <View style={paywallStyles.bestValueBadge}>
                      <Text style={paywallStyles.bestValueText}>BEST VALUE</Text>
                    </View>
                  )}
                  <Text style={[paywallStyles.packageTitle, isSelected && paywallStyles.packageTitleSelected]}>
                    {isYearly ? 'Yearly' : 'Monthly'}
                  </Text>
                  <Text style={[paywallStyles.packagePrice, isSelected && paywallStyles.packagePriceSelected]}>
                    {pkg.product.priceString}
                  </Text>
                  <Text style={paywallStyles.packagePer}>
                    {isYearly ? 'per year' : 'per month'}
                  </Text>
                  {isYearly && (
                    <Text style={paywallStyles.savingText}>Save ~40%</Text>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* CTA */}
        <View style={paywallStyles.cta}>
          <TouchableOpacity
            style={[paywallStyles.ctaBtn, (purchasing || !selected) && paywallStyles.ctaBtnDisabled]}
            onPress={handlePurchase}
            disabled={purchasing || !selected}
          >
            {purchasing
              ? <ActivityIndicator color="#fff" />
              : <Text style={paywallStyles.ctaBtnText}>
                  {selected ? `Start with ${selected.product.priceString}` : 'Select a plan'}
                </Text>
            }
          </TouchableOpacity>

          <Text style={paywallStyles.legal}>
            Cancel anytime. Billed through {'\n'}
            {Platform.OS === 'ios' ? 'Apple App Store' : 'Google Play Store'}.
          </Text>

          <TouchableOpacity onPress={handleRestore} disabled={restoring}>
            <Text style={paywallStyles.restoreBtn}>
              {restoring ? 'Restoring...' : 'Restore Purchases'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const paywallStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  closeBtn: { position: 'absolute', top: spacing.lg, right: spacing.xl, zIndex: 10, padding: spacing.sm },
  closeBtnText: { fontSize: 18, color: colors.textSecondary },
  hero: { alignItems: 'center', paddingTop: spacing.xxxl, paddingBottom: spacing.xl, paddingHorizontal: spacing.xl },
  crown: { fontSize: 64, marginBottom: spacing.md },
  heroTitle: { fontSize: typography.fontSize.xxxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, textAlign: 'center' },
  heroSubtitle: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.sm },
  features: { paddingHorizontal: spacing.xl, gap: spacing.md, marginBottom: spacing.xl },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  featureIcon: { fontSize: 22, width: 32, textAlign: 'center' },
  featureText: { fontSize: typography.fontSize.md, color: colors.textPrimary, flex: 1 },
  packages: { flexDirection: 'row', paddingHorizontal: spacing.xl, gap: spacing.md, marginBottom: spacing.xl },
  package: {
    flex: 1, backgroundColor: colors.surface, borderRadius: borderRadius.xl,
    padding: spacing.lg, alignItems: 'center', borderWidth: 2, borderColor: 'transparent',
    ...shadows.sm, position: 'relative', overflow: 'hidden',
  },
  packageSelected: { borderColor: colors.primary, backgroundColor: '#F0F7F8' },
  bestValueBadge: {
    position: 'absolute', top: 0, left: 0, right: 0,
    backgroundColor: colors.accent, paddingVertical: 4,
  },
  bestValueText: { color: '#fff', fontSize: 9, fontWeight: '800', textAlign: 'center', letterSpacing: 1 },
  packageTitle: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textSecondary, marginTop: 16 },
  packageTitleSelected: { color: colors.primary },
  packagePrice: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, marginTop: spacing.xs },
  packagePriceSelected: { color: colors.primary },
  packagePer: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  savingText: { fontSize: typography.fontSize.xs, color: colors.success, fontWeight: typography.fontWeight.bold, marginTop: spacing.xs },
  cta: { paddingHorizontal: spacing.xl, paddingBottom: spacing.xxxl, gap: spacing.md, alignItems: 'center' },
  ctaBtn: {
    width: '100%', backgroundColor: colors.primary,
    paddingVertical: spacing.lg, borderRadius: borderRadius.lg, alignItems: 'center',
  },
  ctaBtnDisabled: { opacity: 0.5 },
  ctaBtnText: { color: '#fff', fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold },
  legal: { fontSize: typography.fontSize.xs, color: colors.textMuted, textAlign: 'center', lineHeight: 18 },
  restoreBtn: { color: colors.primary, fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.medium },
});

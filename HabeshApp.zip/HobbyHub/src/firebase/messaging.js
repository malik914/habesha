// src/firebase/messaging.js
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from './config';

// Configure how notifications appear when app is in foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Request notification permissions and get Expo push token.
 * Saves token to user's Firestore document.
 */
export const registerForPushNotifications = async (userId) => {
  try {
    // Check existing permissions
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    // Ask if not already granted
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.log('Notification permission denied');
      return null;
    }

    // Android channel setup
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Habesha',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#1A6B72',
      });
    }

    // Get Expo push token
    const tokenData = await Notifications.getExpoPushTokenAsync({
      projectId: 'YOUR_EXPO_PROJECT_ID', // Replace with your Expo project ID
    });
    const token = tokenData.data;

    // Save token to Firestore
    if (userId && token) {
      await updateDoc(doc(db, 'users', userId), {
        expoPushToken: token,
        notificationsEnabled: true,
      });
    }

    return token;
  } catch (error) {
    console.error('Push notification setup error:', error);
    return null;
  }
};

/**
 * Send a push notification via Expo's push service.
 * Call this from a Cloud Function or trusted server — not from client directly.
 * Included here as reference for your backend.
 */
export const sendPushNotification = async ({ token, title, body, data = {} }) => {
  const message = {
    to: token,
    sound: 'default',
    title,
    body,
    data,
  };

  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(message),
  });
};

/**
 * Hook to handle notification tap navigation.
 * Use in AppNavigator to route user when tapping a notification.
 *
 * Usage:
 *   const navigationRef = useNavigationContainerRef();
 *   useNotificationNavigation(navigationRef);
 */
export const useNotificationNavigation = (navigationRef) => {
  const { useEffect } = require('react');

  useEffect(() => {
    // Notification tapped while app is open
    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const data = response.notification.request.content.data;
      handleNotificationNavigation(navigationRef, data);
    });

    // App opened FROM a notification (was closed)
    Notifications.getLastNotificationResponseAsync().then((response) => {
      if (response) {
        const data = response.notification.request.content.data;
        handleNotificationNavigation(navigationRef, data);
      }
    });

    return () => sub.remove();
  }, [navigationRef]);
};

const handleNotificationNavigation = (navigationRef, data) => {
  if (!navigationRef?.current || !data) return;

  switch (data.type) {
    case 'message':
      navigationRef.current.navigate('Chat', {
        conversationId: data.conversationId,
        title: data.fromUserName,
      });
      break;
    case 'like':
    case 'comment':
      navigationRef.current.navigate('Feed');
      break;
    case 'follow':
      navigationRef.current.navigate('Profile');
      break;
    default:
      navigationRef.current.navigate('Notifications');
  }
};

/**
 * Badge count management
 */
export const setBadgeCount = (count) =>
  Notifications.setBadgeCountAsync(count);

export const clearBadge = () =>
  Notifications.setBadgeCountAsync(0);

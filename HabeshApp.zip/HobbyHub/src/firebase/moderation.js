// src/firebase/moderation.js
import {
  doc, setDoc, deleteDoc, getDoc, addDoc,
  collection, serverTimestamp, updateDoc, arrayUnion,
} from 'firebase/firestore';
import { db } from './config';

// ── BLOCK ────────────────────────────────────────────────────────

export const blockUser = async (blockerId, blockedId) => {
  await setDoc(doc(db, 'users', blockerId, 'blocks', blockedId), {
    blockedId,
    blockedAt: serverTimestamp(),
  });
};

export const unblockUser = async (blockerId, blockedId) => {
  await deleteDoc(doc(db, 'users', blockerId, 'blocks', blockedId));
};

export const isBlocked = async (blockerId, blockedId) => {
  const snap = await getDoc(doc(db, 'users', blockerId, 'blocks', blockedId));
  return snap.exists();
};

export const getBlockedUsers = async (userId) => {
  const { getDocs, collection: col } = await import('firebase/firestore');
  const snap = await getDocs(collection(db, 'users', userId, 'blocks'));
  return snap.docs.map((d) => d.id);
};

// ── REPORT ───────────────────────────────────────────────────────

export const REPORT_REASONS = [
  'Spam or misleading',
  'Hate speech or discrimination',
  'Harassment or bullying',
  'Nudity or sexual content',
  'Violence or dangerous content',
  'False information',
  'Other',
];

export const reportContent = async ({ reporterId, targetId, targetType, reason, details }) => {
  await addDoc(collection(db, 'reports'), {
    reporterId,
    targetId,
    targetType, // 'user' | 'post' | 'group'
    reason,
    details: details || '',
    status: 'pending',
    createdAt: serverTimestamp(),
  });
};


// ── ReportSheet Component ─────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, Modal, TouchableOpacity, StyleSheet,
  SafeAreaView, ActivityIndicator, Alert,
} from 'react-native';
import { colors, typography, spacing, borderRadius } from '../theme';

export function ReportSheet({ visible, onClose, targetId, targetType, reporterId }) {
  const [selected, setSelected] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selected) return;
    setSubmitting(true);
    try {
      await reportContent({ reporterId, targetId, targetType, reason: selected });
      onClose();
      Alert.alert('Report submitted', 'Thank you. We review all reports within 24 hours.');
    } catch (e) {
      Alert.alert('Error', 'Could not submit report. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <SafeAreaView style={rs.container}>
        <View style={rs.header}>
          <TouchableOpacity onPress={onClose}>
            <Text style={rs.cancel}>Cancel</Text>
          </TouchableOpacity>
          <Text style={rs.title}>Report</Text>
          <TouchableOpacity
            style={[rs.submitBtn, !selected && rs.submitBtnDisabled]}
            onPress={handleSubmit}
            disabled={!selected || submitting}
          >
            {submitting
              ? <ActivityIndicator size="small" color="#fff" />
              : <Text style={rs.submitTxt}>Submit</Text>
            }
          </TouchableOpacity>
        </View>

        <Text style={rs.subtitle}>Why are you reporting this?</Text>

        <View style={rs.reasons}>
          {REPORT_REASONS.map((reason) => (
            <TouchableOpacity
              key={reason}
              style={[rs.reason, selected === reason && rs.reasonSelected]}
              onPress={() => setSelected(reason)}
              activeOpacity={0.7}
            >
              <Text style={[rs.reasonTxt, selected === reason && rs.reasonTxtSelected]}>
                {reason}
              </Text>
              {selected === reason && <Text style={rs.check}>✓</Text>}
            </TouchableOpacity>
          ))}
        </View>

        <Text style={rs.disclaimer}>
          Reports are reviewed by our team within 24 hours. False reports may result in account restrictions.
        </Text>
      </SafeAreaView>
    </Modal>
  );
}

const rs = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: spacing.xl, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.surface },
  cancel: { color: colors.textSecondary, fontSize: typography.fontSize.md },
  title: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  submitBtn: { backgroundColor: colors.error, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: borderRadius.full },
  submitBtnDisabled: { opacity: 0.4 },
  submitTxt: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.sm },
  subtitle: { fontSize: typography.fontSize.md, color: colors.textSecondary, padding: spacing.xl, paddingBottom: spacing.md },
  reasons: { paddingHorizontal: spacing.lg },
  reason: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: spacing.lg, paddingHorizontal: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, borderRadius: borderRadius.md },
  reasonSelected: { backgroundColor: colors.surfaceAlt },
  reasonTxt: { fontSize: typography.fontSize.md, color: colors.textPrimary },
  reasonTxtSelected: { color: colors.primary, fontWeight: typography.fontWeight.semibold },
  check: { color: colors.primary, fontSize: 18, fontWeight: '700' },
  disclaimer: { fontSize: typography.fontSize.xs, color: colors.textMuted, padding: spacing.xl, lineHeight: 18 },
});

// src/firebase/follows.js — Real-time v2
import {
  doc, collection, setDoc, deleteDoc, getDoc,
  getDocs, query, where, orderBy, limit,
  onSnapshot, updateDoc, increment, serverTimestamp,
} from 'firebase/firestore';
import { db } from './config';
import { createNotification } from './firestore';

// ─── FOLLOW / UNFOLLOW ─────────────────────────────────────────────

export const followUser = async (followerId, followerName, targetId) => {
  const followId = `${followerId}_${targetId}`;
  await setDoc(doc(db, 'follows', followId), {
    followerId, followingId: targetId, createdAt: serverTimestamp(),
  });
  await updateDoc(doc(db, 'users', followerId), { followingCount: increment(1) });
  await updateDoc(doc(db, 'users', targetId),   { followersCount: increment(1) });
  await createNotification({
    userId: targetId, type: 'follow',
    fromUserId: followerId, fromUserName: followerName,
  });
};

export const unfollowUser = async (followerId, targetId) => {
  const followId = `${followerId}_${targetId}`;
  await deleteDoc(doc(db, 'follows', followId));
  await updateDoc(doc(db, 'users', followerId), { followingCount: increment(-1) });
  await updateDoc(doc(db, 'users', targetId),   { followersCount: increment(-1) });
};

export const isFollowing = async (followerId, targetId) => {
  const snap = await getDoc(doc(db, 'follows', `${followerId}_${targetId}`));
  return snap.exists();
};

// ✅ REAL-TIME: Live follow status
export const subscribeFollowStatus = (followerId, targetId, callback) =>
  onSnapshot(doc(db, 'follows', `${followerId}_${targetId}`), (snap) =>
    callback(snap.exists())
  );

// ✅ REAL-TIME: Live follower count for a user
export const subscribeToUserStats = (userId, callback) =>
  onSnapshot(doc(db, 'users', userId), (snap) => {
    if (snap.exists()) {
      const d = snap.data();
      callback({
        followersCount: d.followersCount || 0,
        followingCount: d.followingCount || 0,
        joinedGroups:   d.joinedGroups   || [],
      });
    }
  });

// ✅ REAL-TIME: Live list of who a user follows
export const subscribeToFollowing = (userId, callback) => {
  const q = query(
    collection(db, 'follows'),
    where('followerId', '==', userId),
    orderBy('createdAt', 'desc'),
  );
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => d.data().followingId))
  );
};

// ✅ REAL-TIME: Live followers list
export const subscribeToFollowers = (userId, callback) => {
  const q = query(
    collection(db, 'follows'),
    where('followingId', '==', userId),
    orderBy('createdAt', 'desc'),
  );
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => d.data().followerId))
  );
};

// One-time fetches (kept for non-critical paths)
export const getFollowing = async (userId) => {
  const q = query(collection(db, 'follows'), where('followerId', '==', userId));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data().followingId);
};

export const getFollowers = async (userId) => {
  const q = query(collection(db, 'follows'), where('followingId', '==', userId));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data().followerId);
};

export const getUserById = async (userId) => {
  const snap = await getDoc(doc(db, 'users', userId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
};

// ✅ REAL-TIME: Live single user profile
export const subscribeToUser = (userId, callback) =>
  onSnapshot(doc(db, 'users', userId), (snap) =>
    snap.exists() ? callback({ id: snap.id, ...snap.data() }) : null
  );

export const getUsersByIds = async (userIds) => {
  if (!userIds.length) return [];
  const snaps = await Promise.all(userIds.map((id) => getDoc(doc(db, 'users', id))));
  return snaps.filter((s) => s.exists()).map((s) => ({ id: s.id, ...s.data() }));
};

// ─── SEARCH ────────────────────────────────────────────────────────

export const searchUsers = async (searchTerm, currentUserId, limitCount = 20) => {
  if (!searchTerm.trim()) return [];
  const lower = searchTerm.toLowerCase().trim();
  const q = query(
    collection(db, 'users'),
    where('displayNameLower', '>=', lower),
    where('displayNameLower', '<=', lower + '\uf8ff'),
    limit(limitCount),
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((u) => u.uid !== currentUserId);
};

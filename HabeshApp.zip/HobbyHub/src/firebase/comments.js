// src/firebase/comments.js
import {
  collection, addDoc, query, orderBy,
  onSnapshot, serverTimestamp, limit, doc, updateDoc, increment,
} from 'firebase/firestore';
import { db } from './config';
import { createNotification } from './firestore';

export const subscribeToComments = (postId, callback) => {
  const q = query(
    collection(db, 'posts', postId, 'comments'),
    orderBy('createdAt', 'asc'),
    limit(100),
  );
  return onSnapshot(q, callback);
};

export const addComment = async ({ postId, authorId, authorName, text, postAuthorId }) => {
  // Add comment
  const ref = await addDoc(collection(db, 'posts', postId, 'comments'), {
    authorId,
    authorName,
    text,
    createdAt: serverTimestamp(),
  });

  // Increment comment count on post
  await updateDoc(doc(db, 'posts', postId), {
    commentCount: increment(1),
  });

  // Notify post author (if not self)
  if (postAuthorId && postAuthorId !== authorId) {
    await createNotification({
      userId: postAuthorId,
      type: 'comment',
      fromUserId: authorId,
      fromUserName: authorName,
      postId,
    });
  }

  return ref;
};


// src/components/CommentsSheet.jsx
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  TouchableOpacity, KeyboardAvoidingView, Platform,
  Modal, ActivityIndicator, SafeAreaView,
} from 'react-native';
import { subscribeToComments, addComment } from '../firebase/comments';
import { useAuth } from '../context/AuthContext';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

const Comment = ({ item }) => {
  const timeAgo = item.createdAt?.toDate ? timeSince(item.createdAt.toDate()) : '';
  return (
    <View style={commentStyles.row}>
      <View style={commentStyles.avatar}>
        <Text style={commentStyles.avatarText}>
          {item.authorName?.[0]?.toUpperCase() || '?'}
        </Text>
      </View>
      <View style={commentStyles.bubble}>
        <Text style={commentStyles.author}>{item.authorName}</Text>
        <Text style={commentStyles.text}>{item.text}</Text>
        <Text style={commentStyles.time}>{timeAgo}</Text>
      </View>
    </View>
  );
};

export const CommentsSheet = ({ visible, onClose, post }) => {
  const { user, profile } = useAuth();
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const flatRef = useRef(null);

  useEffect(() => {
    if (!visible || !post?.id) return;
    const unsub = subscribeToComments(post.id, (snap) => {
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setComments(data);
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    });
    return unsub;
  }, [visible, post?.id]);

  const handleSend = async () => {
    if (!text.trim() || !user) return;
    const msg = text.trim();
    setText('');
    setSending(true);
    try {
      await addComment({
        postId: post.id,
        authorId: user.uid,
        authorName: profile?.displayName || user.displayName,
        text: msg,
        postAuthorId: post.authorId,
      });
    } catch (e) {
      console.error(e);
    } finally {
      setSending(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={0}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>
              Comments · {comments.length}
            </Text>
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.closeBtn}>✕</Text>
            </TouchableOpacity>
          </View>

          {/* Post preview */}
          {post && (
            <View style={styles.postPreview}>
              <Text style={styles.postAuthor}>{post.authorName}</Text>
              <Text style={styles.postContent} numberOfLines={2}>{post.content}</Text>
            </View>
          )}

          {/* Comments list */}
          <FlatList
            ref={flatRef}
            data={comments}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <Comment item={item} />}
            contentContainerStyle={{ padding: spacing.lg, gap: spacing.md, flexGrow: 1 }}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Text style={styles.emptyText}>No comments yet. Be the first!</Text>
              </View>
            }
            showsVerticalScrollIndicator={false}
          />

          {/* Input */}
          <View style={styles.inputRow}>
            <View style={styles.inputAvatar}>
              <Text style={styles.inputAvatarText}>
                {profile?.displayName?.[0]?.toUpperCase() || '?'}
              </Text>
            </View>
            <TextInput
              style={styles.input}
              value={text}
              onChangeText={setText}
              placeholder="Add a comment..."
              placeholderTextColor={colors.textMuted}
              multiline
              maxLength={300}
              returnKeyType="send"
              onSubmitEditing={handleSend}
            />
            <TouchableOpacity
              style={[styles.sendBtn, (!text.trim() || sending) && styles.sendBtnDisabled]}
              onPress={handleSend}
              disabled={!text.trim() || sending}
            >
              {sending
                ? <ActivityIndicator size="small" color="#fff" />
                : <Text style={styles.sendIcon}>➤</Text>
              }
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
};

function timeSince(date) {
  const secs = Math.floor((new Date() - date) / 1000);
  if (secs < 60) return 'just now';
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
  return `${Math.floor(secs / 86400)}d ago`;
}

const commentStyles = StyleSheet.create({
  row: { flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-start' },
  avatar: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center',
    flexShrink: 0,
  },
  avatarText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  bubble: {
    flex: 1, backgroundColor: colors.surfaceAlt,
    borderRadius: borderRadius.lg, padding: spacing.md,
  },
  author: { fontWeight: typography.fontWeight.semibold, fontSize: typography.fontSize.sm, color: colors.textPrimary },
  text: { fontSize: typography.fontSize.md, color: colors.textPrimary, marginTop: 2, lineHeight: 20 },
  time: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 4 },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.xl, paddingVertical: spacing.lg,
    borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.surface,
  },
  title: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  closeBtn: { fontSize: 18, color: colors.textSecondary, padding: spacing.sm },
  postPreview: {
    paddingHorizontal: spacing.xl, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    backgroundColor: colors.surface,
  },
  postAuthor: { fontWeight: typography.fontWeight.semibold, fontSize: typography.fontSize.sm, color: colors.textSecondary },
  postContent: { fontSize: typography.fontSize.md, color: colors.textPrimary, marginTop: 2 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 60 },
  emptyText: { color: colors.textMuted, fontSize: typography.fontSize.md },
  inputRow: {
    flexDirection: 'row', alignItems: 'flex-end', gap: spacing.sm,
    padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border,
    backgroundColor: colors.surface,
  },
  inputAvatar: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
  },
  inputAvatarText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  input: {
    flex: 1, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: typography.fontSize.md, color: colors.textPrimary, maxHeight: 100,
  },
  sendBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
  },
  sendBtnDisabled: { opacity: 0.4 },
  sendIcon: { color: '#fff', fontSize: 14 },
});

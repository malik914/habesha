// src/firebase/postActions.js — Real-time v2
import {
  doc, getDoc, getDocs, updateDoc, deleteDoc,
  addDoc, collection, serverTimestamp, increment,
  onSnapshot, query, orderBy, limit,
} from 'firebase/firestore';
import { db } from './config';

// ─── POST EDIT ──────────────────────────────────────────────────────
export const editPost = async (postId, authorId, newContent) => {
  const snap = await getDoc(doc(db, 'posts', postId));
  if (!snap.exists() || snap.data().authorId !== authorId) throw new Error('Not authorized');
  await updateDoc(doc(db, 'posts', postId), {
    content: newContent, editedAt: serverTimestamp(), edited: true,
  });
};

// ─── POST DELETE ────────────────────────────────────────────────────
export const deletePost = async (postId, authorId) => {
  const snap = await getDoc(doc(db, 'posts', postId));
  if (!snap.exists() || snap.data().authorId !== authorId) throw new Error('Not authorized');
  await deleteDoc(doc(db, 'posts', postId));
};

// ─── VIEW TRACKING ──────────────────────────────────────────────────
const viewedThisSession = new Set();
export const trackPostView = async (postId) => {
  if (viewedThisSession.has(postId)) return;
  viewedThisSession.add(postId);
  try {
    await updateDoc(doc(db, 'posts', postId), { viewCount: increment(1) });
  } catch { /* silent */ }
};

// ─── ONE-TIME ANALYTICS ─────────────────────────────────────────────
export const getPostAnalytics = async (postId) => {
  const snap = await getDoc(doc(db, 'posts', postId));
  if (!snap.exists()) return null;
  const d = snap.data();
  const likeCount = d.likes?.length || Object.values(d.reactions || {}).flat().length || 0;
  return {
    viewCount:      d.viewCount      || 0,
    likeCount,
    commentCount:   d.commentCount   || 0,
    shareCount:     d.shareCount     || 0,
    bookmarkCount:  d.bookmarkCount  || 0,
    engagementRate: d.viewCount
      ? `${((likeCount + (d.commentCount || 0)) / d.viewCount * 100).toFixed(1)}%`
      : '—',
  };
};

// ✅ REAL-TIME: Live analytics that update as people interact
export const subscribeToPostAnalytics = (postId, callback) =>
  onSnapshot(doc(db, 'posts', postId), (snap) => {
    if (!snap.exists()) return;
    const d = snap.data();
    const likeCount = d.likes?.length || Object.values(d.reactions || {}).flat().length || 0;
    callback({
      viewCount:     d.viewCount     || 0,
      likeCount,
      commentCount:  d.commentCount  || 0,
      shareCount:    d.shareCount    || 0,
      bookmarkCount: d.bookmarkCount || 0,
      engagementRate: d.viewCount
        ? `${((likeCount + (d.commentCount || 0)) / d.viewCount * 100).toFixed(1)}%`
        : '—',
    });
  });

// ─── COMMENT REPLIES ────────────────────────────────────────────────
export const addCommentReply = async ({ postId, parentCommentId, authorId, authorName, text, postAuthorId }) => {
  const { createNotification } = await import('./firestore');
  const ref = await addDoc(
    collection(db, 'posts', postId, 'comments', parentCommentId, 'replies'),
    { authorId, authorName, text, createdAt: serverTimestamp() }
  );
  await updateDoc(doc(db, 'posts', postId, 'comments', parentCommentId), { replyCount: increment(1) });
  const parentSnap = await getDoc(doc(db, 'posts', postId, 'comments', parentCommentId));
  const parentAuthorId = parentSnap.data()?.authorId;
  if (parentAuthorId && parentAuthorId !== authorId) {
    await createNotification({ userId: parentAuthorId, type: 'comment', fromUserId: authorId, fromUserName: authorName, postId });
  }
  return ref;
};

// ✅ REAL-TIME: Live replies on a comment
export const subscribeToReplies = (postId, commentId, callback) => {
  const q = query(
    collection(db, 'posts', postId, 'comments', commentId, 'replies'),
    orderBy('createdAt', 'asc'),
  );
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  );
};

// ─── PAGINATION HOOK ─────────────────────────────────────────────────
import { useState, useCallback, useRef } from 'react';

export function usePagination(buildQuery, pageSize = 20) {
  const [data, setData]       = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const lastDocRef            = useRef(null);

  const load = useCallback(async (reset = false) => {
    if (loading) return;
    setLoading(true);
    try {
      const q    = buildQuery(reset ? null : lastDocRef.current);
      const snap = await getDocs(q);
      const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      lastDocRef.current = snap.docs[snap.docs.length - 1] || null;
      setHasMore(docs.length === pageSize);
      setData((prev) => reset ? docs : [...prev, ...docs]);
    } catch (e) { console.error('Pagination error:', e); }
    finally { setLoading(false); }
  }, [buildQuery, loading, pageSize]);

  const loadMore = useCallback(() => { if (hasMore && !loading) load(false); }, [hasMore, loading, load]);
  const refresh  = useCallback(() => { lastDocRef.current = null; load(true); }, [load]);
  return { data, loadMore, loading, hasMore, refresh };
}

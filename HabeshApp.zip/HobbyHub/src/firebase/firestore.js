// src/firebase/firestore.js — Full real-time v2
// Every data operation has both a one-time fetch AND a real-time subscribe version

import {
  collection, doc, addDoc, getDoc, getDocs,
  updateDoc, deleteDoc, query, where, orderBy,
  limit, onSnapshot, arrayUnion, arrayRemove,
  serverTimestamp, increment, startAfter,
} from 'firebase/firestore';
import { db } from './config';

// ─── POSTS ─────────────────────────────────────────────────────────

export const createPost = (data) =>
  addDoc(collection(db, 'posts'), {
    ...data,
    likes: [],
    reactions: {},
    commentCount: 0,
    viewCount: 0,
    shareCount: 0,
    bookmarkCount: 0,
    createdAt: serverTimestamp(),
  });

export const getFeedPosts = (groupIds, limitCount = 20) => {
  if (!groupIds.length) return Promise.resolve({ docs: [] });
  return getDocs(query(
    collection(db, 'posts'),
    where('groupId', 'in', groupIds.slice(0, 10)),
    orderBy('createdAt', 'desc'),
    limit(limitCount),
  ));
};

// ✅ REAL-TIME: Live feed updates
export const subscribeToFeed = (groupIds, callback) => {
  if (!groupIds.length) { callback({ docs: [] }); return () => {}; }
  const q = query(
    collection(db, 'posts'),
    where('groupId', 'in', groupIds.slice(0, 10)),
    orderBy('createdAt', 'desc'),
    limit(30),
  );
  return onSnapshot(q, callback);
};

// ✅ REAL-TIME: Live single post (for like/reaction counts)
export const subscribeToPost = (postId, callback) =>
  onSnapshot(doc(db, 'posts', postId), (snap) =>
    snap.exists() ? callback({ id: snap.id, ...snap.data() }) : null
  );

// ✅ REAL-TIME: Live posts for a group
export const subscribeToGroupPosts = (groupId, callback) => {
  const q = query(
    collection(db, 'posts'),
    where('groupId', '==', groupId),
    orderBy('createdAt', 'desc'),
    limit(20),
  );
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  );
};

export const toggleLike = (postId, userId, liked) =>
  updateDoc(doc(db, 'posts', postId), {
    likes: liked ? arrayRemove(userId) : arrayUnion(userId),
  });

// ─── GROUPS ────────────────────────────────────────────────────────

export const getGroups = (limitCount = 50) =>
  getDocs(query(collection(db, 'groups'), orderBy('memberCount', 'desc'), limit(limitCount)));

export const getGroupById = (groupId) =>
  getDoc(doc(db, 'groups', groupId));

// ✅ REAL-TIME: Live group data (member count, posts, etc.)
export const subscribeToGroup = (groupId, callback) =>
  onSnapshot(doc(db, 'groups', groupId), (snap) =>
    snap.exists() ? callback({ id: snap.id, ...snap.data() }) : null
  );

// ✅ REAL-TIME: Live group list updates
export const subscribeToGroups = (callback, limitCount = 50) => {
  const q = query(collection(db, 'groups'), orderBy('memberCount', 'desc'), limit(limitCount));
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  );
};

export const joinGroup = async (groupId, userId) => {
  await updateDoc(doc(db, 'groups', groupId), {
    members: arrayUnion(userId),
    memberCount: increment(1),
  });
  await updateDoc(doc(db, 'users', userId), {
    joinedGroups: arrayUnion(groupId),
  });
};

export const leaveGroup = async (groupId, userId) => {
  await updateDoc(doc(db, 'groups', groupId), {
    members: arrayRemove(userId),
    memberCount: increment(-1),
  });
  await updateDoc(doc(db, 'users', userId), {
    joinedGroups: arrayRemove(groupId),
  });
};

// ─── MESSAGES ──────────────────────────────────────────────────────

export const getOrCreateConversation = async (userId1, userId2) => {
  const participants = [userId1, userId2].sort();
  const q = query(collection(db, 'conversations'), where('participants', '==', participants));
  const snap = await getDocs(q);
  if (!snap.empty) return snap.docs[0].id;
  const ref = await addDoc(collection(db, 'conversations'), {
    participants,
    lastMessage: '',
    lastMessageAt: serverTimestamp(),
  });
  return ref.id;
};

export const sendMessage = async (convId, senderId, text) => {
  await addDoc(collection(db, 'conversations', convId, 'messages'), {
    senderId, text, read: false, createdAt: serverTimestamp(),
  });
  await updateDoc(doc(db, 'conversations', convId), {
    lastMessage: text, lastMessageAt: serverTimestamp(),
  });
};

export const subscribeToMessages = (convId, callback) => {
  const q = query(
    collection(db, 'conversations', convId, 'messages'),
    orderBy('createdAt', 'asc'),
  );
  return onSnapshot(q, callback);
};

// ✅ REAL-TIME: Live conversation list
export const subscribeToConversations = (userId, callback) => {
  const q = query(
    collection(db, 'conversations'),
    where('participants', 'array-contains', userId),
    orderBy('lastMessageAt', 'desc'),
  );
  return onSnapshot(q, (snap) =>
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  );
};

export const getUserConversations = (userId) => {
  const q = query(
    collection(db, 'conversations'),
    where('participants', 'array-contains', userId),
    orderBy('lastMessageAt', 'desc'),
  );
  return getDocs(q);
};

// ─── NOTIFICATIONS ─────────────────────────────────────────────────

export const createNotification = (data) =>
  addDoc(collection(db, 'notifications'), {
    ...data, read: false, createdAt: serverTimestamp(),
  });

export const subscribeToNotifications = (userId, callback) => {
  const q = query(
    collection(db, 'notifications'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(50),
  );
  return onSnapshot(q, callback);
};

export const markNotificationRead = (notifId) =>
  updateDoc(doc(db, 'notifications', notifId), { read: true });

export const markAllNotificationsRead = async (userId) => {
  const q = query(
    collection(db, 'notifications'),
    where('userId', '==', userId),
    where('read', '==', false),
  );
  const snap = await getDocs(q);
  await Promise.all(snap.docs.map((d) => updateDoc(d.ref, { read: true })));
};

// ─── USER PROFILE ──────────────────────────────────────────────────

export const updateUserProfile = (userId, data) =>
  updateDoc(doc(db, 'users', userId), data);

// ✅ REAL-TIME: Live user profile (follower counts, etc.)
export const subscribeToUserProfile = (userId, callback) =>
  onSnapshot(doc(db, 'users', userId), (snap) =>
    snap.exists() ? callback({ id: snap.id, ...snap.data() }) : null
  );

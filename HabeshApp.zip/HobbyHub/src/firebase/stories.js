// src/firebase/stories.js
import {
  collection, addDoc, query, where, orderBy,
  onSnapshot, serverTimestamp, Timestamp, getDocs, doc, deleteDoc,
} from 'firebase/firestore';
import { db } from './config';
import { uploadImage } from './storage';

// Stories expire after 24 hours
const STORY_TTL_MS = 24 * 60 * 60 * 1000;

export const createStory = async ({ authorId, authorName, authorUsername, authorPhoto, mediaUri, text, backgroundColor }) => {
  const expiresAt = Timestamp.fromMillis(Date.now() + STORY_TTL_MS);

  let mediaUrl = null;
  if (mediaUri) {
    mediaUrl = await uploadImage(mediaUri, `stories/${authorId}/${Date.now()}.jpg`);
  }

  return addDoc(collection(db, 'stories'), {
    authorId,
    authorName,
    authorUsername: authorUsername || null,
    authorPhoto: authorPhoto || null,
    mediaUrl,
    text: text || null,
    backgroundColor: backgroundColor || '#1A6B72',
    viewedBy: [],
    expiresAt,
    createdAt: serverTimestamp(),
  });
};

export const subscribeToStories = (followingIds, currentUserId, callback) => {
  const cutoff = Timestamp.fromMillis(Date.now() - STORY_TTL_MS);
  const ids = [currentUserId, ...followingIds].slice(0, 10);

  const q = query(
    collection(db, 'stories'),
    where('authorId', 'in', ids.length ? ids : [currentUserId]),
    where('createdAt', '>=', cutoff),
    orderBy('createdAt', 'desc'),
  );
  return onSnapshot(q, callback);
};

export const markStoryViewed = async (storyId, userId) => {
  const { updateDoc, arrayUnion } = await import('firebase/firestore');
  await updateDoc(doc(db, 'stories', storyId), {
    viewedBy: arrayUnion(userId),
  });
};

// Group stories by author for the story bar
export const groupStoriesByAuthor = (stories) => {
  const map = new Map();
  for (const story of stories) {
    if (!map.has(story.authorId)) {
      map.set(story.authorId, {
        authorId: story.authorId,
        authorName: story.authorName,
        authorUsername: story.authorUsername,
        authorPhoto: story.authorPhoto,
        stories: [],
      });
    }
    map.get(story.authorId).stories.push(story);
  }
  return Array.from(map.values());
};


// ─── StoryBar Component ──────────────────────────────────────────
// src/components/StoryBar.jsx
import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  Image, StyleSheet, Modal,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { subscribeToStories, groupStoriesByAuthor } from '../firebase/stories';
import { getFollowing } from '../firebase/follows';
import { colors, spacing, typography } from '../theme';
import StoryViewer from './StoryViewer';

export default function StoryBar({ onAddStory }) {
  const { user, profile } = useAuth();
  const [storyGroups, setStoryGroups] = useState([]);
  const [viewingGroup, setViewingGroup] = useState(null);

  useEffect(() => {
    if (!user) return;
    getFollowing(user.uid).then((followingIds) => {
      const unsub = subscribeToStories(followingIds, user.uid, (snap) => {
        const stories = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setStoryGroups(groupStoriesByAuthor(stories));
      });
      return unsub;
    });
  }, [user?.uid]);

  const myStories = storyGroups.find((g) => g.authorId === user?.uid);
  const othersStories = storyGroups.filter((g) => g.authorId !== user?.uid);
  const sorted = [...(myStories ? [myStories] : []), ...othersStories];

  return (
    <>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={barStyles.container}
      >
        {/* Add story button */}
        <TouchableOpacity style={barStyles.addStory} onPress={onAddStory}>
          <View style={barStyles.addAvatar}>
            {profile?.photoURL
              ? <Image source={{ uri: profile.photoURL }} style={barStyles.avatarImg} />
              : <View style={barStyles.avatarPlaceholder}>
                  <Text style={barStyles.avatarTxt}>{profile?.displayName?.[0]?.toUpperCase()}</Text>
                </View>
            }
            <View style={barStyles.plusBadge}><Text style={barStyles.plusTxt}>+</Text></View>
          </View>
          <Text style={barStyles.storyName} numberOfLines={1}>Your Story</Text>
        </TouchableOpacity>

        {/* Other stories */}
        {sorted.filter(g => g.authorId !== user?.uid).map((group) => {
          const hasUnviewed = group.stories.some((s) => !s.viewedBy?.includes(user?.uid));
          return (
            <TouchableOpacity
              key={group.authorId}
              style={barStyles.storyItem}
              onPress={() => setViewingGroup(group)}
            >
              <View style={[barStyles.ring, hasUnviewed && barStyles.ringActive]}>
                {group.authorPhoto
                  ? <Image source={{ uri: group.authorPhoto }} style={barStyles.avatarImg} />
                  : <View style={barStyles.avatarPlaceholder}>
                      <Text style={barStyles.avatarTxt}>{group.authorName?.[0]?.toUpperCase()}</Text>
                    </View>
                }
              </View>
              <Text style={barStyles.storyName} numberOfLines={1}>
                {group.authorName?.split(' ')[0]}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {viewingGroup && (
        <StoryViewer
          group={viewingGroup}
          onClose={() => setViewingGroup(null)}
          currentUserId={user?.uid}
        />
      )}
    </>
  );
}

const barStyles = StyleSheet.create({
  container: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md, gap: spacing.md },
  addStory: { alignItems: 'center', width: 70 },
  storyItem: { alignItems: 'center', width: 70 },
  addAvatar: { position: 'relative' },
  ring: {
    width: 64, height: 64, borderRadius: 32,
    padding: 2, backgroundColor: colors.border,
    justifyContent: 'center', alignItems: 'center',
  },
  ringActive: {
    backgroundColor: 'transparent',
    borderWidth: 2.5, borderColor: colors.primary,
  },
  avatarImg: { width: 56, height: 56, borderRadius: 28 },
  avatarPlaceholder: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center',
  },
  avatarTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  plusBadge: {
    position: 'absolute', bottom: 0, right: 0,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: colors.background,
  },
  plusTxt: { color: '#fff', fontSize: 14, fontWeight: '700', lineHeight: 16 },
  storyName: { fontSize: typography.fontSize.xs, color: colors.textSecondary, marginTop: 4, textAlign: 'center' },
});

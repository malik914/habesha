// src/firebase/usernames.js
// Handles unique username reservation, validation, and lookup

import {
  doc, getDoc, setDoc, deleteDoc,
  updateDoc, serverTimestamp, runTransaction,
} from 'firebase/firestore';
import { db } from './config';

// ─── VALIDATION ──────────────────────────────────────────────────

const USERNAME_REGEX = /^[a-z0-9_]{3,20}$/;

export const validateUsername = (username) => {
  if (!username) return 'Username is required';
  if (username.length < 3) return 'Username must be at least 3 characters';
  if (username.length > 20) return 'Username must be 20 characters or less';
  if (!USERNAME_REGEX.test(username)) {
    return 'Only lowercase letters, numbers, and underscores allowed';
  }
  const reserved = ['admin', 'habesha', 'support', 'help', 'official', 'mod', 'moderator'];
  if (reserved.includes(username)) return 'This username is reserved';
  return null; // valid
};

// ─── AVAILABILITY ─────────────────────────────────────────────────

/**
 * Check if a username is available
 */
export const isUsernameAvailable = async (username) => {
  const snap = await getDoc(doc(db, 'usernames', username.toLowerCase()));
  return !snap.exists();
};

// ─── CLAIM / RELEASE ──────────────────────────────────────────────

/**
 * Atomically claim a username for a user.
 * Fails if already taken.
 */
export const claimUsername = async (userId, username) => {
  const lower = username.toLowerCase();

  await runTransaction(db, async (tx) => {
    const usernameRef = doc(db, 'usernames', lower);
    const snap = await tx.get(usernameRef);

    if (snap.exists()) {
      throw new Error('Username is already taken');
    }

    // Reserve the username
    tx.set(usernameRef, {
      uid: userId,
      claimedAt: serverTimestamp(),
    });

    // Save to user document
    tx.update(doc(db, 'users', userId), {
      username: lower,
    });
  });
};

/**
 * Release a username (used when changing username)
 */
export const releaseUsername = async (userId, oldUsername) => {
  const lower = oldUsername.toLowerCase();
  const snap = await getDoc(doc(db, 'usernames', lower));
  // Only delete if this user owns it
  if (snap.exists() && snap.data().uid === userId) {
    await deleteDoc(doc(db, 'usernames', lower));
  }
};

/**
 * Change username — release old, claim new atomically
 */
export const changeUsername = async (userId, oldUsername, newUsername) => {
  const newLower = newUsername.toLowerCase();

  await runTransaction(db, async (tx) => {
    const newRef = doc(db, 'usernames', newLower);
    const snap = await tx.get(newRef);

    if (snap.exists() && snap.data().uid !== userId) {
      throw new Error('Username is already taken');
    }

    // Release old username
    if (oldUsername) {
      tx.delete(doc(db, 'usernames', oldUsername.toLowerCase()));
    }

    // Claim new username
    tx.set(newRef, { uid: userId, claimedAt: serverTimestamp() });

    // Update user doc
    tx.update(doc(db, 'users', userId), { username: newLower });
  });
};

/**
 * Look up a user by @username
 */
export const getUserByUsername = async (username) => {
  const lower = username.toLowerCase().replace('@', '');
  const snap = await getDoc(doc(db, 'usernames', lower));
  if (!snap.exists()) return null;
  const { uid } = snap.data();
  const userSnap = await getDoc(doc(db, 'users', uid));
  return userSnap.exists() ? { id: userSnap.id, ...userSnap.data() } : null;
};

// src/firebase/auth.js
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
  onAuthStateChanged,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './config';

// Register new user
export const registerUser = async ({ email, password, displayName }) => {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, { displayName });

  // Create user profile in Firestore
  await setDoc(doc(db, 'users', cred.user.uid), {
    uid: cred.user.uid,
    displayName,
    displayNameLower: displayName.toLowerCase(), // enables search
    email,
    photoURL: null,
    bio: '',
    interests: [],
    joinedGroups: [],
    followersCount: 0,
    followingCount: 0,
    onboardingComplete: false,
    createdAt: serverTimestamp(),
  });

  return cred.user;
};

// Login
export const loginUser = ({ email, password }) =>
  signInWithEmailAndPassword(auth, email, password);

// Logout
export const logoutUser = () => signOut(auth);

// Password reset
export const resetPassword = (email) =>
  sendPasswordResetEmail(auth, email);

// Fetch user profile from Firestore
export const fetchUserProfile = async (uid) => {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? snap.data() : null;
};

// Auth state listener
export const onAuthChange = (callback) =>
  onAuthStateChanged(auth, callback);

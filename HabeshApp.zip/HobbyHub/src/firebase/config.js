// src/firebase/config.js — Habesha App (Premium Account)
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey:            "AIzaSyAB6xhQCsfEeZ0MoU-u_LfD-SsfggZTfBU",
  authDomain:        "habesha-8e0cb.firebaseapp.com",
  projectId:         "habesha-8e0cb",
  storageBucket:     "habesha-8e0cb.firebasestorage.app",
  messagingSenderId: "752525870447",
  appId:             "1:752525870447:web:b7ed0e2d70c634e793d49a"
};

const app = initializeApp(firebaseConfig);

export const auth    = getAuth(app);
export const db      = getFirestore(app);
export const storage = getStorage(app);

export default app;

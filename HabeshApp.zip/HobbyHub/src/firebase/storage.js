// src/firebase/storage.js
import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { getApp } from 'firebase/app';

const storage = getStorage(getApp());

/**
 * Upload an image to Firebase Storage with progress callback.
 * @param {string} uri        - Local file URI from expo-image-picker
 * @param {string} path       - Storage path e.g. 'avatars/userId.jpg'
 * @param {function} onProgress - Called with 0–100 progress value
 * @returns {Promise<string>} Download URL
 */
export const uploadImage = (uri, path, onProgress) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Convert URI to blob
      const response = await fetch(uri);
      const blob = await response.blob();

      const storageRef = ref(storage, path);
      const uploadTask = uploadBytesResumable(storageRef, blob);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          onProgress?.(Math.round(progress));
        },
        (error) => reject(error),
        async () => {
          const url = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(url);
        }
      );
    } catch (err) {
      reject(err);
    }
  });
};

/**
 * Upload profile avatar
 */
export const uploadAvatar = (userId, uri, onProgress) =>
  uploadImage(uri, `avatars/${userId}.jpg`, onProgress);

/**
 * Upload post image
 */
export const uploadPostImage = (userId, uri, onProgress) => {
  const filename = `${Date.now()}.jpg`;
  return uploadImage(uri, `posts/${userId}/${filename}`, onProgress);
};

/**
 * Delete a file from storage by its full URL
 */
export const deleteImageByUrl = async (url) => {
  try {
    const fileRef = ref(storage, url);
    await deleteObject(fileRef);
  } catch (e) {
    console.warn('Could not delete image:', e.message);
  }
};

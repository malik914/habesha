// src/firebase/bookmarks.js
import {
  doc, setDoc, deleteDoc, getDoc,
  collection, query, where, orderBy, onSnapshot, serverTimestamp,
} from 'firebase/firestore';
import { db } from './config';

/**
 * Toggle bookmark on a post
 */
export const toggleBookmark = async (userId, postId) => {
  const ref = doc(db, 'users', userId, 'bookmarks', postId);
  const snap = await getDoc(ref);
  if (snap.exists()) {
    await deleteDoc(ref);
    return false; // removed
  } else {
    await setDoc(ref, { postId, savedAt: serverTimestamp() });
    return true; // added
  }
};

/**
 * Check if a post is bookmarked by user
 */
export const isBookmarked = async (userId, postId) => {
  const snap = await getDoc(doc(db, 'users', userId, 'bookmarks', postId));
  return snap.exists();
};

/**
 * Subscribe to user's bookmarks in real-time
 */
export const subscribeToBookmarks = (userId, callback) => {
  const q = query(
    collection(db, 'users', userId, 'bookmarks'),
    orderBy('savedAt', 'desc'),
  );
  return onSnapshot(q, callback);
};


// ─── BookmarksScreen ──────────────────────────────────────────────
// src/screens/Main/BookmarksScreen.jsx
import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, SafeAreaView,
  ActivityIndicator, TouchableOpacity,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { subscribeToBookmarks } from '../firebase/bookmarks';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/config';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

export function BookmarksScreen({ navigation }) {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToBookmarks(user.uid, async (snap) => {
      const bookmarkIds = snap.docs.map((d) => d.data().postId);
      const postPromises = bookmarkIds.map((id) => getDoc(doc(db, 'posts', id)));
      const postSnaps = await Promise.all(postPromises);
      const fetched = postSnaps
        .filter((s) => s.exists())
        .map((s) => ({ id: s.id, ...s.data() }));
      setPosts(fetched);
      setLoading(false);
    });
    return unsub;
  }, [user]);

  return (
    <SafeAreaView style={bs.container}>
      <View style={bs.header}>
        <Text style={bs.title}>Bookmarks</Text>
        <Text style={bs.count}>{posts.length} saved</Text>
      </View>
      {loading ? (
        <ActivityIndicator style={{ marginTop: 60 }} color={colors.primary} />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={bs.card} activeOpacity={0.8}>
              <View style={bs.cardHeader}>
                <View style={bs.avatar}>
                  <Text style={bs.avatarTxt}>{item.authorName?.[0]?.toUpperCase()}</Text>
                </View>
                <View>
                  <Text style={bs.authorName}>{item.authorName}</Text>
                  {item.authorUsername && <Text style={bs.username}>@{item.authorUsername}</Text>}
                </View>
                <Text style={bs.bookmark}>🔖</Text>
              </View>
              <Text style={bs.content} numberOfLines={3}>{item.content}</Text>
            </TouchableOpacity>
          )}
          contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}
          ListEmptyComponent={
            <View style={bs.empty}>
              <Text style={bs.emptyEmoji}>🔖</Text>
              <Text style={bs.emptyTitle}>No bookmarks yet</Text>
              <Text style={bs.emptySubtitle}>Tap the bookmark icon on any post to save it here</Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const bs = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  title: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  count: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  card: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, ...shadows.sm },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.md },
  avatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontWeight: '700' },
  authorName: { fontWeight: typography.fontWeight.semibold, color: colors.textPrimary },
  username: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  bookmark: { marginLeft: 'auto', fontSize: 18 },
  content: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 22 },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyEmoji: { fontSize: 56, marginBottom: spacing.lg },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  emptySubtitle: { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.sm, paddingHorizontal: spacing.xl },
});


// ─── Verified Badge ───────────────────────────────────────────────
// src/components/VerifiedBadge.jsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

/**
 * VerifiedBadge — drop next to any username
 * size: 'sm' | 'md' | 'lg'
 */
export function VerifiedBadge({ size = 'md' }) {
  const fontSize = size === 'sm' ? 12 : size === 'lg' ? 20 : 15;
  return <Text style={{ fontSize }}>✅</Text>;
}

/**
 * Firestore: add verified:true to user document to grant badge
 * Only done server-side / by admin — cannot be self-granted
 *
 * Firebase Security Rule to protect this field:
 *
 * match /users/{userId} {
 *   allow update: if request.auth.uid == userId
 *     && !request.resource.data.diff(resource.data).affectedKeys().hasAny(['verified']);
 * }
 */

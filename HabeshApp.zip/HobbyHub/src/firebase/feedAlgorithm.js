// src/firebase/feedAlgorithm.js — Real-time v2
// Smart feed that re-scores live when new posts arrive

import {
  collection, query, where, orderBy, limit,
  getDocs, onSnapshot, Timestamp,
} from 'firebase/firestore';
import { db } from './config';
import { getFollowing } from './follows';

// ─── SCORING WEIGHTS ───────────────────────────────────────────────
const W = { follow: 0.35, interest: 0.30, engagement: 0.20, recency: 0.15 };

const recencyScore = (createdAt) => {
  if (!createdAt?.toDate) return 0.5;
  const ageH = (Date.now() - createdAt.toDate().getTime()) / 3_600_000;
  return Math.max(0, 1 - ageH / 72);
};

const engagementScore = (likes = [], commentCount = 0) => {
  const total = (likes.length || 0) + (commentCount || 0);
  return total === 0 ? 0 : Math.min(1, Math.log10(total + 1) / 2);
};

const interestScore = (post, interests = []) => {
  const topic = post.groupTopic?.toLowerCase() || '';
  return interests.map((i) => i.toLowerCase()).includes(topic) ? 1.0 : 0.1;
};

export const scorePost = (post, { followingIds = [], userInterests = [] }) => {
  const score =
    (followingIds.includes(post.authorId) ? 1.0 : 0.0) * W.follow +
    interestScore(post, userInterests)                              * W.interest +
    engagementScore(post.likes, post.commentCount)                 * W.engagement +
    recencyScore(post.createdAt)                                   * W.recency;

  return { ...post, _score: Math.round(score * 100) };
};

// ─── ONE-TIME SMART FEED ───────────────────────────────────────────
export const getSmartFeed = async ({ userId, userInterests = [], joinedGroups = [], limitCount = 30 }) => {
  const followingIds = await getFollowing(userId);
  const cutoff = Timestamp.fromMillis(Date.now() - 7 * 86_400_000);
  const promises = [];

  if (joinedGroups.length > 0) {
    for (let i = 0; i < joinedGroups.length; i += 10) {
      promises.push(getDocs(query(
        collection(db, 'posts'),
        where('groupId', 'in', joinedGroups.slice(i, i + 10)),
        where('createdAt', '>=', cutoff),
        orderBy('createdAt', 'desc'),
        limit(50),
      )));
    }
  }

  if (followingIds.length > 0) {
    for (let i = 0; i < followingIds.length; i += 10) {
      promises.push(getDocs(query(
        collection(db, 'posts'),
        where('authorId', 'in', followingIds.slice(i, i + 10)),
        where('createdAt', '>=', cutoff),
        orderBy('createdAt', 'desc'),
        limit(50),
      )));
    }
  }

  if (promises.length === 0) {
    promises.push(getDocs(query(
      collection(db, 'posts'),
      where('createdAt', '>=', cutoff),
      orderBy('createdAt', 'desc'),
      limit(50),
    )));
  }

  const results = await Promise.all(promises);
  const seen = new Set();
  const all = [];
  for (const snap of results) {
    for (const d of snap.docs) {
      if (!seen.has(d.id)) { seen.add(d.id); all.push({ id: d.id, ...d.data() }); }
    }
  }
  return all
    .map((p) => scorePost(p, { followingIds, userInterests }))
    .sort((a, b) => b._score - a._score)
    .slice(0, limitCount);
};

// ─── ✅ REAL-TIME SMART FEED ───────────────────────────────────────
/**
 * Subscribes to live feed updates. Re-scores on every change.
 * Returns unsubscribe function.
 */
export const subscribeToSmartFeed = async (
  { userId, userInterests = [], joinedGroups = [], limitCount = 30 },
  callback
) => {
  const followingIds = await getFollowing(userId);
  const cutoff = Timestamp.fromMillis(Date.now() - 7 * 86_400_000);

  const seen = new Map(); // postId → post data (from all subscriptions)
  const unsubs = [];

  const recompute = () => {
    const all = Array.from(seen.values());
    const scored = all
      .map((p) => scorePost(p, { followingIds, userInterests }))
      .sort((a, b) => b._score - a._score)
      .slice(0, limitCount);
    callback(scored);
  };

  const makeHandler = (snap) => {
    snap.docs.forEach((d) => seen.set(d.id, { id: d.id, ...d.data() }));
    recompute();
  };

  // Subscribe to joined groups
  if (joinedGroups.length > 0) {
    for (let i = 0; i < joinedGroups.length; i += 10) {
      const q = query(
        collection(db, 'posts'),
        where('groupId', 'in', joinedGroups.slice(i, i + 10)),
        where('createdAt', '>=', cutoff),
        orderBy('createdAt', 'desc'),
        limit(50),
      );
      unsubs.push(onSnapshot(q, makeHandler));
    }
  }

  // Subscribe to followed users' posts
  if (followingIds.length > 0) {
    for (let i = 0; i < followingIds.length; i += 10) {
      const q = query(
        collection(db, 'posts'),
        where('authorId', 'in', followingIds.slice(i, i + 10)),
        where('createdAt', '>=', cutoff),
        orderBy('createdAt', 'desc'),
        limit(50),
      );
      unsubs.push(onSnapshot(q, makeHandler));
    }
  }

  // Fallback for new users
  if (unsubs.length === 0) {
    const q = query(
      collection(db, 'posts'),
      where('createdAt', '>=', cutoff),
      orderBy('createdAt', 'desc'),
      limit(50),
    );
    unsubs.push(onSnapshot(q, makeHandler));
  }

  // Return combined unsubscribe
  return () => unsubs.forEach((u) => u());
};

// ─── ✅ REAL-TIME TRENDING ─────────────────────────────────────────
export const subscribeToTrending = (callback, limitCount = 20) => {
  const cutoff = Timestamp.fromMillis(Date.now() - 48 * 3_600_000);
  const q = query(
    collection(db, 'posts'),
    where('createdAt', '>=', cutoff),
    orderBy('createdAt', 'desc'),
    limit(100),
  );
  return onSnapshot(q, (snap) => {
    const posts = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    const trending = posts
      .map((p) => ({
        ...p,
        _trendScore: (p.likes?.length || 0) * 2 + (p.commentCount || 0) * 3 + (p.viewCount || 0) * 0.5,
      }))
      .sort((a, b) => b._trendScore - a._trendScore)
      .slice(0, limitCount);
    callback(trending);
  });
};

// One-time trending (kept for backwards compat)
export const getTrendingPosts = async (limitCount = 20) => {
  const cutoff = Timestamp.fromMillis(Date.now() - 48 * 3_600_000);
  const snap = await getDocs(query(
    collection(db, 'posts'),
    where('createdAt', '>=', cutoff),
    orderBy('createdAt', 'desc'),
    limit(100),
  ));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
    .map((p) => ({ ...p, _trendScore: (p.likes?.length || 0) * 2 + (p.commentCount || 0) * 3 }))
    .sort((a, b) => b._trendScore - a._trendScore)
    .slice(0, limitCount);
};

// src/firebase/hashtags.js
import {
  collection, doc, setDoc, getDoc, getDocs,
  query, orderBy, limit, where, increment,
  updateDoc, serverTimestamp, runTransaction,
} from 'firebase/firestore';
import { db } from './config';

// ─── PARSING ─────────────────────────────────────────────────────

/**
 * Extract hashtags from post content
 * e.g. "Love #photography and #travel!" → ['photography', 'travel']
 */
export const extractHashtags = (text = '') => {
  const matches = text.match(/#([a-zA-Z0-9_]+)/g) || [];
  return [...new Set(matches.map((h) => h.slice(1).toLowerCase()))];
};

/**
 * Render post text with tappable hashtags
 * Returns array of { type: 'text'|'hashtag', value }
 */
export const parseTextWithHashtags = (text = '') => {
  const parts = text.split(/(#[a-zA-Z0-9_]+)/g);
  return parts.map((part) => ({
    type: part.startsWith('#') ? 'hashtag' : 'text',
    value: part,
  }));
};

// ─── FIRESTORE ────────────────────────────────────────────────────

/**
 * Register hashtags used in a post.
 * Increments usage count in a `hashtags` collection.
 */
export const registerHashtags = async (postId, hashtags) => {
  if (!hashtags.length) return;
  const promises = hashtags.map(async (tag) => {
    const ref = doc(db, 'hashtags', tag);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        count: increment(1),
        lastUsed: serverTimestamp(),
        postIds: [...(snap.data().postIds || []).slice(-99), postId], // keep last 100
      });
    } else {
      await setDoc(ref, {
        tag,
        count: 1,
        lastUsed: serverTimestamp(),
        postIds: [postId],
      });
    }
  });
  await Promise.all(promises);
};

/**
 * Get posts for a specific hashtag
 */
export const getPostsByHashtag = async (tag, limitCount = 30) => {
  const snap = await getDoc(doc(db, 'hashtags', tag.toLowerCase()));
  if (!snap.exists()) return [];
  const postIds = snap.data().postIds || [];
  const recent = postIds.slice(-limitCount).reverse();
  const { getDocs: gd, doc: d } = await import('firebase/firestore');
  const promises = recent.map((id) => getDoc(doc(db, 'posts', id)));
  const snaps = await Promise.all(promises);
  return snaps.filter((s) => s.exists()).map((s) => ({ id: s.id, ...s.data() }));
};

/**
 * Get trending hashtags
 */
export const getTrendingHashtags = (limitCount = 20) =>
  getDocs(query(
    collection(db, 'hashtags'),
    orderBy('lastUsed', 'desc'),
    limit(limitCount),
  )).then((snap) => snap.docs.map((d) => ({ tag: d.id, ...d.data() })));

/**
 * Search hashtags by prefix
 */
export const searchHashtags = (prefix, limitCount = 10) =>
  getDocs(query(
    collection(db, 'hashtags'),
    where('tag', '>=', prefix.toLowerCase()),
    where('tag', '<=', prefix.toLowerCase() + '\uf8ff'),
    orderBy('tag'),
    limit(limitCount),
  )).then((snap) => snap.docs.map((d) => ({ tag: d.id, ...d.data() })));


// ─── HashtagText Component ────────────────────────────────────────
// src/components/HashtagText.jsx
import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { parseTextWithHashtags } from '../firebase/hashtags';
import { colors, typography } from '../theme';

/**
 * Renders post text with tappable blue hashtags.
 * Usage: <HashtagText text={post.content} onHashtagPress={(tag) => navigate} />
 */
export function HashtagText({ text, style, numberOfLines, onHashtagPress }) {
  const parts = parseTextWithHashtags(text);
  return (
    <Text style={style} numberOfLines={numberOfLines}>
      {parts.map((part, i) =>
        part.type === 'hashtag' ? (
          <Text
            key={i}
            style={ht.hashtag}
            onPress={() => onHashtagPress?.(part.value.slice(1))}
          >
            {part.value}
          </Text>
        ) : (
          <Text key={i}>{part.value}</Text>
        )
      )}
    </Text>
  );
}

const ht = StyleSheet.create({
  hashtag: {
    color: colors.primary,
    fontWeight: typography.fontWeight.semibold,
  },
});


// ─── HashtagScreen ────────────────────────────────────────────────
// src/screens/Main/HashtagScreen.jsx
import React, { useEffect, useState } from 'react';
import {
  View, StyleSheet, SafeAreaView, FlatList,
  ActivityIndicator,
} from 'react-native';
import { getPostsByHashtag } from '../firebase/hashtags';
import { useAuth } from '../context/AuthContext';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

export function HashtagScreen({ route, navigation }) {
  const { tag } = route.params;
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    navigation.setOptions({ title: `#${tag}` });
    getPostsByHashtag(tag).then((data) => {
      setPosts(data);
      setLoading(false);
    });
  }, [tag]);

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  return (
    <SafeAreaView style={hs.container}>
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={hs.postCard}>
            <View style={hs.postHeader}>
              <View style={hs.avatar}>
                <Text style={hs.avatarTxt}>{item.authorName?.[0]?.toUpperCase()}</Text>
              </View>
              <View>
                <Text style={hs.authorName}>{item.authorName}</Text>
                {item.authorUsername && <Text style={hs.username}>@{item.authorUsername}</Text>}
              </View>
            </View>
            <HashtagText
              text={item.content}
              style={hs.content}
              onHashtagPress={(t) => navigation.push('Hashtag', { tag: t })}
            />
            <Text style={hs.meta}>❤️ {item.likes?.length || 0} · 💬 {item.commentCount || 0}</Text>
          </View>
        )}
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}
        ListEmptyComponent={
          <View style={hs.empty}>
            <Text style={hs.emptyEmoji}>#️⃣</Text>
            <Text style={hs.emptyTitle}>No posts yet for #{tag}</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const hs = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  postCard: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, ...shadows.sm },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.md },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontWeight: '700' },
  authorName: { fontWeight: typography.fontWeight.semibold, color: colors.textPrimary },
  username: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  content: { fontSize: typography.fontSize.md, color: colors.textPrimary, lineHeight: 22, marginBottom: spacing.sm },
  meta: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyEmoji: { fontSize: 48, marginBottom: spacing.lg },
  emptyTitle: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
});

// src/firebase/reactions.js — Real-time v2
import {
  doc, updateDoc, onSnapshot, arrayUnion, arrayRemove,
} from 'firebase/firestore';
import { db } from './config';

export const REACTIONS = ['❤️', '🔥', '😂', '😮', '😢', '👏'];

export const toggleReaction = async (postId, userId, emoji, currentlyReacted) => {
  const postRef = doc(db, 'posts', postId);
  // Remove from ALL other reactions first (one reaction per user)
  const updates = {};
  for (const e of REACTIONS) {
    if (e !== emoji) {
      updates[`reactions.${e}`] = arrayRemove(userId);
    }
  }
  updates[`reactions.${emoji}`] = currentlyReacted ? arrayRemove(userId) : arrayUnion(userId);
  await updateDoc(postRef, updates);
};

export const getReactionSummary = (reactions = {}) =>
  REACTIONS
    .map((emoji) => ({ emoji, count: reactions[emoji]?.length || 0, users: reactions[emoji] || [] }))
    .filter((r) => r.count > 0)
    .sort((a, b) => b.count - a.count);

export const getUserReaction = (reactions = {}, userId) => {
  for (const emoji of REACTIONS) {
    if (reactions[emoji]?.includes(userId)) return emoji;
  }
  return null;
};

// ✅ REAL-TIME: Live reactions for a single post
export const subscribeToPostReactions = (postId, callback) =>
  onSnapshot(doc(db, 'posts', postId), (snap) => {
    if (snap.exists()) {
      callback({
        reactions:    snap.data().reactions    || {},
        likes:        snap.data().likes        || [],
        commentCount: snap.data().commentCount || 0,
        viewCount:    snap.data().viewCount    || 0,
        shareCount:   snap.data().shareCount   || 0,
      });
    }
  });


// ─── ReactionBar Component ─────────────────────────────────────────
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated, Pressable } from 'react-native';
import { colors, spacing, typography, borderRadius, shadows } from '../theme';

export function ReactionBar({ postId, initialReactions, currentUserId, onReacted }) {
  // Subscribe to live reaction updates
  const [liveReactions, setLiveReactions] = useState(initialReactions || {});
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const [showPicker, setShowPicker] = useState(false);

  useEffect(() => {
    const unsub = subscribeToPostReactions(postId, ({ reactions }) => {
      setLiveReactions(reactions);
    });
    return unsub;
  }, [postId]);

  const myReaction  = getUserReaction(liveReactions, currentUserId);
  const summary     = getReactionSummary(liveReactions);
  const totalCount  = summary.reduce((s, r) => s + r.count, 0);

  const openPicker = () => {
    setShowPicker(true);
    Animated.spring(scaleAnim, { toValue: 1, tension: 200, friction: 12, useNativeDriver: true }).start();
  };

  const closePicker = () => {
    Animated.timing(scaleAnim, { toValue: 0, duration: 120, useNativeDriver: true })
      .start(() => setShowPicker(false));
  };

  const handleReact = async (emoji) => {
    const alreadyReacted = liveReactions[emoji]?.includes(currentUserId);
    closePicker();
    await toggleReaction(postId, currentUserId, emoji, alreadyReacted);
    onReacted?.();
  };

  return (
    <View style={rb.wrap}>
      {showPicker && (
        <>
          <Animated.View style={[rb.picker, { transform: [{ scale: scaleAnim }] }]}>
            {REACTIONS.map((emoji) => (
              <TouchableOpacity
                key={emoji}
                style={[rb.pickerEmoji, myReaction === emoji && rb.pickerEmojiActive]}
                onPress={() => handleReact(emoji)}
              >
                <Text style={rb.pickerEmojiTxt}>{emoji}</Text>
              </TouchableOpacity>
            ))}
          </Animated.View>
          <Pressable style={StyleSheet.absoluteFillObject} onPress={closePicker} />
        </>
      )}

      <View style={rb.row}>
        <Pressable
          onPress={myReaction ? () => handleReact(myReaction) : openPicker}
          onLongPress={openPicker}
          style={rb.reactBtn}
        >
          <Text style={rb.reactIcon}>{myReaction || '🤍'}</Text>
          {totalCount > 0 && (
            <Text style={[rb.reactCount, myReaction && { color: colors.primary, fontWeight: '700' }]}>
              {totalCount}
            </Text>
          )}
        </Pressable>

        {summary.slice(0, 3).map((r) => (
          <View key={r.emoji} style={rb.summaryChip}>
            <Text style={rb.summaryEmoji}>{r.emoji}</Text>
            <Text style={rb.summaryCount}>{r.count}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const rb = StyleSheet.create({
  wrap: { position: 'relative' },
  picker: {
    position: 'absolute', bottom: 44, left: 0,
    flexDirection: 'row', gap: 4,
    backgroundColor: colors.surfaceHigh,
    borderRadius: borderRadius.full,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderWidth: 1, borderColor: colors.border,
    ...shadows.lg, zIndex: 100,
  },
  pickerEmoji: { padding: spacing.sm, borderRadius: borderRadius.full },
  pickerEmojiActive: { backgroundColor: colors.primaryGlow },
  pickerEmojiTxt: { fontSize: 26 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  reactBtn: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  reactIcon: { fontSize: 20 },
  reactCount: { fontSize: typography.fontSize.sm, color: colors.textSecondary },
  summaryChip: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  summaryEmoji: { fontSize: 14 },
  summaryCount: { fontSize: typography.fontSize.xs, color: colors.textMuted },
});

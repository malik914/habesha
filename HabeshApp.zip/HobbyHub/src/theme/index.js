// src/theme/index.js  — Habesha Premium Theme v2
// Aesthetic: Midnight Luxury — deep navy, electric coral, warm gold

export const colors = {
  primary:       '#FF4D6D',
  primaryDark:   '#C9184A',
  primaryLight:  '#FF758F',
  primaryGlow:   'rgba(255, 77, 109, 0.25)',
  accent:        '#FFB703',
  accentLight:   '#FFD166',
  accentGlow:    'rgba(255, 183, 3, 0.2)',
  tertiary:      '#48CAE4',
  tertiaryGlow:  'rgba(72, 202, 228, 0.2)',
  background:    '#0A0A0F',
  surface:       '#12121A',
  surfaceAlt:    '#1A1A26',
  surfaceHigh:   '#222235',
  surfaceGlass:  'rgba(255,255,255,0.05)',
  border:        'rgba(255,255,255,0.08)',
  borderLight:   'rgba(255,255,255,0.14)',
  borderGlow:    'rgba(255, 77, 109, 0.3)',
  textPrimary:   '#F0F0F8',
  textSecondary: '#9898B8',
  textMuted:     '#5A5A7A',
  textInverse:   '#0A0A0F',
  gradientPrimary:   ['#FF4D6D', '#C9184A'],
  gradientGold:      ['#FFB703', '#FF8800'],
  gradientNight:     ['#0A0A0F', '#12121A'],
  gradientCard:      ['#1E1E2E', '#12121A'],
  gradientGlass:     ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)'],
  gradientProfile:   ['#FF4D6D', '#C9184A', '#0A0A0F'],
  success:  '#06D6A0',
  warning:  '#FFB703',
  error:    '#EF233C',
  info:     '#48CAE4',
  topics: {
    photography: '#9B5DE5', cooking: '#F15BB5', gaming: '#00BBF9',
    fitness: '#06D6A0', music: '#FF4D6D', travel: '#FFB703',
    art: '#FF6B6B', reading: '#845EC2', tech: '#48CAE4',
    nature: '#06D6A0', film: '#F72585', sports: '#4CC9F0',
  },
};

export const typography = {
  fontFamily: { display: 'Georgia', body: 'System', mono: 'Courier New' },
  fontSize: { xs: 11, sm: 13, md: 15, lg: 17, xl: 20, xxl: 24, xxxl: 32, display: 42, hero: 54 },
  fontWeight: { regular: '400', medium: '500', semibold: '600', bold: '700', black: '900' },
  lineHeight: { tight: 1.15, normal: 1.5, relaxed: 1.75 },
  letterSpacing: { tight: -1, normal: 0, wide: 1, wider: 2 },
};

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48, huge: 64 };

export const borderRadius = { xs: 4, sm: 8, md: 14, lg: 20, xl: 28, xxl: 36, full: 9999 };

export const shadows = {
  sm:  { shadowColor: '#000', shadowOffset: { width: 0, height: 2  }, shadowOpacity: 0.4, shadowRadius: 8,  elevation: 4  },
  md:  { shadowColor: '#000', shadowOffset: { width: 0, height: 6  }, shadowOpacity: 0.5, shadowRadius: 16, elevation: 8  },
  lg:  { shadowColor: '#000', shadowOffset: { width: 0, height: 12 }, shadowOpacity: 0.6, shadowRadius: 28, elevation: 16 },
  glow:     { shadowColor: '#FF4D6D', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.6, shadowRadius: 20, elevation: 10 },
  goldGlow: { shadowColor: '#FFB703', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.5, shadowRadius: 16, elevation: 8  },
};

export const glass = {
  backgroundColor: 'rgba(255,255,255,0.05)',
  borderWidth: 1,
  borderColor: 'rgba(255,255,255,0.1)',
  borderRadius: borderRadius.xl,
};

export default { colors, typography, spacing, borderRadius, shadows, glass };

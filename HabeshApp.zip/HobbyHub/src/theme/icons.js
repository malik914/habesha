// src/theme/icons.js
// ─────────────────────────────────────────────────────────────────
// SINGLE SOURCE OF TRUTH for all emojis/icons in the app.
// Every screen imports from here — no raw emoji literals scattered around.
// ─────────────────────────────────────────────────────────────────

// ── Navigation Tabs ────────────────────────────────────────────────
export const TAB_ICONS = {
  feed:      '🏡',   // Home/Feed
  explore:   '🧭',   // Explore/Discover
  reels:     '🎞️',   // Reels/Video
  messages:  '✉️',   // Messages/DM
  profile:   '🪪',   // Profile/Identity
};

// ── App Brand ──────────────────────────────────────────────────────
export const BRAND = {
  logo:      '🌟',   // Habesha star
  premium:   '👑',   // Premium badge
  verified:  '✅',   // Verified badge
};

// ── Topics ─────────────────────────────────────────────────────────
export const TOPIC_ICONS = {
  photography: '📷',
  cooking:     '🧑‍🍳',
  gaming:      '🕹️',
  fitness:     '🏃',
  music:       '🎸',
  travel:      '🗺️',
  art:         '🖼️',
  reading:     '📖',
  tech:        '🖥️',
  nature:      '🌳',
  film:        '🎥',
  sports:      '🏅',
  fashion:     '👠',
  pets:        '🐶',
  diy:         '🔧',
  food:        '🍱',
  default:     '✨',   // fallback for unknown topics
};

// ── Post / Feed Actions ────────────────────────────────────────────
export const POST_ACTIONS = {
  like:          '🤍',
  liked:         '❤️',
  comment:       '💬',
  share:         '↗️',
  bookmark:      '🔖',
  bookmarked:    '🔖',
  more:          '⋯',
  report:        '🚩',
};

// ── Reactions ─────────────────────────────────────────────────────
export const REACTIONS = ['❤️', '🔥', '😂', '😮', '😢', '👏'];

// ── Story ─────────────────────────────────────────────────────────
export const STORY = {
  add:     '＋',
  camera:  '📸',
  gallery: '🖼️',
  timer:   '⏱️',
};

// ── Messages ───────────────────────────────────────────────────────
export const MSG_ICONS = {
  send:      '▶',
  attach:    '📎',
  emoji:     '😊',
  new:       '✏️',
  unread:    '🔴',
  read:      '✓✓',
};

// ── Notifications ─────────────────────────────────────────────────
export const NOTIF_ICONS = {
  like:     '❤️',
  comment:  '💬',
  follow:   '🫂',
  message:  '✉️',
  group:    '👥',
  mention:  '💡',
  system:   '🔔',
  default:  '🔔',
};

// ── Profile / Account ─────────────────────────────────────────────
export const PROFILE_ICONS = {
  edit:       '✏️',
  settings:   '⚙️',
  bookmarks:  '🔖',
  followers:  '👥',
  following:  '🫂',
  groups:     '🏘️',
  posts:      '📝',
  logout:     '🚪',
  delete:     '🗑️',
};

// ── Settings ──────────────────────────────────────────────────────
export const SETTINGS_ICONS = {
  account:       '🪪',
  username:      '🏷️',
  password:      '🔐',
  email:         '📧',
  privacy:       '🛡️',
  notifications: '🔔',
  blocked:       '🚫',
  muted:         '🔇',
  appearance:    '🎨',
  theme:         '🌙',
  textSize:      '🔤',
  subscription:  '👑',
  help:          '🆘',
  bug:           '🐛',
  privacy_policy:'📜',
  terms:         '📋',
  version:       'ℹ️',
  signout:       '🚪',
  danger:        '⚡',
};

// ── Feedback / Status ─────────────────────────────────────────────
export const STATUS_ICONS = {
  success:  '✅',
  error:    '❌',
  warning:  '⚠️',
  info:     '💡',
  loading:  '⏳',
  empty:    '🌑',
  offline:  '📵',
  online:   '🟢',
};

// ── Groups ────────────────────────────────────────────────────────
export const GROUP_ICONS = {
  create:   '✨',
  join:     '🚀',
  leave:    '👋',
  admin:    '🛠️',
  public:   '🌍',
  private:  '🔒',
  members:  '👥',
  pin:      '📌',
};

// ── Search ────────────────────────────────────────────────────────
export const SEARCH_ICONS = {
  search:    '🔍',
  clear:     '✕',
  trending:  '🔥',
  hashtag:   '#️⃣',
  people:    '🧑‍🤝‍🧑',
  suggest:   '💫',
};

// ── Paywall ───────────────────────────────────────────────────────
export const PAYWALL_ICONS = {
  premium:     '👑',
  unlock:      '🔓',
  star:        '⭐',
  check:       '✓',
  monthly:     '📅',
  yearly:      '🗓️',
  restore:     '♻️',
};

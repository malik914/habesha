// src/components/Skeleton.jsx — Premium dark v2
import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet } from 'react-native';
import { colors, spacing, borderRadius } from '../theme';

const Shimmer = ({ style }) => {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1, duration: 850, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 850, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return (
    <Animated.View style={[{ backgroundColor: colors.surfaceHigh, borderRadius: borderRadius.sm }, style,
      { opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.3, 0.7] }) }]} />
  );
};

export const PostSkeleton = () => (
  <View style={{ backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, gap: spacing.md, borderWidth: 1, borderColor: colors.border, marginHorizontal: spacing.lg }}>
    <View style={{ flexDirection: 'row', gap: spacing.md, alignItems: 'center' }}>
      <Shimmer style={{ width: 44, height: 44, borderRadius: 22 }} />
      <View style={{ flex: 1, gap: 8 }}>
        <Shimmer style={{ width: '55%', height: 13 }} />
        <Shimmer style={{ width: '35%', height: 10 }} />
      </View>
    </View>
    <Shimmer style={{ width: '100%', height: 14 }} />
    <Shimmer style={{ width: '80%', height: 14 }} />
    <Shimmer style={{ width: '60%', height: 14 }} />
  </View>
);

export const UserSkeleton = () => (
  <View style={{ backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
      <Shimmer style={{ width: 52, height: 52, borderRadius: 26 }} />
      <View style={{ flex: 1, gap: 8 }}>
        <Shimmer style={{ width: '50%', height: 13 }} />
        <Shimmer style={{ width: '30%', height: 10 }} />
      </View>
      <Shimmer style={{ width: 80, height: 32, borderRadius: borderRadius.full }} />
    </View>
  </View>
);

export const StorySkeleton = () => (
  <View style={{ flexDirection: 'row', gap: spacing.md, padding: spacing.md }}>
    {[...Array(5)].map((_, i) => (
      <View key={i} style={{ alignItems: 'center', gap: 6 }}>
        <Shimmer style={{ width: 64, height: 64, borderRadius: 32 }} />
        <Shimmer style={{ width: 48, height: 9 }} />
      </View>
    ))}
  </View>
);

export const FeedSkeleton = () => (
  <View style={{ gap: spacing.md, paddingVertical: spacing.md }}>
    <StorySkeleton />
    {[...Array(3)].map((_, i) => <PostSkeleton key={i} />)}
  </View>
);

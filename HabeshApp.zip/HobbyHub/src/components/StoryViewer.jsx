// src/components/StoryViewer.jsx
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, Image, StyleSheet, TouchableOpacity,
  Dimensions, Animated, Modal, SafeAreaView, StatusBar,
} from 'react-native';
import { markStoryViewed } from '../firebase/stories';

const { width: W, height: H } = Dimensions.get('window');
const STORY_DURATION = 5000; // ms per story

export default function StoryViewer({ group, onClose, currentUserId }) {
  const [index, setIndex] = useState(0);
  const progress = useRef(new Animated.Value(0)).current;
  const animRef = useRef(null);

  const story = group.stories[index];

  useEffect(() => {
    startProgress();
    if (story?.id && currentUserId) {
      markStoryViewed(story.id, currentUserId);
    }
    return () => animRef.current?.stop();
  }, [index]);

  const startProgress = () => {
    progress.setValue(0);
    animRef.current = Animated.timing(progress, {
      toValue: 1,
      duration: STORY_DURATION,
      useNativeDriver: false,
    });
    animRef.current.start(({ finished }) => {
      if (finished) goNext();
    });
  };

  const goNext = () => {
    if (index < group.stories.length - 1) {
      setIndex((i) => i + 1);
    } else {
      onClose();
    }
  };

  const goPrev = () => {
    if (index > 0) setIndex((i) => i - 1);
  };

  if (!story) return null;

  return (
    <Modal visible animationType="fade" statusBarTranslucent>
      <StatusBar hidden />
      <View style={s.container}>
        {/* Background */}
        {story.mediaUrl
          ? <Image source={{ uri: story.mediaUrl }} style={s.bg} resizeMode="cover" />
          : <View style={[s.bg, { backgroundColor: story.backgroundColor || '#1A6B72' }]} />
        }

        {/* Dark overlay for text readability */}
        <View style={s.overlay} />

        {/* Progress bars */}
        <SafeAreaView style={s.progressWrap}>
          <View style={s.progressRow}>
            {group.stories.map((_, i) => (
              <View key={i} style={s.progressBg}>
                <Animated.View
                  style={[
                    s.progressFill,
                    {
                      width: i < index
                        ? '100%'
                        : i === index
                        ? progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] })
                        : '0%',
                    },
                  ]}
                />
              </View>
            ))}
          </View>

          {/* Author header */}
          <View style={s.header}>
            <View style={s.authorRow}>
              {story.authorPhoto
                ? <Image source={{ uri: story.authorPhoto }} style={s.authorAvatar} />
                : <View style={s.authorAvatarFallback}>
                    <Text style={s.authorAvatarTxt}>{story.authorName?.[0]?.toUpperCase()}</Text>
                  </View>
              }
              <View>
                <Text style={s.authorName}>{story.authorName}</Text>
                {story.authorUsername && (
                  <Text style={s.authorUsername}>@{story.authorUsername}</Text>
                )}
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={s.closeBtn}>
              <Text style={s.closeTxt}>✕</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>

        {/* Story text */}
        {story.text && (
          <View style={s.textWrap}>
            <Text style={s.storyText}>{story.text}</Text>
          </View>
        )}

        {/* Tap zones: left = prev, right = next */}
        <TouchableOpacity style={s.tapLeft} onPress={goPrev} activeOpacity={1} />
        <TouchableOpacity style={s.tapRight} onPress={goNext} activeOpacity={1} />
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  bg: { ...StyleSheet.absoluteFillObject },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.25)' },
  progressWrap: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 },
  progressRow: { flexDirection: 'row', gap: 4, paddingHorizontal: 12, paddingTop: 8 },
  progressBg: { flex: 1, height: 2.5, backgroundColor: 'rgba(255,255,255,0.35)', borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#fff', borderRadius: 2 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 10 },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  authorAvatar: { width: 38, height: 38, borderRadius: 19, borderWidth: 2, borderColor: '#fff' },
  authorAvatarFallback: { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.3)', justifyContent: 'center', alignItems: 'center' },
  authorAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 16 },
  authorName: { color: '#fff', fontWeight: '700', fontSize: 14 },
  authorUsername: { color: 'rgba(255,255,255,0.7)', fontSize: 11 },
  closeBtn: { padding: 8 },
  closeTxt: { color: '#fff', fontSize: 18, fontWeight: '700' },
  textWrap: { position: 'absolute', bottom: 80, left: 0, right: 0, alignItems: 'center', paddingHorizontal: 24 },
  storyText: { color: '#fff', fontSize: 22, fontWeight: '700', textAlign: 'center', textShadowColor: 'rgba(0,0,0,0.6)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 },
  tapLeft: { position: 'absolute', left: 0, top: 0, bottom: 0, width: W * 0.35 },
  tapRight: { position: 'absolute', right: 0, top: 0, bottom: 0, width: W * 0.65 },
});

// src/components/OfflineBanner.jsx — Premium dark v2
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Platform } from 'react-native';
import { colors, typography, spacing } from '../theme';
import { STATUS_ICONS } from '../theme/icons';

// Install: npx expo install @react-native-community/netinfo
let NetInfo;
try { NetInfo = require('@react-native-community/netinfo').default; } catch { NetInfo = null; }

export default function OfflineBanner() {
  const [offline, setOffline]   = useState(false);
  const [wasOff, setWasOff]     = useState(false);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!NetInfo) return;
    const unsub = NetInfo.addEventListener((state) => {
      const isOff = !state.isConnected;
      setOffline(isOff);
      if (isOff) setWasOff(true);
    });
    return unsub;
  }, []);

  useEffect(() => {
    const show = offline || (wasOff && !offline);
    Animated.timing(anim, { toValue: show ? 1 : 0, duration: 300, useNativeDriver: true }).start(() => {
      if (!offline && wasOff) {
        setTimeout(() => { Animated.timing(anim, { toValue: 0, duration: 300, useNativeDriver: true }).start(); setWasOff(false); }, 2000);
      }
    });
  }, [offline, wasOff]);

  if (!offline && !wasOff) return null;

  return (
    <Animated.View style={[s.banner, { backgroundColor: offline ? colors.surfaceHigh : colors.success, opacity: anim, transform: [{ translateY: anim.interpolate({ inputRange: [0,1], outputRange: [-50, 0] }) }] }]}>
      <Text style={s.icon}>{offline ? STATUS_ICONS.offline : STATUS_ICONS.success}</Text>
      <Text style={s.txt}>{offline ? 'No internet connection' : 'Back online'}</Text>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  banner: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 9998, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm, paddingVertical: spacing.sm, paddingTop: Platform.OS === 'ios' ? spacing.xl : spacing.sm, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)' },
  icon: { fontSize: 14 },
  txt: { color: colors.textPrimary, fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold },
});

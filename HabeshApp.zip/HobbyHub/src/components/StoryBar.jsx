// src/components/StoryBar.jsx — Premium dark v2
import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  Image, StyleSheet,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { subscribeToStories, groupStoriesByAuthor } from '../firebase/stories';
import { getFollowing } from '../firebase/follows';
import { colors, spacing, typography, borderRadius, shadows } from '../theme';
import { STORY } from '../theme/icons';
import StoryViewer from './StoryViewer';

export default function StoryBar({ onAddStory }) {
  const { user, profile }     = useAuth();
  const [storyGroups, setGroups] = useState([]);
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    if (!user) return;
    getFollowing(user.uid).then((followingIds) => {
      const unsub = subscribeToStories(followingIds, user.uid, (snap) => {
        const stories = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setGroups(groupStoriesByAuthor(stories));
      });
      return unsub;
    });
  }, [user?.uid]);

  const myGroup  = storyGroups.find((g) => g.authorId === user?.uid);
  const others   = storyGroups.filter((g) => g.authorId !== user?.uid);
  const sorted   = [...(myGroup ? [myGroup] : []), ...others];

  return (
    <>
      <View style={s.container}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={s.scroll}
        >
          {/* Add story */}
          <TouchableOpacity style={s.storyItem} onPress={onAddStory} activeOpacity={0.8}>
            <View style={s.addRing}>
              {profile?.photoURL
                ? <Image source={{ uri: profile.photoURL }} style={s.avatarImg} />
                : <View style={[s.avatarFallback, { backgroundColor: colors.primary }]}>
                    <Text style={s.avatarTxt}>{profile?.displayName?.[0]?.toUpperCase()}</Text>
                  </View>
              }
              <View style={s.plusBadge}><Text style={s.plusTxt}>{STORY.add}</Text></View>
            </View>
            <Text style={s.storyName} numberOfLines={1}>Your Story</Text>
          </TouchableOpacity>

          {/* Others' stories */}
          {sorted.filter((g) => g.authorId !== user?.uid).map((group) => {
            const hasUnviewed = group.stories.some((st) => !st.viewedBy?.includes(user?.uid));
            return (
              <TouchableOpacity
                key={group.authorId}
                style={s.storyItem}
                onPress={() => setViewing(group)}
                activeOpacity={0.8}
              >
                <View style={[s.ring, hasUnviewed ? s.ringActive : s.ringViewed]}>
                  {group.authorPhoto
                    ? <Image source={{ uri: group.authorPhoto }} style={s.avatarImg} />
                    : <View style={[s.avatarFallback, { backgroundColor: colors.topics?.[group.authorInterests?.[0]] || colors.primary }]}>
                        <Text style={s.avatarTxt}>{group.authorName?.[0]?.toUpperCase()}</Text>
                      </View>
                  }
                </View>
                <Text style={[s.storyName, hasUnviewed && s.storyNameActive]} numberOfLines={1}>
                  {group.authorName?.split(' ')[0]}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {viewing && (
        <StoryViewer
          group={viewing}
          onClose={() => setViewing(null)}
          currentUserId={user?.uid}
        />
      )}
    </>
  );
}

const AVATAR_SIZE = 58;

const s = StyleSheet.create({
  container: { backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  scroll: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md, gap: spacing.md },
  storyItem: { alignItems: 'center', width: 72 },
  addRing: { position: 'relative', width: AVATAR_SIZE + 6, height: AVATAR_SIZE + 6, borderRadius: (AVATAR_SIZE + 6) / 2, borderWidth: 2, borderColor: colors.border, justifyContent: 'center', alignItems: 'center' },
  ring: { width: AVATAR_SIZE + 6, height: AVATAR_SIZE + 6, borderRadius: (AVATAR_SIZE + 6) / 2, borderWidth: 2.5, justifyContent: 'center', alignItems: 'center' },
  ringActive: { borderColor: colors.primary },
  ringViewed: { borderColor: colors.border },
  avatarImg: { width: AVATAR_SIZE, height: AVATAR_SIZE, borderRadius: AVATAR_SIZE / 2 },
  avatarFallback: { width: AVATAR_SIZE, height: AVATAR_SIZE, borderRadius: AVATAR_SIZE / 2, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontWeight: '700', fontSize: 22 },
  plusBadge: {
    position: 'absolute', bottom: -1, right: -1,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: colors.surface,
  },
  plusTxt: { color: '#fff', fontSize: 16, fontWeight: '900', lineHeight: 20 },
  storyName: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 5, textAlign: 'center' },
  storyNameActive: { color: colors.textSecondary, fontWeight: '600' },
});

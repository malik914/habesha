// src/components/UsernamePicker.jsx — v2 with icon registry
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, StyleSheet, ActivityIndicator } from 'react-native';
import { validateUsername, isUsernameAvailable } from '../firebase/usernames';
import { colors, typography, spacing, borderRadius } from '../theme';

const STATUS_ICON = { available: '✅', taken: '❌', invalid: '⚠️', checking: null, idle: null };
const STATUS_COLOR = {
  available: colors.success,
  taken:     '#EF233C',
  invalid:   '#FFB703',
  checking:  colors.border,
  idle:      colors.border,
};

export default function UsernamePicker({ value, onChange }) {
  const [status, setStatus]   = useState('idle');
  const [errMsg, setErrMsg]   = useState('');
  const debounce              = useRef(null);

  useEffect(() => {
    if (!value) { setStatus('idle'); setErrMsg(''); onChange?.('', false); return; }

    const validErr = validateUsername(value);
    if (validErr) { setStatus('invalid'); setErrMsg(validErr); onChange?.(value, false); return; }

    setStatus('checking');
    clearTimeout(debounce.current);
    debounce.current = setTimeout(async () => {
      try {
        const avail = await isUsernameAvailable(value);
        setStatus(avail ? 'available' : 'taken');
        setErrMsg(avail ? '' : 'Username already taken');
        onChange?.(value, avail);
      } catch { setStatus('idle'); }
    }, 500);

    return () => clearTimeout(debounce.current);
  }, [value]);

  const borderColor = STATUS_COLOR[status];
  const icon        = STATUS_ICON[status];

  return (
    <View style={s.wrap}>
      <View style={[s.row, { borderColor }]}>
        <Text style={s.at}>@</Text>
        <TextInput
          style={s.input}
          value={value}
          onChangeText={(t) => onChange?.(t.toLowerCase().replace(/[^a-z0-9_]/g, ''), false)}
          placeholder="yourhandle"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
          maxLength={20}
        />
        <View style={s.statusWrap}>
          {status === 'checking'
            ? <ActivityIndicator size="small" color={colors.textMuted} />
            : icon ? <Text style={{ fontSize: 18 }}>{icon}</Text> : null
          }
        </View>
      </View>

      <View style={s.hint}>
        {status === 'available' && <Text style={[s.hintTxt, { color: colors.success }]}>✅ @{value} is available!</Text>}
        {(status === 'taken' || status === 'invalid') && <Text style={[s.hintTxt, { color: STATUS_COLOR[status] }]}>{errMsg}</Text>}
        {status === 'idle' && <Text style={s.hintTxt}>3–20 chars · letters, numbers, underscores only</Text>}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { gap: spacing.xs },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceAlt, borderWidth: 2, borderRadius: borderRadius.md, paddingHorizontal: spacing.md },
  at: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.black, color: colors.primary, marginRight: 2 },
  input: { flex: 1, paddingVertical: spacing.md, fontSize: typography.fontSize.lg, color: colors.textPrimary, fontWeight: typography.fontWeight.medium },
  statusWrap: { width: 28, alignItems: 'center' },
  hint: { minHeight: 18 },
  hintTxt: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginLeft: spacing.sm },
});

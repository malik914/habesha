// src/components/Toast.jsx — Premium dark v2
import React, { createContext, useContext, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity, Platform } from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';
import { STATUS_ICONS } from '../theme/icons';

const BG    = { success: '#06D6A0', error: '#EF233C', info: '#48CAE4', warning: '#FFB703' };
const ICONS = { success: STATUS_ICONS.success, error: STATUS_ICONS.error, info: STATUS_ICONS.info, warning: STATUS_ICONS.warning };
const ToastCtx = createContext(null);

const ToastItem = ({ toast, onDismiss }) => {
  const anim = useRef(new Animated.Value(0)).current;
  React.useEffect(() => {
    Animated.spring(anim, { toValue: 1, tension: 220, friction: 14, useNativeDriver: true }).start();
  }, []);
  return (
    <Animated.View style={[s.toast, { backgroundColor: BG[toast.type] || BG.info },
      { transform: [{ translateY: anim.interpolate({ inputRange: [0,1], outputRange: [-24, 0] }) }], opacity: anim }]}>
      <Text style={s.icon}>{ICONS[toast.type]}</Text>
      <Text style={s.msg} numberOfLines={2}>{toast.message}</Text>
      <TouchableOpacity onPress={onDismiss} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Text style={s.dismiss}>✕</Text>
      </TouchableOpacity>
    </Animated.View>
  );
};

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  const show = (message, type = 'success', duration = 3000) => {
    const id = Date.now();
    setToasts((p) => [...p, { id, message, type }]);
    setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), duration);
  };
  const dismiss = (id) => setToasts((p) => p.filter((t) => t.id !== id));
  return (
    <ToastCtx.Provider value={{ show }}>
      {children}
      <View style={s.container} pointerEvents="box-none">
        {toasts.map((t) => <ToastItem key={t.id} toast={t} onDismiss={() => dismiss(t.id)} />)}
      </View>
    </ToastCtx.Provider>
  );
};

export const useToast = () => {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('useToast must be inside ToastProvider');
  return ctx;
};

const s = StyleSheet.create({
  container: { position: 'absolute', top: Platform.OS === 'ios' ? 60 : 40, left: spacing.lg, right: spacing.lg, zIndex: 9999, gap: spacing.sm, pointerEvents: 'box-none' },
  toast: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderRadius: borderRadius.lg, ...shadows.lg },
  icon: { fontSize: 18 },
  msg: { flex: 1, color: '#fff', fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold, lineHeight: 20 },
  dismiss: { color: 'rgba(255,255,255,0.7)', fontSize: 14 },
});

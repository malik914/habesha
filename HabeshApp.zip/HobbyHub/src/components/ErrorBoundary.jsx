// src/components/ErrorBoundary.jsx
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { colors, typography, spacing, borderRadius } from '../theme';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // Log to your crash reporting service here
    console.error('ErrorBoundary caught:', error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <SafeAreaView style={s.container}>
          <View style={s.content}>
            <Text style={s.emoji}>😵</Text>
            <Text style={s.title}>Something went wrong</Text>
            <Text style={s.subtitle}>
              Habesha hit an unexpected error. We're sorry about that!
            </Text>
            {__DEV__ && (
              <View style={s.errorBox}>
                <Text style={s.errorText} numberOfLines={6}>
                  {this.state.error?.message}
                </Text>
              </View>
            )}
            <TouchableOpacity style={s.btn} onPress={this.handleReset}>
              <Text style={s.btnText}>Try Again</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      );
    }
    return this.props.children;
  }
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: spacing.xl, gap: spacing.lg },
  emoji: { fontSize: 72 },
  title: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, textAlign: 'center' },
  subtitle: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 24 },
  errorBox: { backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.md, padding: spacing.lg, width: '100%' },
  errorText: { fontFamily: 'Courier New', fontSize: 11, color: colors.error },
  btn: { backgroundColor: colors.primary, paddingVertical: spacing.lg, paddingHorizontal: spacing.xxxl, borderRadius: borderRadius.lg },
  btnText: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.lg },
});

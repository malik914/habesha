// src/components/UserCard.jsx — Premium v2
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator, Animated,
} from 'react-native';
import { followUser, unfollowUser, isFollowing } from '../firebase/follows';
import { colors, typography, spacing, borderRadius, shadows } from '../theme';

export default function UserCard({ user, currentUserId, currentUserName, onPress, showBio = true }) {
  const [following, setFollowing] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [toggling, setToggling] = useState(false);
  const btnScale = useRef(new Animated.Value(1)).current;

  const userId = user?.uid || user?.id;
  const displayName = user?.displayName || 'Unknown';
  const photoURL = user?.photoURL;
  const bio = user?.bio;
  const interests = user?.interests || [];
  const followersCount = user?.followersCount || 0;
  const topicColor = colors.topics[interests[0]] || colors.primary;

  useEffect(() => {
    if (!currentUserId || !userId) return;
    isFollowing(currentUserId, userId).then(setFollowing).finally(() => setLoadingStatus(false));
  }, [currentUserId, userId]);

  const handleToggle = async () => {
    if (toggling) return;
    // Button bounce
    Animated.sequence([
      Animated.spring(btnScale, { toValue: 0.88, tension: 400, useNativeDriver: true }),
      Animated.spring(btnScale, { toValue: 1,    tension: 400, useNativeDriver: true }),
    ]).start();

    setToggling(true);
    try {
      if (following) {
        await unfollowUser(currentUserId, userId);
        setFollowing(false);
      } else {
        await followUser(currentUserId, currentUserName, userId);
        setFollowing(true);
      }
    } catch (e) { console.error(e); }
    finally { setToggling(false); }
  };

  return (
    <TouchableOpacity style={s.card} onPress={onPress} activeOpacity={0.82}>
      {/* Accent strip */}
      <View style={[s.accentStrip, { backgroundColor: topicColor }]} />

      <View style={s.inner}>
        {/* Avatar */}
        <View style={s.avatarWrap}>
          {photoURL
            ? <Image source={{ uri: photoURL }} style={s.avatar} />
            : <View style={[s.avatarFallback, { backgroundColor: topicColor }]}>
                <Text style={s.avatarTxt}>{displayName[0]?.toUpperCase()}</Text>
              </View>
          }
          {user?.verified && (
            <View style={s.verifiedBadge}><Text style={{ fontSize: 10 }}>✅</Text></View>
          )}
        </View>

        {/* Info */}
        <View style={s.info}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.xs }}>
            <Text style={s.name} numberOfLines={1}>{displayName}</Text>
            {user?.isPremium && <Text style={{ fontSize: 12 }}>👑</Text>}
          </View>
          {user?.username && <Text style={s.username}>@{user.username}</Text>}
          {showBio && bio
            ? <Text style={s.bio} numberOfLines={1}>{bio}</Text>
            : <Text style={s.followers}>{followersCount} {followersCount === 1 ? 'follower' : 'followers'}</Text>
          }
          {interests.length > 0 && (
            <View style={s.tags}>
              {interests.slice(0, 3).map((tag) => {
                const c = colors.topics[tag] || colors.primary;
                return (
                  <View key={tag} style={[s.tag, { backgroundColor: c + '20' }]}>
                    <Text style={[s.tagTxt, { color: c }]}>{tag}</Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* Follow button */}
        {currentUserId !== userId && (
          <Animated.View style={{ transform: [{ scale: btnScale }] }}>
            <TouchableOpacity
              style={[s.followBtn, following && s.followingBtn]}
              onPress={handleToggle}
              disabled={loadingStatus || toggling}
              activeOpacity={0.8}
            >
              {(loadingStatus || toggling)
                ? <ActivityIndicator size="small" color={following ? colors.textSecondary : '#fff'} />
                : <Text style={[s.followBtnTxt, following && s.followingBtnTxt]}>
                    {following ? '✓ Following' : '+ Follow'}
                  </Text>
              }
            </TouchableOpacity>
          </Animated.View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    borderWidth: 1, borderColor: colors.border,
    ...shadows.sm,
  },
  accentStrip: { height: 3 },
  inner: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  avatarWrap: { position: 'relative', flexShrink: 0 },
  avatar: { width: 52, height: 52, borderRadius: 26 },
  avatarFallback: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontSize: 20, fontWeight: '700' },
  verifiedBadge: { position: 'absolute', bottom: -2, right: -2, width: 18, height: 18, borderRadius: 9, backgroundColor: colors.surface, justifyContent: 'center', alignItems: 'center' },
  info: { flex: 1, gap: 3 },
  name: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  username: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  bio: { fontSize: typography.fontSize.sm, color: colors.textSecondary },
  followers: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: 4 },
  tag: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: borderRadius.full },
  tagTxt: { fontSize: 10, fontWeight: '600', textTransform: 'capitalize' },
  followBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: borderRadius.full, minWidth: 88, alignItems: 'center', ...shadows.glow },
  followingBtn: { backgroundColor: colors.surfaceHigh, borderWidth: 1, borderColor: colors.border },
  followBtnTxt: { color: '#fff', fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.bold },
  followingBtnTxt: { color: colors.textSecondary },
});

// src/screens/Groups/GroupsDiscoverScreen.jsx — Real-time v2
import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, TextInput,
  StyleSheet, SafeAreaView, ActivityIndicator, Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { subscribeToGroups, joinGroup, leaveGroup } from '../../firebase/firestore';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TOPIC_ICONS, GROUP_ICONS } from '../../theme/icons';
import { haptic } from '../../utils/haptics';

export default function GroupsDiscoverScreen({ navigation }) {
  const { user, profile, refreshProfile } = useAuth();
  // ✅ REAL-TIME: Live group list (member counts update as people join)
  const [groups, setGroups]   = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch]   = useState('');
  const [loading, setL]       = useState(true);
  const [joining, setJoining] = useState(null);

  useEffect(() => {
    const unsub = subscribeToGroups((data) => {
      setGroups(data);
      setFiltered(data);
      setL(false);
    });
    return unsub;
  }, []);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(groups.filter((g) =>
      !q || g.name?.toLowerCase().includes(q) || g.topic?.toLowerCase().includes(q)
    ));
  }, [search, groups]);

  const handleToggle = async (group) => {
    const joined = profile?.joinedGroups?.includes(group.id);
    setJoining(group.id);
    haptic.medium();
    try {
      if (joined) { await leaveGroup(group.id, user.uid); }
      else        { await joinGroup(group.id, user.uid); haptic.success(); }
      await refreshProfile();
    } catch (e) { haptic.error(); }
    finally { setJoining(null); }
  };

  const GroupCard = ({ group }) => {
    const joined     = profile?.joinedGroups?.includes(group.id);
    const topicColor = colors.topics?.[group.topic?.toLowerCase()] || colors.primary;
    const topicIcon  = TOPIC_ICONS[group.topic?.toLowerCase()] || TOPIC_ICONS.default;
    const isJoining  = joining === group.id;

    return (
      <TouchableOpacity
        style={[s.card, { borderTopColor: topicColor, borderTopWidth: 3 }]}
        onPress={() => navigation.navigate('GroupDetail', { groupId: group.id, group })}
        activeOpacity={0.85}
      >
        <View style={[s.cover, { backgroundColor: topicColor + '18' }]}>
          <Text style={s.coverEmoji}>{topicIcon}</Text>
          <View style={[s.badge, { backgroundColor: topicColor }]}>
            <Text style={s.badgeTxt}>{group.topic}</Text>
          </View>
        </View>
        <View style={s.cardBody}>
          <Text style={s.groupName} numberOfLines={1}>{group.name}</Text>
          <Text style={s.groupDesc} numberOfLines={2}>{group.description}</Text>
          <View style={s.cardFooter}>
            {/* Live member count from real-time subscription */}
            <Text style={s.memberCount}>{GROUP_ICONS.members} {group.memberCount || 0} members</Text>
            <TouchableOpacity
              style={[s.joinBtn, joined && s.joinedBtn]}
              onPress={() => handleToggle(group)}
              disabled={!!isJoining}
            >
              {isJoining
                ? <ActivityIndicator size="small" color={joined ? colors.textSecondary : '#fff'} />
                : <Text style={[s.joinBtnTxt, joined && s.joinedBtnTxt]}>
                    {joined ? '✓ Joined' : `${GROUP_ICONS.join} Join`}
                  </Text>
              }
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>Discover Groups</Text>
        <View style={s.searchRow}>
          <View style={s.searchBar}>
            <Text style={s.searchIcon}>🔍</Text>
            <TextInput style={s.searchInput} value={search} onChangeText={setSearch} placeholder="Search…" placeholderTextColor={colors.textMuted} />
          </View>
          <TouchableOpacity style={s.createBtn} onPress={() => navigation.navigate('CreateGroup')}>
            <Text style={s.createBtnTxt}>{GROUP_ICONS.create}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {loading
        ? <ActivityIndicator style={{ marginTop: 60 }} size="large" color={colors.primary} />
        : (
          <FlatList
            data={filtered}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <GroupCard group={item} />}
            contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={{ fontSize: 56 }}>🌑</Text>
                <Text style={s.emptyTitle}>No groups found</Text>
                <TouchableOpacity style={s.emptyBtn} onPress={() => navigation.navigate('CreateGroup')}>
                  <Text style={s.emptyBtnTxt}>{GROUP_ICONS.create} Create Group</Text>
                </TouchableOpacity>
              </View>
            }
          />
        )
      }
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.md },
  title: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  searchRow: { flexDirection: 'row', gap: spacing.sm },
  searchBar: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderWidth: 1, borderColor: colors.border },
  searchIcon: { fontSize: 16 },
  searchInput: { flex: 1, fontSize: typography.fontSize.md, color: colors.textPrimary },
  createBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', ...shadows.glow },
  createBtnTxt: { fontSize: 22 },
  card: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, ...shadows.sm },
  cover: { height: 86, justifyContent: 'center', alignItems: 'center', position: 'relative' },
  coverEmoji: { fontSize: 42 },
  badge: { position: 'absolute', top: spacing.sm, right: spacing.sm, paddingHorizontal: spacing.sm, paddingVertical: 3, borderRadius: borderRadius.full },
  badgeTxt: { color: '#fff', fontSize: 10, fontWeight: '800', textTransform: 'capitalize' },
  cardBody: { padding: spacing.lg },
  groupName: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  groupDesc: { fontSize: typography.fontSize.sm, color: colors.textSecondary, marginTop: spacing.xs, lineHeight: 18 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.md },
  memberCount: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  joinBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: borderRadius.full, minWidth: 80, alignItems: 'center' },
  joinedBtn: { backgroundColor: colors.surfaceHigh, borderWidth: 1, borderColor: colors.border },
  joinBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.sm },
  joinedBtnTxt: { color: colors.textSecondary },
  empty: { alignItems: 'center', paddingTop: 80, gap: spacing.md },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  emptyBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.xl, paddingVertical: spacing.md, borderRadius: borderRadius.full },
  emptyBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold },
});

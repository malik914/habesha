// src/screens/Groups/GroupDetailScreen.jsx — Real-time v2
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  TouchableOpacity, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { subscribeToGroup, subscribeToGroupPosts, joinGroup, leaveGroup } from '../../firebase/firestore';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TOPIC_ICONS, GROUP_ICONS, BRAND } from '../../theme/icons';
import { haptic } from '../../utils/haptics';
import { shareGroup } from '../../utils/appUtils';

export default function GroupDetailScreen({ route, navigation }) {
  const { groupId }               = route.params;
  const { user, profile, refreshProfile } = useAuth();
  // ✅ REAL-TIME: Live group data
  const [group, setGroup]   = useState(route.params.group || null);
  // ✅ REAL-TIME: Live posts in group
  const [posts, setPosts]   = useState([]);
  const [joining, setJoining] = useState(false);

  const isJoined     = profile?.joinedGroups?.includes(groupId);
  const topicColor   = colors.topics?.[group?.topic?.toLowerCase()] || colors.primary;
  const topicIcon    = TOPIC_ICONS[group?.topic?.toLowerCase()] || TOPIC_ICONS.default;
  const isAdmin      = group?.createdBy === user?.uid;

  useEffect(() => {
    // Subscribe to live group document
    const unsubGroup = subscribeToGroup(groupId, (data) => {
      setGroup(data);
      navigation.setOptions({ title: data?.name || 'Group' });
    });

    // Subscribe to live posts in this group
    const unsubPosts = subscribeToGroupPosts(groupId, setPosts);

    return () => { unsubGroup(); unsubPosts(); };
  }, [groupId]);

  const handleToggle = async () => {
    setJoining(true);
    haptic.medium();
    try {
      if (isJoined) { await leaveGroup(groupId, user.uid); haptic.light(); }
      else          { await joinGroup(groupId, user.uid);  haptic.success(); }
      await refreshProfile();
    } catch (e) { haptic.error(); console.error(e); }
    finally { setJoining(false); }
  };

  if (!group) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  return (
    <SafeAreaView style={s.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={[s.hero, { backgroundColor: topicColor + '15' }]}>
          {/* Admin / Share buttons */}
          <View style={s.heroActions}>
            {isAdmin && (
              <TouchableOpacity style={s.adminBtn} onPress={() => navigation.navigate('GroupAdmin', { groupId })}>
                <Text style={s.adminBtnTxt}>{GROUP_ICONS.admin} Admin</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={s.shareBtn} onPress={() => shareGroup(group)}>
              <Text style={{ fontSize: 18 }}>↗️</Text>
            </TouchableOpacity>
          </View>

          <View style={[s.heroIcon, { backgroundColor: topicColor + '28', borderColor: topicColor + '55' }]}>
            <Text style={s.heroIconTxt}>{topicIcon}</Text>
          </View>
          <Text style={s.groupName}>{group.name}</Text>
          <Text style={s.groupDesc}>{group.description}</Text>

          {/* Live stats chips */}
          <View style={s.metaRow}>
            <View style={[s.chip, { backgroundColor: topicColor + '20', borderColor: topicColor + '50' }]}>
              <Text style={[s.chipTxt, { color: topicColor }]}>{group.topic}</Text>
            </View>
            {/* member count updates live */}
            <View style={s.chip}>
              <Text style={s.chipTxt}>{GROUP_ICONS.members} {group.memberCount || 0} members</Text>
            </View>
            <View style={s.chip}>
              <Text style={s.chipTxt}>{group.privacy === 'private' ? GROUP_ICONS.private : GROUP_ICONS.public} {group.privacy}</Text>
            </View>
          </View>

          <TouchableOpacity
            style={[s.joinBtn, isJoined && s.leaveBtn, isJoined && { borderColor: topicColor }]}
            onPress={handleToggle}
            disabled={joining}
          >
            {joining
              ? <ActivityIndicator size="small" color={isJoined ? colors.textSecondary : '#fff'} />
              : <Text style={[s.joinBtnTxt, isJoined && s.leaveBtnTxt]}>
                  {isJoined ? `${GROUP_ICONS.leave} Leave Group` : `${GROUP_ICONS.join} Join Group`}
                </Text>
            }
          </TouchableOpacity>
        </View>

        {/* Live posts */}
        <View style={s.postsSection}>
          <Text style={s.sectionTitle}>Recent Posts · {posts.length}</Text>
          {posts.length === 0
            ? <View style={s.noPosts}><Text style={{ fontSize: 40 }}>📝</Text><Text style={s.noPostsTxt}>No posts yet. Be the first!</Text></View>
            : posts.map((post) => (
                <View key={post.id} style={s.postCard}>
                  <View style={s.postHeader}>
                    <View style={s.postAvatar}><Text style={s.postAvatarTxt}>{post.authorName?.[0]?.toUpperCase()}</Text></View>
                    <View style={{ flex: 1 }}>
                      <View style={{ flexDirection: 'row', gap: spacing.xs, alignItems: 'center' }}>
                        <Text style={s.postAuthor}>{post.authorName}</Text>
                        {post.authorVerified && <Text style={{ fontSize: 11 }}>{BRAND.verified}</Text>}
                      </View>
                      {post.authorUsername && <Text style={s.postUsername}>@{post.authorUsername}</Text>}
                    </View>
                    {/* Live reaction count */}
                    <Text style={s.postMeta}>❤️ {post.likes?.length || 0}</Text>
                  </View>
                  <Text style={s.postContent} numberOfLines={4}>{post.content}</Text>
                  <Text style={s.postFooter}>💬 {post.commentCount || 0} comments</Text>
                </View>
              ))
          }
        </View>
        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { alignItems: 'center', padding: spacing.xl, gap: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, overflow: 'hidden', position: 'relative' },
  heroActions: { position: 'absolute', top: spacing.lg, right: spacing.lg, flexDirection: 'row', gap: spacing.sm },
  adminBtn: { backgroundColor: colors.accent + '20', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.accent + '50' },
  adminBtnTxt: { color: colors.accent, fontSize: typography.fontSize.sm, fontWeight: '700' },
  shareBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  heroIcon: { width: 90, height: 90, borderRadius: 24, justifyContent: 'center', alignItems: 'center', borderWidth: 1.5, marginBottom: spacing.sm },
  heroIconTxt: { fontSize: 46 },
  groupName: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, textAlign: 'center' },
  groupDesc: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 22, paddingHorizontal: spacing.lg },
  metaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, justifyContent: 'center' },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border },
  chipTxt: { fontSize: typography.fontSize.sm, color: colors.textSecondary, fontWeight: '600', textTransform: 'capitalize' },
  joinBtn: { paddingHorizontal: spacing.xxxl, paddingVertical: spacing.md, backgroundColor: colors.primary, borderRadius: borderRadius.lg, ...shadows.glow },
  leaveBtn: { backgroundColor: 'transparent', borderWidth: 2 },
  joinBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.black, fontSize: typography.fontSize.md },
  leaveBtnTxt: { color: colors.textSecondary },
  postsSection: { padding: spacing.xl, gap: spacing.md },
  sectionTitle: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  noPosts: { alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xxl },
  noPostsTxt: { color: colors.textMuted },
  postCard: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border, gap: spacing.sm },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  postAvatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  postAvatarTxt: { color: '#fff', fontWeight: '700' },
  postAuthor: { fontWeight: typography.fontWeight.bold, color: colors.textPrimary, fontSize: typography.fontSize.sm },
  postUsername: { fontSize: 11, color: colors.textMuted },
  postContent: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 20 },
  postMeta: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  postFooter: { fontSize: typography.fontSize.xs, color: colors.textMuted },
});

// src/screens/Groups/GroupAdminScreen.jsx — Real-time v2
import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator, Image,
} from 'react-native';
import {
  doc, onSnapshot, updateDoc, arrayRemove, deleteDoc,
  collection, query, where, orderBy, limit,
} from 'firebase/firestore';
import { db }              from '../../firebase/config';
import { useAuth }         from '../../context/AuthContext';
import { subscribeToUser } from '../../firebase/follows';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { GROUP_ICONS, TOPIC_ICONS } from '../../theme/icons';

export default function GroupAdminScreen({ route, navigation }) {
  const { groupId } = route.params;
  const { user }    = useAuth();
  // ✅ REAL-TIME: Live group document
  const [group, setGroup]   = useState(null);
  // ✅ REAL-TIME: Live posts in group
  const [posts, setPosts]   = useState([]);
  // ✅ REAL-TIME: Live member profiles
  const [memberProfiles, setMP] = useState({});
  const [tab, setTab]       = useState('overview');
  const [loading, setL]     = useState(true);

  useEffect(() => {
    // Subscribe to live group document
    const unsubGroup = onSnapshot(doc(db, 'groups', groupId), async (snap) => {
      if (!snap.exists()) { navigation.goBack(); return; }
      const data = { id: snap.id, ...snap.data() };
      if (data.createdBy !== user.uid) {
        Alert.alert('Access denied', 'Only the group creator can access admin panel.');
        navigation.goBack();
        return;
      }
      setGroup(data);
      setL(false);
    });

    // Subscribe to live posts in this group
    const postsQ = query(
      collection(db, 'posts'),
      where('groupId', '==', groupId),
      orderBy('createdAt', 'desc'),
      limit(30),
    );
    const unsubPosts = onSnapshot(postsQ, (snap) =>
      setPosts(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    );

    return () => { unsubGroup(); unsubPosts(); };
  }, [groupId]);

  // Subscribe to each member's live profile
  useEffect(() => {
    if (!group?.members?.length) return;
    const unsubs = group.members.slice(0, 50).map((uid) =>
      subscribeToUser(uid, (profile) => {
        setMP((prev) => ({ ...prev, [uid]: profile }));
      })
    );
    return () => unsubs.forEach((u) => u());
  }, [group?.members?.join(',')]);

  const handleRemoveMember = (memberUid) => {
    Alert.alert('Remove member?', 'This person will be removed from the group.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove', style: 'destructive', onPress: async () => {
          await updateDoc(doc(db, 'groups', groupId), {
            members: arrayRemove(memberUid),
            memberCount: (group.memberCount || 1) - 1,
          });
          await updateDoc(doc(db, 'users', memberUid), { joinedGroups: arrayRemove(groupId) });
        }
      },
    ]);
  };

  const handlePinPost = async (postId) => {
    const pinned = group.pinnedPosts?.includes(postId);
    await updateDoc(doc(db, 'groups', groupId), {
      pinnedPosts: pinned ? arrayRemove(postId) : [...(group.pinnedPosts || []), postId],
    });
  };

  const handleDeletePost = (postId) => {
    Alert.alert('Delete post?', 'Permanently removes this post.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => deleteDoc(doc(db, 'posts', postId)) },
    ]);
  };

  const handleDeleteGroup = () => {
    Alert.alert('⚡ Delete Group?', `Permanently delete "${group?.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive', onPress: async () => {
          await deleteDoc(doc(db, 'groups', groupId));
          navigation.navigate('Main');
        }
      },
    ]);
  };

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );

  const members = group?.members || [];
  const TABS = ['overview', 'members', 'posts'];

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={s.back}>← Back</Text></TouchableOpacity>
        <Text style={s.title}>{GROUP_ICONS.admin} Admin Panel</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={s.tabs}>
        {TABS.map((t) => (
          <TouchableOpacity key={t} style={[s.tab, tab === t && s.tabActive]} onPress={() => setTab(t)}>
            <Text style={[s.tabTxt, tab === t && s.tabTxtActive]}>{t.charAt(0).toUpperCase() + t.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>

        {/* ── Overview (live stats) ── */}
        {tab === 'overview' && (
          <>
            <View style={s.statsRow}>
              {[
                { icon: '👥', label: 'Members',  value: group?.memberCount || 0 },
                { icon: '📝', label: 'Posts',    value: posts.length },
                { icon: '📌', label: 'Pinned',   value: group?.pinnedPosts?.length || 0 },
              ].map(({ icon, label, value }) => (
                <View key={label} style={s.statCard}>
                  <Text style={s.statIcon}>{icon}</Text>
                  <Text style={s.statValue}>{value}</Text>
                  <Text style={s.statLabel}>{label}</Text>
                </View>
              ))}
            </View>

            <View style={s.card}>
              <Text style={s.cardTitle}>Group Details</Text>
              <View style={s.infoRow}><Text style={s.infoLabel}>Topic</Text><Text style={s.infoValue}>{TOPIC_ICONS[group?.topic]} {group?.topic}</Text></View>
              <View style={s.infoRow}><Text style={s.infoLabel}>Privacy</Text><Text style={s.infoValue}>{group?.privacy === 'private' ? GROUP_ICONS.private : GROUP_ICONS.public} {group?.privacy}</Text></View>
              <View style={[s.infoRow, { borderBottomWidth: 0 }]}><Text style={s.infoLabel}>Created</Text><Text style={s.infoValue}>{group?.createdAt?.toDate?.()?.toLocaleDateString?.() || '—'}</Text></View>
            </View>

            <TouchableOpacity style={s.dangerBtn} onPress={handleDeleteGroup}>
              <Text style={s.dangerBtnTxt}>🗑️ Delete Group</Text>
            </TouchableOpacity>
          </>
        )}

        {/* ── Members (live list) ── */}
        {tab === 'members' && members.map((uid) => {
          const m = memberProfiles[uid];
          return (
            <View key={uid} style={s.memberRow}>
              {m?.photoURL
                ? <Image source={{ uri: m.photoURL }} style={s.memberAvatar} />
                : <View style={s.memberAvatarFallback}><Text style={s.memberAvatarTxt}>{(m?.displayName || '?')[0].toUpperCase()}</Text></View>
              }
              <View style={{ flex: 1 }}>
                <Text style={s.memberName}>{m?.displayName || uid.slice(0, 12) + '…'}</Text>
                {m?.username && <Text style={s.memberUsername}>@{m.username}</Text>}
              </View>
              {uid === group?.createdBy
                ? <View style={s.adminBadge}><Text style={s.adminBadgeTxt}>Admin</Text></View>
                : (
                  <TouchableOpacity style={s.removeBtn} onPress={() => handleRemoveMember(uid)}>
                    <Text style={s.removeBtnTxt}>Remove</Text>
                  </TouchableOpacity>
                )
              }
            </View>
          );
        })}

        {/* ── Posts (live list) ── */}
        {tab === 'posts' && posts.map((p) => {
          const pinned = group?.pinnedPosts?.includes(p.id);
          return (
            <View key={p.id} style={s.postRow}>
              {pinned && <Text style={s.pinnedBadge}>📌 Pinned</Text>}
              <Text style={s.postContent} numberOfLines={2}>{p.content}</Text>
              <Text style={s.postMeta}>By {p.authorName} · ❤️ {p.likes?.length || 0} · 💬 {p.commentCount || 0}</Text>
              <View style={s.postActions}>
                <TouchableOpacity style={s.pinBtn} onPress={() => handlePinPost(p.id)}>
                  <Text style={s.pinBtnTxt}>{pinned ? '📌 Unpin' : '📌 Pin'}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.deletePostBtn} onPress={() => handleDeletePost(p.id)}>
                  <Text style={s.deletePostTxt}>🗑️ Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  back: { color: colors.primary, fontSize: typography.fontSize.md, fontWeight: '600', width: 60 },
  title: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, paddingVertical: spacing.md, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: colors.primary },
  tabTxt: { color: colors.textMuted, fontWeight: typography.fontWeight.medium },
  tabTxtActive: { color: colors.primary, fontWeight: typography.fontWeight.bold },
  body: { padding: spacing.xl, gap: spacing.lg },
  statsRow: { flexDirection: 'row', gap: spacing.md },
  statCard: { flex: 1, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, alignItems: 'center', gap: spacing.xs, borderWidth: 1, borderColor: colors.border },
  statIcon: { fontSize: 24 },
  statValue: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  statLabel: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  card: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  cardTitle: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textPrimary, marginBottom: spacing.md },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  infoLabel: { color: colors.textMuted, fontSize: typography.fontSize.sm },
  infoValue: { color: colors.textSecondary, fontSize: typography.fontSize.sm, fontWeight: '600', textTransform: 'capitalize' },
  dangerBtn: { backgroundColor: colors.error + '20', paddingVertical: spacing.lg, borderRadius: borderRadius.lg, alignItems: 'center', borderWidth: 1, borderColor: colors.error + '40' },
  dangerBtnTxt: { color: colors.error, fontWeight: typography.fontWeight.bold },
  memberRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  memberAvatar: { width: 44, height: 44, borderRadius: 22 },
  memberAvatarFallback: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  memberAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 18 },
  memberName: { fontWeight: typography.fontWeight.semibold, color: colors.textPrimary },
  memberUsername: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  adminBadge: { backgroundColor: colors.primary + '25', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full },
  adminBadgeTxt: { color: colors.primary, fontSize: typography.fontSize.xs, fontWeight: '700' },
  removeBtn: { backgroundColor: colors.error + '20', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.error + '40' },
  removeBtnTxt: { color: colors.error, fontSize: typography.fontSize.xs, fontWeight: '600' },
  postRow: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border, gap: spacing.sm },
  pinnedBadge: { fontSize: typography.fontSize.xs, color: colors.accent, fontWeight: '700' },
  postContent: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 20 },
  postMeta: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  postActions: { flexDirection: 'row', gap: spacing.sm },
  pinBtn: { backgroundColor: colors.accent + '20', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full },
  pinBtnTxt: { color: colors.accent, fontSize: typography.fontSize.xs, fontWeight: '600' },
  deletePostBtn: { backgroundColor: colors.error + '20', paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full },
  deletePostTxt: { color: colors.error, fontSize: typography.fontSize.xs, fontWeight: '600' },
});

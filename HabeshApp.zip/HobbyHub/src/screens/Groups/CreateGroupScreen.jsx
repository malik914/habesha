// src/screens/Groups/CreateGroupScreen.jsx — Premium dark v2
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, ScrollView, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { joinGroup } from '../../firebase/firestore';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TOPIC_ICONS, GROUP_ICONS } from '../../theme/icons';

const TOPICS = [
  { id: 'photography', label: 'Photography', color: '#9B5DE5' },
  { id: 'cooking',     label: 'Cooking',     color: '#F15BB5' },
  { id: 'gaming',      label: 'Gaming',      color: '#00BBF9' },
  { id: 'fitness',     label: 'Fitness',     color: '#06D6A0' },
  { id: 'music',       label: 'Music',       color: '#FF4D6D' },
  { id: 'travel',      label: 'Travel',      color: '#FFB703' },
  { id: 'art',         label: 'Art & Design',color: '#FF6B6B' },
  { id: 'reading',     label: 'Reading',     color: '#845EC2' },
  { id: 'tech',        label: 'Technology',  color: '#48CAE4' },
  { id: 'nature',      label: 'Nature',      color: '#06D6A0' },
  { id: 'film',        label: 'Film & TV',   color: '#F72585' },
  { id: 'sports',      label: 'Sports',      color: '#4CC9F0' },
];

const COVER_COLORS = [
  '#FF4D6D','#9B5DE5','#00BBF9','#06D6A0',
  '#FFB703','#F15BB5','#48CAE4','#FF6B6B',
  '#845EC2','#F72585','#4CC9F0','#1C1917',
];

const PRIVACY_OPTIONS = [
  { id: 'public',  label: 'Public',  desc: 'Anyone can find and join',  icon: GROUP_ICONS.public  },
  { id: 'private', label: 'Private', desc: 'Members must be approved', icon: GROUP_ICONS.private },
];

export default function CreateGroupScreen({ navigation }) {
  const { user, profile } = useAuth();
  const [name, setName]         = useState('');
  const [desc, setDesc]         = useState('');
  const [topic, setTopic]       = useState(null);
  const [color, setColor]       = useState(COVER_COLORS[0]);
  const [privacy, setPrivacy]   = useState('public');
  const [saving, setSaving]     = useState(false);

  const selectedTopic = TOPICS.find((t) => t.id === topic);
  const topicIcon     = TOPIC_ICONS[topic] || TOPIC_ICONS.default;
  const canCreate     = name.trim().length >= 3 && desc.trim().length >= 10 && topic;

  const handleCreate = async () => {
    if (!canCreate) return;
    setSaving(true);
    try {
      const ref = await addDoc(collection(db, 'groups'), {
        name: name.trim(),
        description: desc.trim(),
        topic,
        emoji: topicIcon,
        coverColor: color,
        privacy,
        memberCount: 1,
        members: [user.uid],
        createdBy: user.uid,
        createdByName: profile?.displayName,
        createdByUsername: profile?.username || null,
        createdAt: serverTimestamp(),
      });
      await joinGroup(ref.id, user.uid);
      Alert.alert(`${GROUP_ICONS.create} Group Created!`, `"${name}" is live. Share it with your friends!`, [
        { text: 'View Group', onPress: () => navigation.replace('GroupDetail', { groupId: ref.id }) },
      ]);
    } catch (e) {
      Alert.alert('Error', e.message || 'Could not create group. Please try again.');
    } finally { setSaving(false); }
  };

  return (
    <SafeAreaView style={s.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        {/* Header */}
        <View style={s.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={s.cancelBtn}>Cancel</Text>
          </TouchableOpacity>
          <Text style={s.headerTitle}>New Group</Text>
          <TouchableOpacity
            style={[s.createBtn, !canCreate && s.createBtnOff]}
            onPress={handleCreate}
            disabled={!canCreate || saving}
          >
            {saving ? <ActivityIndicator size="small" color="#fff" /> : <Text style={s.createBtnTxt}>Create</Text>}
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
          {/* Live preview */}
          <View style={[s.preview, { backgroundColor: (selectedTopic?.color || color) + '25', borderColor: (selectedTopic?.color || color) + '55' }]}>
            <Text style={s.previewIcon}>{topicIcon}</Text>
            <Text style={s.previewName}>{name || 'Group Name'}</Text>
            <Text style={s.previewTopic}>{selectedTopic?.label || 'Choose a topic below'}</Text>
          </View>

          {/* Name */}
          <View style={s.field}>
            <Text style={s.label}>Group Name <Text style={s.req}>*</Text></Text>
            <View style={s.inputWrap}>
              <Text style={s.inputIcon}>{GROUP_ICONS.admin}</Text>
              <TextInput style={s.input} value={name} onChangeText={setName} placeholder="e.g. Street Photography Club" placeholderTextColor={colors.textMuted} maxLength={60} autoCapitalize="words" />
            </View>
            <Text style={s.charCount}>{name.length}/60</Text>
          </View>

          {/* Description */}
          <View style={s.field}>
            <Text style={s.label}>Description <Text style={s.req}>*</Text></Text>
            <TextInput style={[s.inputWrap, s.textArea, { paddingHorizontal: spacing.lg }]} value={desc} onChangeText={setDesc} placeholder="What's this group about?" placeholderTextColor={colors.textMuted} multiline maxLength={300} textAlignVertical="top" />
            <Text style={s.charCount}>{desc.length}/300</Text>
          </View>

          {/* Topic */}
          <View style={s.field}>
            <Text style={s.label}>Topic <Text style={s.req}>*</Text></Text>
            <View style={s.topicGrid}>
              {TOPICS.map((t) => {
                const on = topic === t.id;
                return (
                  <TouchableOpacity
                    key={t.id}
                    style={[s.topicChip, on && { backgroundColor: t.color, borderColor: t.color }]}
                    onPress={() => { setTopic(t.id); setColor(t.color); }}
                    activeOpacity={0.75}
                  >
                    <Text style={s.topicEmoji}>{TOPIC_ICONS[t.id]}</Text>
                    <Text style={[s.topicLabel, on && { color: '#fff', fontWeight: '700' }]}>{t.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Cover color */}
          <View style={s.field}>
            <Text style={s.label}>Cover Color</Text>
            <View style={s.colorRow}>
              {COVER_COLORS.map((c) => (
                <TouchableOpacity
                  key={c}
                  style={[s.colorDot, { backgroundColor: c }, color === c && s.colorDotActive]}
                  onPress={() => setColor(c)}
                />
              ))}
            </View>
          </View>

          {/* Privacy */}
          <View style={s.field}>
            <Text style={s.label}>Privacy</Text>
            <View style={s.privacyRow}>
              {PRIVACY_OPTIONS.map((opt) => (
                <TouchableOpacity
                  key={opt.id}
                  style={[s.privacyCard, privacy === opt.id && s.privacyCardActive]}
                  onPress={() => setPrivacy(opt.id)}
                  activeOpacity={0.8}
                >
                  <Text style={s.privacyIcon}>{opt.icon}</Text>
                  <Text style={[s.privacyLabel, privacy === opt.id && { color: colors.primary }]}>{opt.label}</Text>
                  <Text style={s.privacyDesc}>{opt.desc}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={s.hint}>
            <Text style={s.hintTxt}>{GROUP_ICONS.admin} As the creator, you're the group admin. You can manage members and pin posts after creation.</Text>
          </View>
          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  cancelBtn: { color: colors.textSecondary, fontSize: typography.fontSize.md },
  headerTitle: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  createBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: borderRadius.full, ...shadows.glow },
  createBtnOff: { opacity: 0.4 },
  createBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.sm },
  scroll: { padding: spacing.xl, gap: spacing.xl },
  preview: { borderRadius: borderRadius.xl, padding: spacing.xl, alignItems: 'center', minHeight: 140, justifyContent: 'center', gap: spacing.sm, borderWidth: 1.5 },
  previewIcon: { fontSize: 52 },
  previewName: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, textAlign: 'center' },
  previewTopic: { fontSize: typography.fontSize.sm, color: colors.textMuted, textAlign: 'center' },
  field: { gap: spacing.sm },
  label: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold, color: colors.textSecondary },
  req: { color: colors.error },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceAlt, borderWidth: 1.5, borderColor: colors.border, borderRadius: borderRadius.md, paddingHorizontal: spacing.md },
  inputIcon: { fontSize: 18, marginRight: spacing.sm },
  input: { flex: 1, paddingVertical: spacing.md, fontSize: typography.fontSize.md, color: colors.textPrimary },
  textArea: { minHeight: 90, paddingTop: spacing.md },
  charCount: { fontSize: typography.fontSize.xs, color: colors.textMuted, textAlign: 'right' },
  topicGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  topicChip: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: borderRadius.full, backgroundColor: colors.surfaceAlt, borderWidth: 1.5, borderColor: colors.border },
  topicEmoji: { fontSize: 16 },
  topicLabel: { fontSize: typography.fontSize.sm, color: colors.textSecondary, fontWeight: typography.fontWeight.medium },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md },
  colorDot: { width: 36, height: 36, borderRadius: 18 },
  colorDotActive: { borderWidth: 3, borderColor: colors.textPrimary, transform: [{ scale: 1.2 }] },
  privacyRow: { flexDirection: 'row', gap: spacing.md },
  privacyCard: { flex: 1, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, alignItems: 'center', gap: spacing.xs, borderWidth: 2, borderColor: 'transparent', borderColor: colors.border },
  privacyCardActive: { borderColor: colors.primary, backgroundColor: colors.primaryGlow },
  privacyIcon: { fontSize: 28 },
  privacyLabel: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textSecondary },
  privacyDesc: { fontSize: typography.fontSize.xs, color: colors.textMuted, textAlign: 'center' },
  hint: { backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  hintTxt: { fontSize: typography.fontSize.sm, color: colors.textSecondary, lineHeight: 20 },
});

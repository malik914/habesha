// src/screens/Main/ReelsScreen.jsx — Real-time v2
import React, { useRef, useState, useCallback, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, Dimensions,
  TouchableOpacity, Image, ActivityIndicator, StatusBar,
} from 'react-native';
import { useAuth }         from '../../context/AuthContext';
import { collection, query, where, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db }              from '../../firebase/config';
import { toggleReaction, subscribeToPostReactions, getUserReaction } from '../../firebase/reactions';
import { toggleBookmark }  from '../../firebase/bookmarks';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { POST_ACTIONS, TOPIC_ICONS, BRAND } from '../../theme/icons';

const { width: W, height: H } = Dimensions.get('window');

// ── Live Reel Item ──────────────────────────────────────────────────
const ReelItem = ({ item, isActive, currentUserId, navigation }) => {
  // ✅ REAL-TIME: Live like/comment counts
  const [liveStats, setLiveStats] = useState({
    reactions:    item.reactions    || {},
    commentCount: item.commentCount || 0,
    viewCount:    item.viewCount    || 0,
  });
  const [saved, setSaved] = useState(false);
  const topicIcon = TOPIC_ICONS[item.groupTopic?.toLowerCase()] || TOPIC_ICONS.default;

  useEffect(() => {
    const unsub = subscribeToPostReactions(item.id, (stats) => setLiveStats(stats));
    return unsub;
  }, [item.id]);

  const myReaction = getUserReaction(liveStats.reactions, currentUserId);
  const likeCount  = liveStats.reactions?.['❤️']?.length || liveStats.likes?.length || 0;
  const isLiked    = !!myReaction;

  const handleLike = async () => {
    await toggleReaction(item.id, currentUserId, '❤️', isLiked);
  };

  const handleSave = async () => {
    setSaved((v) => !v);
    await toggleBookmark(currentUserId, item.id);
  };

  return (
    <View style={rs.reel}>
      {item.imageUrl
        ? <Image source={{ uri: item.imageUrl }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
        : <View style={[StyleSheet.absoluteFillObject, { backgroundColor: colors.topics?.[item.groupTopic] || '#1A1A26' }]} />
      }
      <View style={rs.overlayTop} />
      <View style={rs.overlayBottom} />

      {/* Right bar */}
      <View style={rs.rightBar}>
        <TouchableOpacity style={rs.authorBtn} onPress={() => navigation?.navigate('UserProfile', { userId: item.authorId })}>
          {item.authorPhoto
            ? <Image source={{ uri: item.authorPhoto }} style={rs.authorAvatar} />
            : <View style={[rs.authorAvatarFallback, { backgroundColor: colors.topics?.[item.groupTopic] || colors.primary }]}>
                <Text style={rs.authorAvatarTxt}>{item.authorName?.[0]?.toUpperCase()}</Text>
              </View>
          }
          <View style={rs.followPill}><Text style={rs.followPillTxt}>+</Text></View>
        </TouchableOpacity>

        <TouchableOpacity style={rs.actionBtn} onPress={handleLike}>
          <Text style={rs.actionEmoji}>{isLiked ? POST_ACTIONS.liked : POST_ACTIONS.like}</Text>
          {/* Live count */}
          <Text style={rs.actionCount}>{likeCount}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={rs.actionBtn}>
          <Text style={rs.actionEmoji}>{POST_ACTIONS.comment}</Text>
          {/* Live comment count */}
          <Text style={rs.actionCount}>{liveStats.commentCount}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={rs.actionBtn} onPress={handleSave}>
          <Text style={rs.actionEmoji}>{saved ? POST_ACTIONS.bookmarked : POST_ACTIONS.bookmark}</Text>
          <Text style={rs.actionCount}>Save</Text>
        </TouchableOpacity>

        <TouchableOpacity style={rs.actionBtn}>
          <Text style={rs.actionEmoji}>{POST_ACTIONS.share}</Text>
          <Text style={rs.actionCount}>Share</Text>
        </TouchableOpacity>
      </View>

      {/* Bottom info */}
      <View style={rs.bottomInfo}>
        <TouchableOpacity onPress={() => navigation?.navigate('UserProfile', { userId: item.authorId })}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.xs }}>
            <Text style={rs.authorHandle}>@{item.authorUsername || item.authorName}</Text>
            {item.authorVerified && <Text style={{ fontSize: 13 }}>{BRAND.verified}</Text>}
          </View>
        </TouchableOpacity>
        {item.content && <Text style={rs.caption} numberOfLines={2}>{item.content}</Text>}
        {item.hashtags?.length > 0 && (
          <Text style={rs.hashtags}>{item.hashtags.slice(0, 4).map((h) => `#${h}`).join(' ')}</Text>
        )}
        <View style={rs.groupPill}>
          <Text style={rs.groupPillTxt}>{topicIcon} {item.groupName || 'Habesha'}</Text>
        </View>
      </View>
    </View>
  );
};

export default function ReelsScreen({ navigation }) {
  const { user }       = useAuth();
  // ✅ REAL-TIME: Live reels feed
  const [reels, setR]  = useState([]);
  const [active, setA] = useState(0);
  const [loading, setL]= useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'posts'),
      where('isReel', '==', true),
      orderBy('createdAt', 'desc'),
      limit(50),
    );
    const unsub = onSnapshot(q, (snap) => {
      setR(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setL(false);
    });
    return unsub;
  }, []);

  const onViewable = useCallback(({ viewableItems }) => {
    if (viewableItems.length > 0) setA(viewableItems[0].index);
  }, []);

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#000' }}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );

  if (reels.length === 0) return (
    <View style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center', gap: spacing.lg }}>
      <Text style={{ fontSize: 64 }}>🎞️</Text>
      <Text style={{ color: '#fff', fontSize: typography.fontSize.xl, fontWeight: '800' }}>No Reels yet</Text>
      <Text style={{ color: 'rgba(255,255,255,0.5)', fontSize: typography.fontSize.md }}>Be the first to share a short video!</Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <StatusBar hidden />
      <FlatList
        data={reels}
        keyExtractor={(item) => item.id}
        renderItem={({ item, index }) => (
          <ReelItem item={item} isActive={index === active} currentUserId={user?.uid} navigation={navigation} />
        )}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        snapToInterval={H}
        decelerationRate="fast"
        onViewableItemsChanged={onViewable}
        viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
        getItemLayout={(_, i) => ({ length: H, offset: H * i, index: i })}
      />
    </View>
  );
}

const rs = StyleSheet.create({
  reel: { width: W, height: H, backgroundColor: '#000' },
  overlayTop: { position: 'absolute', top: 0, left: 0, right: 0, height: 160, backgroundColor: 'rgba(0,0,0,0.35)' },
  overlayBottom: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 260, backgroundColor: 'rgba(0,0,0,0.5)' },
  rightBar: { position: 'absolute', right: 14, bottom: 120, alignItems: 'center', gap: 20 },
  authorBtn: { position: 'relative' },
  authorAvatar: { width: 50, height: 50, borderRadius: 25, borderWidth: 2.5, borderColor: '#fff' },
  authorAvatarFallback: { width: 50, height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center', borderWidth: 2.5, borderColor: '#fff' },
  authorAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  followPill: { position: 'absolute', bottom: -8, alignSelf: 'center', width: 22, height: 22, borderRadius: 11, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#000' },
  followPillTxt: { color: '#fff', fontSize: 16, fontWeight: '900', lineHeight: 20 },
  actionBtn: { alignItems: 'center', gap: 4 },
  actionEmoji: { fontSize: 29 },
  actionCount: { color: '#fff', fontSize: 12, fontWeight: '700' },
  bottomInfo: { position: 'absolute', bottom: 24, left: 16, right: 76, gap: 5 },
  authorHandle: { color: '#fff', fontWeight: '800', fontSize: 15 },
  caption: { color: 'rgba(255,255,255,0.9)', fontSize: 14, lineHeight: 20 },
  hashtags: { color: colors.tertiary, fontSize: 13, fontWeight: '700' },
  groupPill: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: spacing.md, paddingVertical: 4, borderRadius: borderRadius.full, alignSelf: 'flex-start', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  groupPillTxt: { color: 'rgba(255,255,255,0.85)', fontSize: 12, fontWeight: '600' },
});

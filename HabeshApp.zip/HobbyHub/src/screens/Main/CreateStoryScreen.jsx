// src/screens/Main/CreateStoryScreen.jsx
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, Image, Dimensions, StatusBar,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { createStory } from '../../firebase/stories';
import { useImagePicker } from '../../hooks/useImagePicker';
import { colors, typography, spacing, borderRadius } from '../../theme';

const { width: W, height: H } = Dimensions.get('window');

const BG_COLORS = [
  '#1A6B72', '#8B5CF6', '#F59E0B', '#3B82F6',
  '#22A06B', '#EC4899', '#FF6B47', '#EF4444',
  '#0EA5E9', '#1C1917', '#6366F1', '#F97316',
];

const TEXT_STYLES = [
  { id: 'normal',  label: 'Aa',  style: { fontWeight: '400', fontStyle: 'normal'  } },
  { id: 'bold',    label: 'Aa',  style: { fontWeight: '800', fontStyle: 'normal'  } },
  { id: 'italic',  label: 'Aa',  style: { fontWeight: '400', fontStyle: 'italic'  } },
  { id: 'outline', label: 'Aa',  style: { fontWeight: '700', fontStyle: 'normal'  } },
];

export default function CreateStoryScreen({ navigation }) {
  const { user, profile } = useAuth();
  const { showPickerOptions } = useImagePicker();

  const [bgColor, setBgColor] = useState(BG_COLORS[0]);
  const [imageUri, setImageUri] = useState(null);
  const [text, setText] = useState('');
  const [textStyleId, setTextStyleId] = useState('bold');
  const [uploading, setUploading] = useState(false);
  const [showTextInput, setShowTextInput] = useState(false);
  const inputRef = useRef(null);

  const currentTextStyle = TEXT_STYLES.find((t) => t.id === textStyleId);

  const handlePickImage = async () => {
    const uri = await showPickerOptions();
    if (uri) setImageUri(uri);
  };

  const handlePost = async () => {
    if (!text.trim() && !imageUri) {
      Alert.alert('Add something', 'Write some text or add a photo to your story.');
      return;
    }
    setUploading(true);
    try {
      await createStory({
        authorId: user.uid,
        authorName: profile?.displayName,
        authorUsername: profile?.username || null,
        authorPhoto: profile?.photoURL || null,
        mediaUri: imageUri,
        text: text.trim() || null,
        backgroundColor: bgColor,
      });
      navigation.goBack();
    } catch (e) {
      Alert.alert('Error', 'Could not post story. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <SafeAreaView style={s.container}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {/* Story Preview Canvas */}
        <View style={[s.canvas, { backgroundColor: bgColor }]}>
          {imageUri && (
            <Image source={{ uri: imageUri }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
          )}
          {/* Semi-transparent overlay when image is shown */}
          {imageUri && <View style={s.imgOverlay} />}

          {/* Tap-to-type text overlay */}
          {showTextInput ? (
            <TextInput
              ref={inputRef}
              style={[s.storyTextInput, currentTextStyle?.style]}
              value={text}
              onChangeText={setText}
              placeholder="Type something..."
              placeholderTextColor="rgba(255,255,255,0.5)"
              multiline
              autoFocus
              maxLength={150}
              onBlur={() => !text && setShowTextInput(false)}
              textAlign="center"
            />
          ) : text ? (
            <TouchableOpacity onPress={() => { setShowTextInput(true); setTimeout(() => inputRef.current?.focus(), 50); }}>
              <Text style={[s.storyTextDisplay, currentTextStyle?.style]}>{text}</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={s.tapToType} onPress={() => { setShowTextInput(true); setTimeout(() => inputRef.current?.focus(), 50); }}>
              <Text style={s.tapToTypeText}>Tap to type</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Top controls */}
        <View style={s.topBar}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={s.topBtn}>
            <Text style={s.topBtnTxt}>✕</Text>
          </TouchableOpacity>

          <View style={s.topActions}>
            {/* Text style toggle */}
            {TEXT_STYLES.map((ts) => (
              <TouchableOpacity
                key={ts.id}
                style={[s.textStyleBtn, textStyleId === ts.id && s.textStyleBtnActive]}
                onPress={() => setTextStyleId(ts.id)}
              >
                <Text style={[s.textStyleBtnTxt, ts.style, textStyleId === ts.id && { color: bgColor }]}>
                  {ts.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity onPress={handlePickImage} style={s.topBtn}>
            <Text style={s.topBtnTxt}>🖼️</Text>
          </TouchableOpacity>
        </View>

        {/* Bottom controls */}
        <View style={s.bottomBar}>
          {/* Background color picker */}
          <View style={s.colorRow}>
            {BG_COLORS.map((c) => (
              <TouchableOpacity
                key={c}
                style={[s.colorDot, { backgroundColor: c }, bgColor === c && s.colorDotSelected]}
                onPress={() => setBgColor(c)}
              />
            ))}
          </View>

          {/* Post button */}
          <TouchableOpacity
            style={[s.postBtn, uploading && s.postBtnDisabled]}
            onPress={handlePost}
            disabled={uploading}
          >
            {uploading
              ? <ActivityIndicator color="#fff" />
              : <>
                  <Text style={s.postBtnTxt}>Share Story</Text>
                  <Text style={s.postBtnArrow}>→</Text>
                </>
            }
          </TouchableOpacity>

          {/* Story duration hint */}
          <Text style={s.durationHint}>Your story disappears after 24 hours</Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  canvas: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  imgOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.25)' },
  tapToType: { padding: spacing.xl },
  tapToTypeText: { color: 'rgba(255,255,255,0.5)', fontSize: typography.fontSize.xl, fontWeight: '600', textAlign: 'center' },
  storyTextInput: { color: '#fff', fontSize: 28, textAlign: 'center', minWidth: W * 0.6, maxWidth: W * 0.85, padding: spacing.md },
  storyTextDisplay: { color: '#fff', fontSize: 28, textAlign: 'center', maxWidth: W * 0.85, padding: spacing.md, textShadowColor: 'rgba(0,0,0,0.5)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 },
  topBar: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.lg, paddingTop: spacing.lg },
  topBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  topBtnTxt: { fontSize: 18, color: '#fff' },
  topActions: { flexDirection: 'row', gap: spacing.sm },
  textStyleBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  textStyleBtnActive: { backgroundColor: '#fff' },
  textStyleBtnTxt: { color: '#fff', fontSize: 14 },
  bottomBar: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: spacing.xl, gap: spacing.md, paddingBottom: spacing.xxxl },
  colorRow: { flexDirection: 'row', justifyContent: 'center', gap: spacing.sm },
  colorDot: { width: 28, height: 28, borderRadius: 14 },
  colorDotSelected: { borderWidth: 3, borderColor: '#fff', transform: [{ scale: 1.2 }] },
  postBtn: { backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: spacing.lg, borderRadius: borderRadius.lg, gap: spacing.sm },
  postBtnDisabled: { opacity: 0.6 },
  postBtnTxt: { color: '#fff', fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold },
  postBtnArrow: { color: '#fff', fontSize: 20 },
  durationHint: { color: 'rgba(255,255,255,0.5)', fontSize: typography.fontSize.xs, textAlign: 'center' },
});

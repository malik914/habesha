// src/screens/Main/ExploreScreen.jsx — Real-time v2
import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView, Animated,
  TouchableOpacity, Image, ActivityIndicator,
  RefreshControl, TextInput, Dimensions,
} from 'react-native';
import { useAuth }                from '../../context/AuthContext';
import { subscribeToTrending }   from '../../firebase/feedAlgorithm';
import { subscribeToGroups }     from '../../firebase/firestore';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db }                    from '../../firebase/config';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TOPIC_ICONS, BRAND }    from '../../theme/icons';

const { width: W } = Dimensions.get('window');
const HALF = (W - spacing.xl * 2 - spacing.sm) / 2;

const TRENDING_TAGS = [
  { tag: 'photography', color: '#9B5DE5', emoji: TOPIC_ICONS.photography },
  { tag: 'gaming',      color: '#00BBF9', emoji: TOPIC_ICONS.gaming      },
  { tag: 'cooking',     color: '#F15BB5', emoji: TOPIC_ICONS.cooking     },
  { tag: 'fitness',     color: '#06D6A0', emoji: TOPIC_ICONS.fitness     },
  { tag: 'travel',      color: '#FFB703', emoji: TOPIC_ICONS.travel      },
  { tag: 'art',         color: '#FF6B6B', emoji: TOPIC_ICONS.art         },
  { tag: 'music',       color: '#FF4D6D', emoji: TOPIC_ICONS.music       },
  { tag: 'tech',        color: '#48CAE4', emoji: TOPIC_ICONS.tech        },
];

const AnimatedChip = ({ item, index, onPress }) => {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(anim, { toValue: 1, delay: index * 55, tension: 130, friction: 11, useNativeDriver: true }).start();
  }, []);
  return (
    <Animated.View style={{ opacity: anim, transform: [{ scale: anim }] }}>
      <TouchableOpacity
        style={[es.tagChip, { backgroundColor: item.color + '20', borderColor: item.color + '55' }]}
        onPress={() => onPress(item.tag)} activeOpacity={0.75}
      >
        <Text style={es.tagEmoji}>{item.emoji}</Text>
        <View>
          <Text style={[es.tagName, { color: item.color }]}>#{item.tag}</Text>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
};

export default function ExploreScreen({ navigation }) {
  const { user }      = useAuth();
  // ✅ REAL-TIME: Live trending posts (update as people like/comment)
  const [trending, setTrending]   = useState([]);
  // ✅ REAL-TIME: Live groups (member counts update as people join)
  const [groups, setGroups]       = useState([]);
  // ✅ REAL-TIME: Live top creators (follower counts update)
  const [creators, setCreators]   = useState([]);
  const [loading, setL]           = useState(true);
  const [refreshing, setRef]      = useState(false);
  const unsubsRef                 = useRef([]);

  const setupSubscriptions = useCallback(() => {
    // Clear existing subscriptions
    unsubsRef.current.forEach((u) => u());
    unsubsRef.current = [];

    // 1. Live trending posts
    unsubsRef.current.push(
      subscribeToTrending((posts) => {
        setTrending(posts);
        setL(false);
      }, 16)
    );

    // 2. Live popular groups
    unsubsRef.current.push(
      subscribeToGroups((data) => setGroups(data.slice(0, 8)), 8)
    );

    // 3. Live top creators
    const creatorsQ = query(
      collection(db, 'users'),
      orderBy('followersCount', 'desc'),
      limit(10)
    );
    unsubsRef.current.push(
      onSnapshot(creatorsQ, (snap) =>
        setCreators(snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((u2) => u2.uid !== user?.uid))
      )
    );
  }, [user?.uid]);

  useEffect(() => {
    setupSubscriptions();
    return () => unsubsRef.current.forEach((u) => u());
  }, [setupSubscriptions]);

  const onRefresh = () => {
    setRef(true);
    setupSubscriptions();
    setTimeout(() => setRef(false), 1000);
  };

  const PostTile = ({ post, index }) => {
    const isLarge = index % 5 === 0;
    return (
      <TouchableOpacity style={[es.tile, { width: isLarge ? '100%' : HALF, height: isLarge ? 200 : HALF }]} activeOpacity={0.88}>
        {post.imageUrl
          ? <Image source={{ uri: post.imageUrl }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
          : <View style={[StyleSheet.absoluteFillObject, { backgroundColor: colors.topics?.[post.groupTopic] || colors.surfaceHigh }]}>
              <Text style={es.tilePlaceholderTxt}>{post.content?.slice(0, 60)}</Text>
            </View>
        }
        <View style={es.tileMeta}>
          <Text style={es.tileAuthor}>@{post.authorUsername || post.authorName}</Text>
          {/* Live like count */}
          <Text style={es.tileLikes}>❤️ {post.reactions?.['❤️']?.length || post.likes?.length || 0}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  return (
    <SafeAreaView style={es.container}>
      <View style={es.header}>
        <Text style={es.title}>Explore</Text>
        <View style={es.searchBar}>
          <Text style={{ fontSize: 16 }}>🔍</Text>
          <Text style={es.searchPlaceholder} onPress={() => navigation.navigate('Search')}>
            Search people, topics, groups…
          </Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* Trending Topics */}
        <View style={es.section}>
          <View style={es.sectionHeader}>
            <Text style={es.sectionTitle}>🔥 Trending Topics</Text>
            <Text style={es.sectionSub}>This week</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={es.hScroll}>
            {TRENDING_TAGS.map((item, i) => (
              <AnimatedChip key={item.tag} item={item} index={i} onPress={(tag) => navigation.navigate('Hashtag', { tag })} />
            ))}
          </ScrollView>
        </View>

        {/* Live Top Creators */}
        {creators.length > 0 && (
          <View style={es.section}>
            <View style={es.sectionHeader}>
              <Text style={es.sectionTitle}>⭐ Top Creators</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Search')}>
                <Text style={es.seeAll}>See all</Text>
              </TouchableOpacity>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={es.hScroll}>
              {creators.map((c) => {
                const topicColor = colors.topics?.[c.interests?.[0]] || colors.primary;
                return (
                  <TouchableOpacity
                    key={c.uid || c.id}
                    style={es.creatorCard}
                    onPress={() => navigation.navigate('UserProfile', { userId: c.uid || c.id })}
                  >
                    <View style={[es.creatorStrip, { backgroundColor: topicColor + '40' }]} />
                    <View style={es.creatorBody}>
                      {c.photoURL
                        ? <Image source={{ uri: c.photoURL }} style={es.creatorAvatar} />
                        : <View style={[es.creatorAvatarFallback, { backgroundColor: topicColor }]}>
                            <Text style={es.creatorAvatarTxt}>{c.displayName?.[0]?.toUpperCase()}</Text>
                          </View>
                      }
                      <View style={es.creatorNameRow}>
                        <Text style={es.creatorName} numberOfLines={1}>{c.displayName}</Text>
                        {c.verified && <Text style={{ fontSize: 11 }}>{BRAND.verified}</Text>}
                      </View>
                      {/* Live follower count */}
                      <Text style={es.creatorFollowers}>{c.followersCount || 0} followers</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
        )}

        {/* Live Popular Groups */}
        {groups.length > 0 && (
          <View style={es.section}>
            <View style={es.sectionHeader}>
              <Text style={es.sectionTitle}>👥 Popular Groups</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Discover')}>
                <Text style={es.seeAll}>See all</Text>
              </TouchableOpacity>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={es.hScroll}>
              {groups.map((g) => {
                const topicColor = colors.topics?.[g.topic] || colors.primary;
                return (
                  <TouchableOpacity
                    key={g.id}
                    style={[es.groupCard, { borderTopColor: topicColor, borderTopWidth: 3 }]}
                    onPress={() => navigation.navigate('GroupDetail', { groupId: g.id, group: g })}
                  >
                    <Text style={es.groupEmoji}>{TOPIC_ICONS[g.topic] || TOPIC_ICONS.default}</Text>
                    <Text style={es.groupName} numberOfLines={2}>{g.name}</Text>
                    {/* Live member count */}
                    <Text style={es.groupMembers}>{g.memberCount || 0} members</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
        )}

        {/* Live Trending Posts Grid */}
        {trending.length > 0 && (
          <View style={es.section}>
            <View style={es.sectionHeader}>
              <Text style={es.sectionTitle}>📈 Trending Posts</Text>
              <Text style={es.sectionSub}>Last 48h · updates live</Text>
            </View>
            <View style={es.grid}>
              {trending.map((post, i) => <PostTile key={post.id} post={post} index={i} />)}
            </View>
          </View>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const es = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.md },
  title: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderWidth: 1, borderColor: colors.border },
  searchPlaceholder: { fontSize: typography.fontSize.md, color: colors.textMuted },
  section: { paddingTop: spacing.xl },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, marginBottom: spacing.md },
  sectionTitle: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  sectionSub: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  seeAll: { fontSize: typography.fontSize.sm, color: colors.primary, fontWeight: '600' },
  hScroll: { paddingHorizontal: spacing.xl, gap: spacing.md },
  tagChip: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderRadius: borderRadius.lg, borderWidth: 1 },
  tagEmoji: { fontSize: 22 },
  tagName: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.bold },
  creatorCard: { width: 128, backgroundColor: colors.surface, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, ...shadows.sm },
  creatorStrip: { height: 48 },
  creatorBody: { alignItems: 'center', padding: spacing.md, gap: spacing.xs, marginTop: -24 },
  creatorAvatar: { width: 50, height: 50, borderRadius: 25, borderWidth: 2, borderColor: colors.surface },
  creatorAvatarFallback: { width: 50, height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: colors.surface },
  creatorAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  creatorNameRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  creatorName: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.bold, color: colors.textPrimary, maxWidth: 90 },
  creatorFollowers: { fontSize: 10, color: colors.textMuted },
  groupCard: { width: 136, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.md, alignItems: 'center', gap: spacing.sm, borderWidth: 1, borderColor: colors.border, ...shadows.sm },
  groupEmoji: { fontSize: 34 },
  groupName: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.bold, color: colors.textPrimary, textAlign: 'center' },
  groupMembers: { fontSize: 10, color: colors.textMuted },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, paddingHorizontal: spacing.xl },
  tile: { borderRadius: borderRadius.md, overflow: 'hidden', justifyContent: 'flex-end', backgroundColor: colors.surfaceAlt },
  tilePlaceholderTxt: { color: colors.textSecondary, fontSize: 11, padding: spacing.sm, lineHeight: 16 },
  tileMeta: { flexDirection: 'row', justifyContent: 'space-between', padding: spacing.sm, backgroundColor: 'rgba(0,0,0,0.55)' },
  tileAuthor: { color: '#fff', fontSize: 10, fontWeight: '600', flex: 1 },
  tileLikes: { color: '#fff', fontSize: 10 },
});

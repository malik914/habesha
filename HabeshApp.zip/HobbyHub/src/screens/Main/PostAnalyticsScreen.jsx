// src/screens/Main/PostAnalyticsScreen.jsx
import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  ActivityIndicator, TouchableOpacity,
} from 'react-native';
import { getPostAnalytics } from '../../firebase/postActions';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';

export default function PostAnalyticsScreen({ route, navigation }) {
  const { postId, postContent } = route.params;
  const [analytics, setA] = useState(null);
  const [loading, setL]   = useState(true);

  useEffect(() => {
    getPostAnalytics(postId).then((a) => { setA(a); setL(false); });
  }, [postId]);

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );

  const stats = [
    { icon: '👁️',  label: 'Views',          value: analytics?.viewCount,     color: '#48CAE4' },
    { icon: '❤️',  label: 'Reactions',       value: analytics?.likeCount,     color: '#FF4D6D' },
    { icon: '💬',  label: 'Comments',        value: analytics?.commentCount,  color: '#9B5DE5' },
    { icon: '↗️',  label: 'Shares',          value: analytics?.shareCount,    color: '#FFB703' },
    { icon: '🔖',  label: 'Bookmarks',       value: analytics?.bookmarkCount, color: '#06D6A0' },
    { icon: '📊',  label: 'Engagement Rate', value: analytics?.engagementRate,color: '#F15BB5' },
  ];

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={s.back}>← Back</Text>
        </TouchableOpacity>
        <Text style={s.title}>Post Analytics</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView contentContainerStyle={s.body} showsVerticalScrollIndicator={false}>
        {/* Post preview */}
        <View style={s.postPreview}>
          <Text style={s.previewLabel}>Post</Text>
          <Text style={s.previewContent} numberOfLines={3}>{postContent}</Text>
        </View>

        {/* Stat grid */}
        <View style={s.grid}>
          {stats.map(({ icon, label, value, color }) => (
            <View key={label} style={[s.statCard, { borderTopColor: color, borderTopWidth: 3 }]}>
              <Text style={s.statIcon}>{icon}</Text>
              <Text style={[s.statValue, { color }]}>{value ?? '—'}</Text>
              <Text style={s.statLabel}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Tips */}
        <View style={s.tipsCard}>
          <Text style={s.tipsTitle}>💡 Tips to grow your reach</Text>
          {[
            'Post at peak hours: 7–9am and 6–9pm',
            'Use 3–5 relevant hashtags per post',
            'Ask a question to drive comments',
            'Reply to comments within the first hour',
            'Share your post in relevant groups',
          ].map((tip, i) => (
            <View key={i} style={s.tip}>
              <Text style={s.tipNum}>{i + 1}</Text>
              <Text style={s.tipTxt}>{tip}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  back: { color: colors.primary, fontSize: typography.fontSize.md, fontWeight: '600', width: 60 },
  title: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  body: { padding: spacing.xl, gap: spacing.xl },
  postPreview: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  previewLabel: { fontSize: typography.fontSize.xs, color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: spacing.sm },
  previewContent: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 22 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md },
  statCard: { width: '47%', backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, alignItems: 'center', gap: spacing.sm, borderWidth: 1, borderColor: colors.border, ...shadows.sm },
  statIcon: { fontSize: 28 },
  statValue: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black },
  statLabel: { fontSize: typography.fontSize.xs, color: colors.textMuted, textAlign: 'center' },
  tipsCard: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border, gap: spacing.md },
  tipsTitle: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  tip: { flexDirection: 'row', gap: spacing.md, alignItems: 'flex-start' },
  tipNum: { width: 22, height: 22, borderRadius: 11, backgroundColor: colors.primary, color: '#fff', textAlign: 'center', lineHeight: 22, fontSize: 11, fontWeight: '800', flexShrink: 0 },
  tipTxt: { flex: 1, fontSize: typography.fontSize.sm, color: colors.textSecondary, lineHeight: 20 },
});

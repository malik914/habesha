// src/screens/Main/SearchScreen.jsx — Premium dark theme v2
import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, TextInput,
  FlatList, TouchableOpacity, ActivityIndicator, Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { searchUsers } from '../../firebase/follows';
import { getUserByUsername } from '../../firebase/usernames';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { SEARCH_ICONS, TOPIC_ICONS } from '../../theme/icons';
import UserCard from '../../components/UserCard';

const SUGGESTED = [
  { emoji: TOPIC_ICONS.photography, label: 'Photography', color: '#9B5DE5' },
  { emoji: TOPIC_ICONS.gaming,      label: 'Gaming',      color: '#00BBF9' },
  { emoji: TOPIC_ICONS.cooking,     label: 'Cooking',     color: '#F15BB5' },
  { emoji: TOPIC_ICONS.music,       label: 'Music',       color: '#FF4D6D' },
  { emoji: TOPIC_ICONS.travel,      label: 'Travel',      color: '#FFB703' },
  { emoji: TOPIC_ICONS.tech,        label: 'Tech',        color: '#48CAE4' },
];

const useDebounce = (fn, delay) => {
  const timer = useRef(null);
  return useCallback((...args) => { clearTimeout(timer.current); timer.current = setTimeout(() => fn(...args), delay); }, [fn]);
};

export default function SearchScreen({ navigation }) {
  const { user, profile }   = useAuth();
  const [query, setQuery]   = useState('');
  const [results, setResults] = useState([]);
  const [loading, setL]     = useState(false);
  const [searched, setS]    = useState(false);
  const inputRef            = useRef(null);
  const fadeAnim            = useRef(new Animated.Value(1)).current;

  const doSearch = useCallback(async (term) => {
    if (!term.trim()) { setResults([]); setS(false); return; }
    setL(true); setS(true);
    try {
      const users = term.startsWith('@')
        ? await getUserByUsername(term.slice(1)).then((u) => (u && u.uid !== user.uid ? [u] : []))
        : await searchUsers(term, user.uid);
      Animated.sequence([
        Animated.timing(fadeAnim, { toValue: 0, duration: 100, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
      setResults(users);
    } catch (e) { console.error(e); }
    finally { setL(false); }
  }, [user?.uid]);

  const debouncedSearch = useDebounce(doSearch, 380);

  const handleChange = (t) => { setQuery(t); debouncedSearch(t); };
  const handleClear  = () => { setQuery(''); setResults([]); setS(false); inputRef.current?.focus(); };

  return (
    <SafeAreaView style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <Text style={s.title}>Search</Text>
        <View style={s.searchBar}>
          <Text style={s.searchIcon}>{SEARCH_ICONS.search}</Text>
          <TextInput
            ref={inputRef}
            style={s.searchInput}
            value={query}
            onChangeText={handleChange}
            placeholder="Search by name or @username…"
            placeholderTextColor={colors.textMuted}
            autoCapitalize="none"
            returnKeyType="search"
            onSubmitEditing={() => doSearch(query)}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={handleClear} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Text style={s.clearTxt}>{SEARCH_ICONS.clear}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {!searched ? (
        /* Discover state */
        <View style={s.discover}>
          <Text style={s.discoverTitle}>{SEARCH_ICONS.suggest} Explore by Interest</Text>
          <View style={s.chipGrid}>
            {SUGGESTED.map((t) => (
              <TouchableOpacity
                key={t.label}
                style={[s.chip, { backgroundColor: t.color + '20', borderColor: t.color + '55' }]}
                onPress={() => { setQuery(t.label); doSearch(t.label); }}
                activeOpacity={0.75}
              >
                <Text style={s.chipEmoji}>{t.emoji}</Text>
                <Text style={[s.chipLabel, { color: t.color }]}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={s.discoverTitle}>{SEARCH_ICONS.hashtag} Try searching for</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {['@friends', '#photography', 'gamers', 'foodies'].map((tip) => (
              <TouchableOpacity key={tip} style={s.tipChip} onPress={() => { setQuery(tip); doSearch(tip); }}>
                <Text style={s.tipTxt}>{tip}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ) : loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
          <FlatList
            data={results}
            keyExtractor={(item) => item.uid || item.id}
            renderItem={({ item }) => (
              <UserCard
                user={item}
                currentUserId={user.uid}
                currentUserName={profile?.displayName}
                onPress={() => navigation.navigate('UserProfile', { userId: item.uid || item.id })}
              />
            )}
            contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={s.emptyEmoji}>{SEARCH_ICONS.search}</Text>
                <Text style={s.emptyTitle}>No results for "{query}"</Text>
                <Text style={s.emptySub}>Try a different name or @username</Text>
              </View>
            }
          />
        </Animated.View>
      )}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.md },
  title: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderWidth: 1, borderColor: colors.border },
  searchIcon: { fontSize: 16 },
  searchInput: { flex: 1, fontSize: typography.fontSize.md, color: colors.textPrimary },
  clearTxt: { color: colors.textMuted, fontSize: 14, padding: spacing.xs },
  discover: { padding: spacing.xl, gap: spacing.lg },
  discoverTitle: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textSecondary },
  chipGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: borderRadius.full, borderWidth: 1 },
  chipEmoji: { fontSize: 18 },
  chipLabel: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.bold },
  tipChip: { backgroundColor: colors.surfaceAlt, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border },
  tipTxt: { color: colors.textSecondary, fontSize: typography.fontSize.sm },
  empty: { alignItems: 'center', paddingTop: 80, gap: spacing.md },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  emptySub: { color: colors.textSecondary, textAlign: 'center' },
});

// src/screens/Main/MessagesScreen.jsx — Premium dark theme v2
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  SafeAreaView, TextInput, ScrollView, KeyboardAvoidingView,
  Platform, Animated, Image, ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { subscribeToConversations, subscribeToMessages, sendMessage } from '../../firebase/firestore';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TAB_ICONS, MSG_ICONS } from '../../theme/icons';

function timeSince(date) {
  const s = Math.floor((new Date() - date) / 1000);
  if (s < 60) return 'now';
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

// ── Conversation List ─────────────────────────────────────────────
export default function MessagesScreen({ navigation }) {
  const { user } = useAuth();
  const [convs, setConvs]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    // ✅ REAL-TIME: Live conversation list - updates when new messages arrive
    const unsub = subscribeToConversations(user.uid, (data) => {
      setConvs(data);
      setLoading(false);
    });
    return unsub;
  }, [user?.uid]);

  const ConvItem = ({ item }) => {
    const other    = item.participants?.find((p) => p !== user.uid) || '';
    const timeAgo  = item.lastMessageAt?.toDate ? timeSince(item.lastMessageAt.toDate()) : '';
    const unread   = !item.lastReadBy?.[user.uid] && item.lastMessage;
    const anim     = useRef(new Animated.Value(0)).current;

    useEffect(() => {
      Animated.spring(anim, { toValue: 1, tension: 100, friction: 14, useNativeDriver: true }).start();
    }, []);

    return (
      <Animated.View style={{ opacity: anim, transform: [{ translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [-20, 0] }) }] }}>
        <TouchableOpacity
          style={[s.convItem, unread && s.convItemUnread]}
          onPress={() => navigation.navigate('Chat', { conversationId: item.id, title: item.otherUserName || 'Chat', otherUserId: other })}
          activeOpacity={0.78}
        >
          <View style={s.convAvatar}>
            {item.otherUserPhoto
              ? <Image source={{ uri: item.otherUserPhoto }} style={s.convAvatarImg} />
              : <View style={s.convAvatarFallback}>
                  <Text style={s.convAvatarTxt}>{(item.otherUserName || '?')[0].toUpperCase()}</Text>
                </View>
            }
            {item.isOnline && <View style={s.onlineDot} />}
          </View>

          <View style={s.convInfo}>
            <View style={s.convRow}>
              <Text style={[s.convName, unread && s.convNameUnread]} numberOfLines={1}>{item.otherUserName || 'User'}</Text>
              <Text style={s.convTime}>{timeAgo}</Text>
            </View>
            <View style={s.convRow}>
              <Text style={[s.convLast, unread && s.convLastUnread]} numberOfLines={1}>
                {item.lastMessage || 'No messages yet'}
              </Text>
              {unread && <View style={s.unreadBadge}><Text style={s.unreadTxt}>●</Text></View>}
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <Text style={s.headerTitle}>Messages</Text>
        <TouchableOpacity style={s.newMsgBtn}>
          <Text style={s.newMsgIcon}>{MSG_ICONS.new}</Text>
        </TouchableOpacity>
      </View>

      {loading
        ? <ActivityIndicator style={{ marginTop: 60 }} color={colors.primary} />
        : (
          <FlatList
            data={convs}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <ConvItem item={item} />}
            contentContainerStyle={{ flexGrow: 1, paddingVertical: spacing.sm }}
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={s.emptyEmoji}>{TAB_ICONS.messages}</Text>
                <Text style={s.emptyTitle}>No conversations yet</Text>
                <Text style={s.emptySub}>Connect with people in your groups to start chatting</Text>
              </View>
            }
          />
        )
      }
    </SafeAreaView>
  );
}

// ── Chat Screen ────────────────────────────────────────────────────
export function ChatScreen({ route, navigation }) {
  const { conversationId, title } = route.params;
  const { user, profile }         = useAuth();
  const [messages, setMessages]   = useState([]);
  const [text, setText]           = useState('');
  const scrollRef                 = useRef(null);
  const inputScale                = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    navigation.setOptions({ title, headerStyle: { backgroundColor: colors.surface }, headerTintColor: colors.textPrimary });
    const unsub = subscribeToMessages(conversationId, (snap) => {
      setMessages(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    });
    return unsub;
  }, [conversationId]);

  const handleSend = async () => {
    if (!text.trim()) return;
    const msg = text.trim();
    setText('');
    Animated.sequence([
      Animated.spring(inputScale, { toValue: 0.95, tension: 400, useNativeDriver: true }),
      Animated.spring(inputScale, { toValue: 1,    tension: 400, useNativeDriver: true }),
    ]).start();
    try { await sendMessage(conversationId, user.uid, msg); } catch (e) { console.error(e); }
  };

  const Bubble = ({ msg }) => {
    const isMe  = msg.senderId === user.uid;
    const time  = msg.createdAt?.toDate ? timeSince(msg.createdAt.toDate()) : '';
    const anim  = useRef(new Animated.Value(0)).current;
    useEffect(() => {
      Animated.spring(anim, { toValue: 1, tension: 200, friction: 14, useNativeDriver: true }).start();
    }, []);
    return (
      <Animated.View
        style={[
          cs.bubbleWrap, isMe && cs.bubbleWrapMe,
          { opacity: anim, transform: [{ scale: anim }, { translateY: anim.interpolate({ inputRange: [0,1], outputRange: [8, 0] }) }] }
        ]}
      >
        {!isMe && (
          <View style={cs.bubbleAvatar}>
            <Text style={cs.bubbleAvatarTxt}>{title?.[0]?.toUpperCase()}</Text>
          </View>
        )}
        <View style={[cs.bubble, isMe && cs.bubbleMe]}>
          <Text style={[cs.bubbleTxt, isMe && cs.bubbleTxtMe]}>{msg.text}</Text>
        </View>
        <Text style={[cs.bubbleTime, isMe && { textAlign: 'right' }]}>{time}</Text>
      </Animated.View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={cs.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm }}
        showsVerticalScrollIndicator={false}
      >
        {messages.map((msg) => <Bubble key={msg.id} msg={msg} />)}
      </ScrollView>

      <View style={cs.inputBar}>
        <TouchableOpacity style={cs.attachBtn}>
          <Text style={cs.attachIcon}>{MSG_ICONS.attach}</Text>
        </TouchableOpacity>
        <Animated.View style={[cs.inputWrap, { transform: [{ scale: inputScale }] }]}>
          <TextInput
            style={cs.input}
            value={text}
            onChangeText={setText}
            placeholder="Message..."
            placeholderTextColor={colors.textMuted}
            multiline
            maxLength={1000}
          />
        </Animated.View>
        <TouchableOpacity
          style={[cs.sendBtn, !text.trim() && cs.sendBtnOff]}
          onPress={handleSend}
          disabled={!text.trim()}
        >
          <Text style={cs.sendIcon}>▶</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  headerTitle: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  newMsgBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  newMsgIcon: { fontSize: 17 },
  convItem: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, gap: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  convItemUnread: { backgroundColor: colors.surfaceAlt + '80' },
  convAvatar: { position: 'relative', flexShrink: 0 },
  convAvatarImg: { width: 52, height: 52, borderRadius: 26 },
  convAvatarFallback: { width: 52, height: 52, borderRadius: 26, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  convAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  onlineDot: { position: 'absolute', bottom: 1, right: 1, width: 13, height: 13, borderRadius: 7, backgroundColor: colors.success, borderWidth: 2, borderColor: colors.background },
  convInfo: { flex: 1, gap: 4 },
  convRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  convName: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.semibold, color: colors.textSecondary },
  convNameUnread: { color: colors.textPrimary, fontWeight: typography.fontWeight.black },
  convTime: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  convLast: { fontSize: typography.fontSize.sm, color: colors.textMuted, flex: 1 },
  convLastUnread: { color: colors.textSecondary, fontWeight: typography.fontWeight.medium },
  unreadBadge: { marginLeft: spacing.sm },
  unreadTxt: { color: colors.primary, fontSize: 10 },
  empty: { alignItems: 'center', paddingTop: 100, gap: spacing.md },
  emptyEmoji: { fontSize: 56 },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  emptySub: { color: colors.textSecondary, textAlign: 'center', paddingHorizontal: spacing.xl, lineHeight: 22 },
});

const cs = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  bubbleWrap: { alignItems: 'flex-start', gap: 3 },
  bubbleWrapMe: { alignItems: 'flex-end' },
  bubbleAvatar: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.surfaceHigh, justifyContent: 'center', alignItems: 'center' },
  bubbleAvatarTxt: { color: colors.textSecondary, fontSize: 11, fontWeight: '700' },
  bubble: { backgroundColor: colors.surfaceHigh, borderRadius: borderRadius.lg, paddingHorizontal: spacing.lg, paddingVertical: spacing.md, maxWidth: '75%', borderWidth: 1, borderColor: colors.border },
  bubbleMe: { backgroundColor: colors.primary, borderColor: colors.primaryDark },
  bubbleTxt: { fontSize: typography.fontSize.md, color: colors.textPrimary, lineHeight: 20 },
  bubbleTxtMe: { color: '#fff' },
  bubbleTime: { fontSize: 10, color: colors.textMuted, marginHorizontal: 4 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', gap: spacing.sm, padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.surface },
  attachBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center' },
  attachIcon: { fontSize: 18 },
  inputWrap: { flex: 1, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg, borderWidth: 1, borderColor: colors.border },
  input: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm, fontSize: typography.fontSize.md, color: colors.textPrimary, maxHeight: 100 },
  sendBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', ...shadows.glow },
  sendBtnOff: { backgroundColor: colors.surfaceHigh, boxShadow: 'none' },
  sendIcon: { color: '#fff', fontSize: 14, fontWeight: '700' },
});

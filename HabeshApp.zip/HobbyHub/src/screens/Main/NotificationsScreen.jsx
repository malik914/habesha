// src/screens/Main/NotificationsScreen.jsx — Premium dark theme v2
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  SafeAreaView, Animated, ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { subscribeToNotifications, markNotificationRead, markAllNotificationsRead } from '../../firebase/firestore';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { NOTIF_ICONS } from '../../theme/icons';

const NOTIF_MESSAGES = {
  like:     (name) => `${name} reacted to your post`,
  comment:  (name) => `${name} commented on your post`,
  follow:   (name) => `${name} started following you`,
  message:  (name) => `${name} sent you a message`,
  mention:  (name) => `${name} mentioned you`,
  group:    (name) => `New post in a group you follow`,
};

const NOTIF_COLORS = {
  like:    colors.primary,
  comment: '#48CAE4',
  follow:  '#06D6A0',
  message: '#FFB703',
  mention: '#9B5DE5',
  group:   '#F15BB5',
  default: colors.textMuted,
};

function timeSince(date) {
  const s = Math.floor((new Date() - date) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

const NotifItem = ({ item, currentUserId, onRead }) => {
  const anim  = useRef(new Animated.Value(0)).current;
  const icon  = NOTIF_ICONS[item.type]  || NOTIF_ICONS.default;
  const color = NOTIF_COLORS[item.type] || NOTIF_COLORS.default;
  const msg   = NOTIF_MESSAGES[item.type]?.(item.fromUserName || 'Someone') || 'sent you a notification';
  const time  = item.createdAt?.toDate ? timeSince(item.createdAt.toDate()) : '';

  useEffect(() => {
    Animated.spring(anim, { toValue: 1, tension: 100, friction: 14, useNativeDriver: true }).start();
  }, []);

  return (
    <Animated.View style={{ opacity: anim, transform: [{ translateX: anim.interpolate({ inputRange: [0,1], outputRange: [-16, 0] }) }] }}>
      <TouchableOpacity
        style={[s.item, !item.read && s.itemUnread]}
        onPress={() => onRead(item)}
        activeOpacity={0.75}
      >
        {/* Colored left bar for unread */}
        {!item.read && <View style={[s.unreadBar, { backgroundColor: color }]} />}

        <View style={[s.iconWrap, { backgroundColor: color + '20' }]}>
          <Text style={s.icon}>{icon}</Text>
        </View>

        <View style={s.itemContent}>
          <Text style={s.itemText}>
            <Text style={s.bold}>{item.fromUserName || 'Someone'}</Text>
            {'  '}{msg.replace(item.fromUserName || 'Someone', '').trim()}
          </Text>
          <Text style={s.itemTime}>{time}</Text>
        </View>

        {!item.read && <View style={s.dot} />}
      </TouchableOpacity>
    </Animated.View>
  );
};

export default function NotificationsScreen() {
  const { user }          = useAuth();
  const [notifs, setNotifs] = useState([]);
  const [loading, setL]   = useState(true);

  const unreadCount = notifs.filter((n) => !n.read).length;

  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToNotifications(user.uid, (snap) => {
      setNotifs(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setL(false);
    });
    return unsub;
  }, [user]);

  const handleRead = async (notif) => {
    if (!notif.read) await markNotificationRead(notif.id);
  };

  const handleMarkAll = async () => {
    if (user) await markAllNotificationsRead(user.uid);
  };

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Notifications</Text>
          {unreadCount > 0 && <Text style={s.unreadCount}>{unreadCount} new</Text>}
        </View>
        {unreadCount > 0 && (
          <TouchableOpacity onPress={handleMarkAll} style={s.markAllBtn}>
            <Text style={s.markAllTxt}>Mark all read</Text>
          </TouchableOpacity>
        )}
      </View>

      {loading
        ? <ActivityIndicator style={{ marginTop: 60 }} color={colors.primary} />
        : (
          <FlatList
            data={notifs}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <NotifItem item={item} currentUserId={user?.uid} onRead={handleRead} />}
            contentContainerStyle={{ flexGrow: 1, paddingVertical: spacing.sm }}
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={s.emptyEmoji}>{NOTIF_ICONS.system}</Text>
                <Text style={s.emptyTitle}>All caught up!</Text>
                <Text style={s.emptySub}>We'll notify you when something happens in your communities</Text>
              </View>
            }
          />
        )
      }
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  headerTitle: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  unreadCount: { fontSize: typography.fontSize.sm, color: colors.primary, fontWeight: typography.fontWeight.bold, marginTop: 2 },
  markAllBtn: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border },
  markAllTxt: { color: colors.textSecondary, fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.medium },
  item: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, gap: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, position: 'relative' },
  itemUnread: { backgroundColor: colors.surfaceAlt + '60' },
  unreadBar: { position: 'absolute', left: 0, top: 8, bottom: 8, width: 3, borderRadius: 2 },
  iconWrap: { width: 46, height: 46, borderRadius: 23, justifyContent: 'center', alignItems: 'center', flexShrink: 0 },
  icon: { fontSize: 22 },
  itemContent: { flex: 1, gap: 4 },
  itemText: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 20 },
  bold: { fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  itemTime: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary, flexShrink: 0 },
  empty: { alignItems: 'center', paddingTop: 100, gap: spacing.md },
  emptyEmoji: { fontSize: 56 },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  emptySub: { color: colors.textSecondary, textAlign: 'center', paddingHorizontal: spacing.xl, lineHeight: 22 },
});

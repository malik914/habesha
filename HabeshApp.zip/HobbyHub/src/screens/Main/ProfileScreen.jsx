// src/screens/Main/ProfileScreen.jsx — Real-time v2
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  TouchableOpacity, TextInput, Alert, ActivityIndicator,
  Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { updateUserProfile, subscribeToUserProfile } from '../../firebase/firestore';
import { AvatarUpload } from '../../hooks/useImagePicker';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { PROFILE_ICONS, BRAND, TOPIC_ICONS } from '../../theme/icons';
import { haptic } from '../../utils/haptics';

export default function ProfileScreen({ navigation }) {
  const { user, profile, refreshProfile } = useAuth();
  // ✅ REAL-TIME: Live profile data (follower counts update instantly)
  const [liveProfile, setLiveProfile] = useState(profile);
  const [editing, setEditing] = useState(false);
  const [bio, setBio]         = useState(profile?.bio || '');
  const [saving, setSaving]   = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!user?.uid) return;
    const unsub = subscribeToUserProfile(user.uid, (data) => {
      setLiveProfile(data);
    });
    return unsub;
  }, [user?.uid]);

  const handleSave = async () => {
    setSaving(true);
    haptic.medium();
    try {
      await updateUserProfile(user.uid, { bio });
      await refreshProfile();
      setEditing(false);
      haptic.success();
    } catch {
      haptic.error();
      Alert.alert('Error', 'Could not save profile.');
    } finally { setSaving(false); }
  };

  const p = liveProfile || profile;
  const followers  = p?.followersCount || 0;
  const following  = p?.followingCount || 0;
  const groups     = p?.joinedGroups?.length || 0;

  return (
    <SafeAreaView style={s.container}>
      <View style={s.topNav}>
        <Text style={s.navTitle}>Profile</Text>
        <View style={{ flexDirection: 'row', gap: spacing.md }}>
          <TouchableOpacity style={s.navBtn} onPress={() => navigation.navigate('Bookmarks')}>
            <Text style={s.navBtnIcon}>{PROFILE_ICONS.bookmarks}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.navBtn} onPress={() => navigation.navigate('Settings')}>
            <Text style={s.navBtnIcon}>{PROFILE_ICONS.settings}</Text>
          </TouchableOpacity>
        </View>
      </View>

      <Animated.ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={s.hero}>
          <View style={s.heroMesh} /><View style={s.heroMesh2} />
          <AvatarUpload user={user} profile={p} onUpdated={refreshProfile} size={96} />
          <View style={s.nameRow}>
            <Text style={s.displayName}>{p?.displayName}</Text>
            {p?.verified  && <Text style={{ fontSize: 18 }}>{BRAND.verified}</Text>}
            {p?.isPremium && <Text style={{ fontSize: 18 }}>{BRAND.premium}</Text>}
          </View>
          {p?.username && <Text style={s.username}>@{p.username}</Text>}
        </View>

        {/* Live stats */}
        <View style={s.statsCard}>
          {[
            { val: followers, label: 'Followers',  onPress: () => navigation.navigate('UserProfile', { userId: user.uid }) },
            { val: following, label: 'Following',  onPress: () => navigation.navigate('UserProfile', { userId: user.uid }) },
            { val: groups,    label: 'Groups',     onPress: null },
          ].map(({ val, label, onPress }, i) => (
            <React.Fragment key={label}>
              {i > 0 && <View style={s.statDiv} />}
              <TouchableOpacity style={s.stat} onPress={onPress} disabled={!onPress} activeOpacity={0.7}>
                <Text style={s.statVal}>{val}</Text>
                <Text style={s.statLbl}>{label}</Text>
              </TouchableOpacity>
            </React.Fragment>
          ))}
        </View>

        {/* Bio */}
        <View style={s.section}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>About</Text>
            {!editing
              ? <TouchableOpacity style={s.editBtn} onPress={() => setEditing(true)}>
                  <Text style={s.editBtnTxt}>{PROFILE_ICONS.edit} Edit</Text>
                </TouchableOpacity>
              : <View style={{ flexDirection: 'row', gap: spacing.sm }}>
                  <TouchableOpacity style={s.cancelBtn} onPress={() => { setBio(p?.bio || ''); setEditing(false); }}>
                    <Text style={s.cancelBtnTxt}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[s.saveBtn, saving && { opacity: 0.6 }]} onPress={handleSave} disabled={saving}>
                    {saving ? <ActivityIndicator size="small" color="#fff" /> : <Text style={s.saveBtnTxt}>Save</Text>}
                  </TouchableOpacity>
                </View>
            }
          </View>
          {editing
            ? <>
                <TextInput style={s.bioInput} value={bio} onChangeText={setBio} placeholder="Tell people about yourself…" placeholderTextColor={colors.textMuted} multiline maxLength={200} autoFocus />
                <Text style={s.charCount}>{bio.length}/200</Text>
              </>
            : <Text style={s.bioText}>{p?.bio || 'No bio yet. Tap Edit to add one!'}</Text>
          }
        </View>

        {/* Interests with live color */}
        {p?.interests?.length > 0 && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>Interests</Text>
            <View style={s.interests}>
              {p.interests.map((tag) => {
                const c = colors.topics?.[tag] || colors.primary;
                return (
                  <View key={tag} style={[s.tag, { backgroundColor: c + '20', borderColor: c + '50' }]}>
                    <Text style={{ fontSize: 13 }}>{TOPIC_ICONS[tag]}</Text>
                    <Text style={[s.tagTxt, { color: c }]}>{tag}</Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Account info */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>Account</Text>
          {[
            { icon: '📧', label: 'Email',       value: user?.email },
            { icon: '📅', label: 'Member since', value: p?.createdAt?.toDate?.()?.getFullYear?.() || '—' },
            { icon: '🌍', label: 'Account type', value: p?.isPremium ? `${BRAND.premium} Premium` : 'Free' },
          ].map(({ icon, label, value }) => (
            <View key={label} style={s.infoRow}>
              <Text style={s.infoIcon}>{icon}</Text>
              <Text style={s.infoLabel}>{label}</Text>
              <Text style={s.infoValue}>{value}</Text>
            </View>
          ))}
        </View>

        <View style={{ height: 80 }} />
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  topNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  navTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  navBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  navBtnIcon: { fontSize: 17 },
  hero: { backgroundColor: colors.surface, alignItems: 'center', paddingTop: spacing.xxl, paddingBottom: spacing.xl, gap: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, overflow: 'hidden' },
  heroMesh: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: colors.primary, top: -180, right: -100, opacity: 0.1 },
  heroMesh2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: colors.accent, bottom: -120, left: -60, opacity: 0.08 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  displayName: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  username: { fontSize: typography.fontSize.md, color: colors.textMuted },
  statsCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, marginHorizontal: spacing.lg, marginTop: spacing.lg, borderRadius: borderRadius.xl, paddingVertical: spacing.lg, borderWidth: 1, borderColor: colors.border, ...shadows.sm },
  stat: { flex: 1, alignItems: 'center' },
  statVal: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  statLbl: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 2, textTransform: 'uppercase', letterSpacing: 0.5 },
  statDiv: { width: 1, height: 36, backgroundColor: colors.border },
  section: { marginHorizontal: spacing.lg, marginTop: spacing.lg, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md },
  sectionTitle: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  editBtn: { backgroundColor: colors.surfaceAlt, paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border },
  editBtnTxt: { color: colors.textSecondary, fontSize: typography.fontSize.sm },
  cancelBtn: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border },
  cancelBtnTxt: { color: colors.textSecondary, fontSize: typography.fontSize.sm },
  saveBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full },
  saveBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.sm },
  bioText: { fontSize: typography.fontSize.md, color: colors.textSecondary, lineHeight: 22 },
  bioInput: { fontSize: typography.fontSize.md, color: colors.textPrimary, lineHeight: 22, minHeight: 80, textAlignVertical: 'top', borderWidth: 1, borderColor: colors.border, borderRadius: borderRadius.md, padding: spacing.md },
  charCount: { textAlign: 'right', color: colors.textMuted, fontSize: typography.fontSize.xs, marginTop: spacing.xs },
  interests: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  tag: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1 },
  tagTxt: { fontSize: typography.fontSize.sm, fontWeight: '600', textTransform: 'capitalize' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  infoIcon: { fontSize: 18, width: 28 },
  infoLabel: { flex: 1, fontSize: typography.fontSize.md, color: colors.textSecondary },
  infoValue: { fontSize: typography.fontSize.sm, color: colors.textMuted },
});

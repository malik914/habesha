// src/screens/Main/FeedScreen.jsx — Real-time v3
import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View, Text, FlatList, StyleSheet, SafeAreaView,
  RefreshControl, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, Modal, Alert,
  Image, Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { createPost } from '../../firebase/firestore';
import { subscribeToSmartFeed } from '../../firebase/feedAlgorithm';
import StoryBar from '../../components/StoryBar';
import { ReactionBar } from '../../firebase/reactions';
import { toggleBookmark, isBookmarked } from '../../firebase/bookmarks';
import { HashtagText } from '../../firebase/hashtags';
import { extractHashtags, registerHashtags } from '../../firebase/hashtags';
import { CommentsSheet } from '../../firebase/comments';
import { ImageViewer, compressPostImage } from '../../utils/imageUtils';
import { haptic } from '../../utils/haptics';
import { sharePost } from '../../utils/appUtils';
import { useImagePicker } from '../../hooks/useImagePicker';
import { uploadPostImage } from '../../firebase/storage';
import { FeedSkeleton } from '../../components/Skeleton';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { POST_ACTIONS, BRAND } from '../../theme/icons';

function timeSince(date) {
  const s = Math.floor((new Date() - date) / 1000);
  if (s < 60) return 'now';
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

// ── Live Post Card ─────────────────────────────────────────────────
const PostCard = React.memo(({ post, currentUserId, navigation }) => {
  const [bookmarked, setBookmarked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [viewingImage, setViewingImage] = useState(false);
  const heartScale = useRef(new Animated.Value(1)).current;
  const cardAnim   = useRef(new Animated.Value(0)).current;
  const timeAgo    = post.createdAt?.toDate ? timeSince(post.createdAt.toDate()) : 'now';

  useEffect(() => {
    isBookmarked(currentUserId, post.id).then(setBookmarked);
    // Entrance animation
    Animated.spring(cardAnim, { toValue: 1, tension: 80, friction: 14, useNativeDriver: true }).start();
  }, []);

  const handleBookmark = async () => {
    haptic.light();
    const next = await toggleBookmark(currentUserId, post.id);
    setBookmarked(next);
  };

  const handleShare = () => {
    haptic.light();
    sharePost(post);
  };

  const handleComment = () => {
    haptic.light();
    setShowComments(true);
  };

  return (
    <>
      <Animated.View style={[pc.card, {
        opacity: cardAnim,
        transform: [{ translateY: cardAnim.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }],
      }]}>
        {/* Glow strip based on score */}
        {post._score > 70 && <View style={[pc.scoreGlow, { backgroundColor: colors.accent }]} />}

        {/* Author */}
        <TouchableOpacity
          style={pc.authorRow}
          onPress={() => navigation?.navigate('UserProfile', { userId: post.authorId })}
          activeOpacity={0.7}
        >
          <View style={pc.avatarWrap}>
            {post.authorPhoto
              ? <Image source={{ uri: post.authorPhoto }} style={pc.avatar} />
              : <View style={pc.avatarFallback}><Text style={pc.avatarTxt}>{post.authorName?.[0]?.toUpperCase()}</Text></View>
            }
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.xs }}>
              <Text style={pc.authorName}>{post.authorName || 'Anonymous'}</Text>
              {post.authorVerified && <Text style={{ fontSize: 12 }}>{BRAND.verified}</Text>}
              {post.edited && <Text style={pc.editedBadge}>edited</Text>}
            </View>
            <Text style={pc.authorMeta}>
              {post.authorUsername ? `@${post.authorUsername} · ` : ''}{post.groupName || ''}{post.groupName ? ' · ' : ''}{timeAgo}
            </Text>
          </View>
          <TouchableOpacity style={pc.moreBtn} onPress={() => {}} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Text style={pc.moreTxt}>{POST_ACTIONS.more}</Text>
          </TouchableOpacity>
        </TouchableOpacity>

        {/* Content with tappable hashtags */}
        <HashtagText
          text={post.content}
          style={pc.content}
          numberOfLines={6}
          onHashtagPress={(tag) => navigation?.navigate('Hashtag', { tag })}
        />

        {/* Post image */}
        {post.imageUrl && (
          <TouchableOpacity style={pc.imageWrap} onPress={() => setViewingImage(true)} activeOpacity={0.92}>
            <Image source={{ uri: post.imageUrl }} style={pc.postImage} resizeMode="cover" />
            <View style={pc.imageHint}><Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11 }}>Tap to expand</Text></View>
          </TouchableOpacity>
        )}

        {/* Live reactions (subscribed internally) */}
        <View style={pc.reactionsRow}>
          <ReactionBar
            postId={post.id}
            initialReactions={post.reactions}
            currentUserId={currentUserId}
          />
        </View>

        {/* Actions bar */}
        <View style={pc.actions}>
          <TouchableOpacity style={pc.actionBtn} onPress={handleComment} activeOpacity={0.7}>
            <Text style={pc.actionIcon}>{POST_ACTIONS.comment}</Text>
            <Text style={pc.actionCount}>{post.commentCount || 0}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={pc.actionBtn} onPress={handleShare} activeOpacity={0.7}>
            <Text style={pc.actionIcon}>{POST_ACTIONS.share}</Text>
            <Text style={pc.actionCount}>Share</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[pc.actionBtn, { marginLeft: 'auto' }]}
            onPress={handleBookmark}
            activeOpacity={0.7}
          >
            <Text style={pc.actionIcon}>{bookmarked ? POST_ACTIONS.bookmarked : POST_ACTIONS.bookmark}</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>

      {/* Comments sheet */}
      <CommentsSheet visible={showComments} onClose={() => setShowComments(false)} post={post} />

      {/* Full-screen image viewer */}
      {post.imageUrl && (
        <ImageViewer
          uri={post.imageUrl}
          visible={viewingImage}
          onClose={() => setViewingImage(false)}
          caption={post.content}
          authorName={post.authorName}
        />
      )}
    </>
  );
});

// ── Feed Screen ────────────────────────────────────────────────────
export default function FeedScreen({ navigation }) {
  const { user, profile }   = useAuth();
  const [posts, setPosts]   = useState([]);
  const [loading, setL]     = useState(true);
  const [refreshing, setRef]= useState(false);
  const [showCompose, setSC] = useState(false);
  const [newPost, setNP]    = useState('');
  const [postImage, setPI]  = useState(null);
  const [posting, setPost]  = useState(false);
  const { showPickerOptions } = useImagePicker();
  const unsubRef = useRef(null);

  const startFeed = useCallback(async () => {
    if (!user || !profile) return;
    // Unsubscribe from previous subscription
    if (unsubRef.current) { unsubRef.current(); unsubRef.current = null; }
    setL(true);
    try {
      unsubRef.current = await subscribeToSmartFeed(
        { userId: user.uid, userInterests: profile.interests || [], joinedGroups: profile.joinedGroups || [] },
        (ranked) => { setPosts(ranked); setL(false); setRef(false); }
      );
    } catch (e) { console.error('Feed subscription error:', e); setL(false); }
  }, [user?.uid, profile?.joinedGroups?.join(','), profile?.interests?.join(',')]);

  useEffect(() => {
    startFeed();
    return () => { if (unsubRef.current) unsubRef.current(); };
  }, [startFeed]);

  const onRefresh = useCallback(async () => {
    setRef(true);
    await startFeed();
  }, [startFeed]);

  const handlePost = async () => {
    if (!newPost.trim() && !postImage) return;
    const groups = profile?.joinedGroups || [];
    if (!groups.length) { Alert.alert('Join a group first', 'Join a group before posting.'); return; }
    setPost(true);
    haptic.medium();
    try {
      let imageUrl = null;
      if (postImage) {
        const compressed = await compressPostImage(postImage);
        imageUrl = await uploadPostImage(user.uid, compressed);
      }
      const hashtags = extractHashtags(newPost.trim());
      const postRef = await createPost({
        authorId:       user.uid,
        authorName:     profile?.displayName || user.displayName,
        authorUsername: profile?.username    || null,
        authorPhoto:    profile?.photoURL    || null,
        authorVerified: profile?.verified    || false,
        groupId:        groups[0],
        groupName:      'My Group',
        content:        newPost.trim(),
        imageUrl,
        hashtags,
      });
      if (hashtags.length) await registerHashtags(postRef.id, hashtags);
      haptic.success();
      setNP(''); setPI(null); setSC(false);
      // Feed auto-updates via onSnapshot — no manual reload needed
    } catch (e) {
      haptic.error();
      Alert.alert('Error', 'Could not post. Please try again.');
    } finally { setPost(false); }
  };

  return (
    <SafeAreaView style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.greeting}>Good {getTimeOfDay()},</Text>
          <Text style={s.name}>{profile?.displayName?.split(' ')[0] || 'Friend'} 👋</Text>
        </View>
        <TouchableOpacity style={s.composeBtn} onPress={() => { haptic.light(); setSC(true); }}>
          <Text style={s.composeTxt}>+ Post</Text>
        </TouchableOpacity>
      </View>

      {/* Feed */}
      {loading
        ? <FeedSkeleton />
        : (
          <FlatList
            data={posts}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <PostCard post={item} currentUserId={user?.uid} navigation={navigation} />
            )}
            ListHeaderComponent={<StoryBar onAddStory={() => navigation.navigate('CreateStory')} />}
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={{ fontSize: 64 }}>🌱</Text>
                <Text style={s.emptyTitle}>Your feed is empty</Text>
                <Text style={s.emptySub}>Join groups to see posts from your community</Text>
                <TouchableOpacity style={s.exploreBtn} onPress={() => navigation.navigate('Explore')}>
                  <Text style={s.exploreBtnTxt}>Explore Groups →</Text>
                </TouchableOpacity>
              </View>
            }
            contentContainerStyle={{ paddingBottom: spacing.xxxl }}
            ItemSeparatorComponent={() => <View style={{ height: spacing.md }} />}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
            showsVerticalScrollIndicator={false}
            onEndReachedThreshold={0.5}
          />
        )
      }

      {/* Compose Modal */}
      <Modal visible={showCompose} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSC(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={cm.container}>
          <View style={cm.header}>
            <TouchableOpacity onPress={() => { setSC(false); setNP(''); setPI(null); }}>
              <Text style={cm.cancel}>Cancel</Text>
            </TouchableOpacity>
            <Text style={cm.title}>New Post</Text>
            <TouchableOpacity
              onPress={handlePost}
              disabled={posting || (!newPost.trim() && !postImage)}
              style={[cm.postBtn, (posting || (!newPost.trim() && !postImage)) && cm.postBtnOff]}
            >
              <Text style={cm.postBtnTxt}>{posting ? '…' : 'Post'}</Text>
            </TouchableOpacity>
          </View>

          <View style={cm.authorRow}>
            <View style={cm.avatar}><Text style={cm.avatarTxt}>{profile?.displayName?.[0]?.toUpperCase()}</Text></View>
            <View>
              <Text style={cm.authorName}>{profile?.displayName}</Text>
              {profile?.username && <Text style={cm.username}>@{profile.username}</Text>}
            </View>
          </View>

          <TextInput
            style={cm.input}
            value={newPost}
            onChangeText={setNP}
            placeholder="What's on your mind? Use #hashtags and @mentions"
            placeholderTextColor={colors.textMuted}
            multiline
            autoFocus
            maxLength={500}
          />

          {postImage && (
            <View style={cm.imgPreview}>
              <Image source={{ uri: postImage }} style={cm.previewImg} />
              <TouchableOpacity style={cm.removeImg} onPress={() => setPI(null)}>
                <Text style={{ color: '#fff', fontWeight: '700' }}>✕</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={cm.toolbar}>
            <TouchableOpacity onPress={async () => { const uri = await showPickerOptions(); if (uri) setPI(uri); }}>
              <Text style={cm.toolbarIcon}>🖼️</Text>
            </TouchableOpacity>
            <Text style={cm.charCount}>{newPost.length}/500</Text>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

function getTimeOfDay() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}

const pc = StyleSheet.create({
  card: { backgroundColor: colors.surface, marginHorizontal: spacing.lg, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border },
  scoreGlow: { height: 2, opacity: 0.8 },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.lg, paddingBottom: spacing.sm },
  avatarWrap: { position: 'relative' },
  avatar: { width: 44, height: 44, borderRadius: 22 },
  avatarFallback: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontWeight: '700', fontSize: 18 },
  authorName: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  editedBadge: { fontSize: 10, color: colors.textMuted, backgroundColor: colors.surfaceAlt, paddingHorizontal: 5, paddingVertical: 1, borderRadius: 4 },
  authorMeta: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 1 },
  moreBtn: { padding: spacing.sm },
  moreTxt: { color: colors.textMuted, fontSize: 20, letterSpacing: 2 },
  content: { fontSize: typography.fontSize.md, color: colors.textPrimary, lineHeight: 22, paddingHorizontal: spacing.lg, paddingBottom: spacing.md },
  imageWrap: { marginHorizontal: spacing.lg, marginBottom: spacing.sm, borderRadius: borderRadius.md, overflow: 'hidden', position: 'relative' },
  postImage: { width: '100%', height: 220, backgroundColor: colors.surfaceAlt },
  imageHint: { position: 'absolute', bottom: spacing.sm, right: spacing.sm },
  reactionsRow: { paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  actions: { flexDirection: 'row', alignItems: 'center', gap: spacing.xl, paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  actionIcon: { fontSize: 19 },
  actionCount: { fontSize: typography.fontSize.sm, color: colors.textSecondary },
});

const cm = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: spacing.xl, borderBottomWidth: 1, borderBottomColor: colors.border },
  cancel: { color: colors.textSecondary, fontSize: typography.fontSize.md },
  title: { fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  postBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: borderRadius.full },
  postBtnOff: { opacity: 0.4 },
  postBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.xl, paddingVertical: spacing.md },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: '#fff', fontWeight: '700', fontSize: 16 },
  authorName: { fontWeight: typography.fontWeight.semibold, color: colors.textPrimary },
  username: { fontSize: typography.fontSize.xs, color: colors.textMuted },
  input: { flex: 1, fontSize: typography.fontSize.lg, color: colors.textPrimary, paddingHorizontal: spacing.xl, textAlignVertical: 'top', lineHeight: 26 },
  imgPreview: { marginHorizontal: spacing.xl, borderRadius: borderRadius.md, overflow: 'hidden', position: 'relative' },
  previewImg: { width: '100%', height: 160 },
  removeImg: { position: 'absolute', top: spacing.sm, right: spacing.sm, width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  toolbar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  toolbarIcon: { fontSize: 24 },
  charCount: { color: colors.textMuted, fontSize: typography.fontSize.sm },
});

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  greeting: { fontSize: typography.fontSize.sm, color: colors.textMuted },
  name: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  composeBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: borderRadius.full, ...shadows.glow },
  composeTxt: { color: '#fff', fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.sm },
  empty: { alignItems: 'center', paddingTop: 80, gap: spacing.md, paddingHorizontal: spacing.xl },
  emptyTitle: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  emptySub: { color: colors.textSecondary, textAlign: 'center', lineHeight: 22 },
  exploreBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.xl, paddingVertical: spacing.md, borderRadius: borderRadius.full },
  exploreBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.bold },
});

// src/screens/Main/UserProfileScreen.jsx — Premium dark v2
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  Image, TouchableOpacity, ActivityIndicator, RefreshControl, Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { getUserById, getFollowers, getFollowing, getUsersByIds, followUser, unfollowUser, subscribeFollowStatus } from '../../firebase/follows';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { PROFILE_ICONS, TOPIC_ICONS, BRAND } from '../../theme/icons';
import UserCard from '../../components/UserCard';
import { shareProfile } from '../../utils/appUtils';
import { haptic } from '../../utils/haptics';

const TABS = ['Posts', 'Followers', 'Following'];

export default function UserProfileScreen({ route, navigation }) {
  const { userId }         = route.params;
  const { user: me, profile: myProfile } = useAuth();
  const [profile, setProfile]   = useState(null);
  const [following, setFollowing] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [tab, setTab]           = useState(0);
  const [followers, setFollowers] = useState([]);
  const [followingList, setFL]  = useState([]);
  const [listLoading, setLL]    = useState(false);
  const [refreshing, setRef]    = useState(false);
  const isSelf = me?.uid === userId;
  const headerAnim = Animated.Value ? new Animated.Value(0) : { interpolate: () => {} };

  const loadProfile = useCallback(async () => {
    const data = await getUserById(userId);
    setProfile(data);
    navigation.setOptions({ title: data?.displayName || 'Profile' });
  }, [userId]);

  useEffect(() => { loadProfile(); }, [loadProfile]);

  useEffect(() => {
    if (!me?.uid || isSelf) return;
    const unsub = subscribeFollowStatus(me.uid, userId, setFollowing);
    return unsub;
  }, [me?.uid, userId, isSelf]);

  useEffect(() => {
    if (tab === 1) { setLL(true); getFollowers(userId).then(getUsersByIds).then(setFollowers).finally(() => setLL(false)); }
    if (tab === 2) { setLL(true); getFollowing(userId).then(getUsersByIds).then(setFL).finally(() => setLL(false)); }
  }, [tab]);

  const handleToggleFollow = async () => {
    if (toggling) return;
    setToggling(true);
    haptic.medium();
    try {
      if (following) await unfollowUser(me.uid, userId);
      else { await followUser(me.uid, myProfile?.displayName, userId); haptic.success(); }
    } catch (e) { console.error(e); }
    finally { setToggling(false); }
  };

  const onRefresh = async () => { setRef(true); await loadProfile(); setRef(false); };

  if (!profile) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  const stats = [
    { label: 'Followers', value: profile.followersCount || 0, tab: 1 },
    { label: 'Following', value: profile.followingCount || 0, tab: 2 },
    { label: 'Groups',    value: profile.joinedGroups?.length || 0, tab: null },
  ];

  return (
    <SafeAreaView style={s.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* Hero */}
        <View style={s.hero}>
          <View style={s.heroMesh} />
          <View style={s.heroMesh2} />

          {/* Share button */}
          <TouchableOpacity style={s.shareBtn} onPress={() => shareProfile(profile)}>
            <Text style={{ fontSize: 18 }}>↗️</Text>
          </TouchableOpacity>

          {profile.photoURL
            ? <Image source={{ uri: profile.photoURL }} style={s.avatar} />
            : <View style={s.avatarFallback}><Text style={s.avatarTxt}>{profile.displayName?.[0]?.toUpperCase()}</Text></View>
          }

          <View style={s.nameRow}>
            <Text style={s.displayName}>{profile.displayName}</Text>
            {profile.verified  && <Text style={{ fontSize: 18 }}>{BRAND.verified}</Text>}
            {profile.isPremium && <Text style={{ fontSize: 18 }}>{BRAND.premium}</Text>}
          </View>

          {profile.username && <Text style={s.handle}>@{profile.username}</Text>}
          {profile.bio && <Text style={s.bio}>{profile.bio}</Text>}

          {/* Stats */}
          <View style={s.statsRow}>
            {stats.map(({ label, value, tab: t }, i) => (
              <React.Fragment key={label}>
                <TouchableOpacity style={s.stat} onPress={() => t !== null && setTab(t)}>
                  <Text style={s.statVal}>{value}</Text>
                  <Text style={[s.statLbl, t !== null && { color: colors.primary }]}>{label}</Text>
                </TouchableOpacity>
                {i < 2 && <View style={s.statDiv} />}
              </React.Fragment>
            ))}
          </View>

          {/* Action buttons */}
          {!isSelf ? (
            <View style={s.actions}>
              <TouchableOpacity
                style={[s.followBtn, following && s.followingBtn]}
                onPress={handleToggleFollow}
                disabled={toggling}
                activeOpacity={0.85}
              >
                {toggling
                  ? <ActivityIndicator size="small" color={following ? colors.textSecondary : '#fff'} />
                  : <Text style={[s.followBtnTxt, following && s.followingBtnTxt]}>
                      {following ? `${PROFILE_ICONS.following} Following` : `+ Follow`}
                    </Text>
                }
              </TouchableOpacity>
              <TouchableOpacity style={s.msgBtn} onPress={() => navigation.navigate('Messages')} activeOpacity={0.85}>
                <Text style={s.msgBtnTxt}>💬 Message</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={s.editBtn} onPress={() => navigation.navigate('Profile')} activeOpacity={0.85}>
              <Text style={s.editBtnTxt}>✏️ Edit Profile</Text>
            </TouchableOpacity>
          )}

          {/* Interests */}
          {profile.interests?.length > 0 && (
            <View style={s.interests}>
              {profile.interests.map((tag) => {
                const c = colors.topics?.[tag] || colors.primary;
                return (
                  <View key={tag} style={[s.interestTag, { backgroundColor: c + '20', borderColor: c + '50' }]}>
                    <Text style={{ fontSize: 12 }}>{TOPIC_ICONS[tag]}</Text>
                    <Text style={[s.interestTxt, { color: c }]}>{tag}</Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* Tabs */}
        <View style={s.tabs}>
          {TABS.map((t, i) => (
            <TouchableOpacity key={t} style={[s.tabBtn, tab === i && s.tabBtnActive]} onPress={() => setTab(i)}>
              <Text style={[s.tabTxt, tab === i && s.tabTxtActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Tab content */}
        <View>
          {tab === 0 && (
            <View style={{ padding: spacing.xl, alignItems: 'center', gap: spacing.md }}>
              <Text style={{ fontSize: 40 }}>📝</Text>
              <Text style={{ color: colors.textMuted, fontSize: typography.fontSize.md }}>No posts yet</Text>
            </View>
          )}
          {(tab === 1 || tab === 2) && (
            listLoading
              ? <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} />
              : <View style={{ padding: spacing.lg, gap: spacing.md }}>
                  {(tab === 1 ? followers : followingList).map((u) => (
                    <UserCard key={u.uid || u.id} user={u} currentUserId={me.uid} currentUserName={myProfile?.displayName}
                      onPress={() => navigation.push('UserProfile', { userId: u.uid || u.id })} />
                  ))}
                  {(tab === 1 ? followers : followingList).length === 0 && (
                    <View style={{ alignItems: 'center', paddingTop: 60, gap: spacing.md }}>
                      <Text style={{ fontSize: 40 }}>{tab === 1 ? '👥' : '🫂'}</Text>
                      <Text style={{ color: colors.textMuted }}>{tab === 1 ? 'No followers yet' : 'Not following anyone yet'}</Text>
                    </View>
                  )}
                </View>
          )}
        </View>
        <View style={{ height: 80 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { backgroundColor: colors.surface, alignItems: 'center', padding: spacing.xl, gap: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, overflow: 'hidden', position: 'relative' },
  heroMesh: { position: 'absolute', width: 280, height: 280, borderRadius: 140, backgroundColor: colors.primary, top: -160, right: -100, opacity: 0.12 },
  heroMesh2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: colors.accent, bottom: -120, left: -60, opacity: 0.1 },
  shareBtn: { position: 'absolute', top: spacing.lg, right: spacing.xl, width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  avatar: { width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: colors.primary },
  avatarFallback: { width: 96, height: 96, borderRadius: 48, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', borderWidth: 3, borderColor: colors.primaryDark },
  avatarTxt: { color: '#fff', fontSize: 38, fontWeight: '700' },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  displayName: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  handle: { fontSize: typography.fontSize.md, color: colors.textMuted },
  bio: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 22, paddingHorizontal: spacing.xl },
  statsRow: { flexDirection: 'row', alignItems: 'center', borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.lg, width: '100%' },
  stat: { flex: 1, alignItems: 'center' },
  statVal: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  statLbl: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 2 },
  statDiv: { width: 1, height: 32, backgroundColor: colors.border },
  actions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  followBtn: { flex: 1, backgroundColor: colors.primary, paddingVertical: spacing.md, borderRadius: borderRadius.lg, alignItems: 'center', ...shadows.glow },
  followingBtn: { backgroundColor: colors.surfaceHigh, borderWidth: 1.5, borderColor: colors.border },
  followBtnTxt: { color: '#fff', fontWeight: typography.fontWeight.black, fontSize: typography.fontSize.md },
  followingBtnTxt: { color: colors.textSecondary },
  msgBtn: { flex: 1, backgroundColor: colors.surfaceAlt, paddingVertical: spacing.md, borderRadius: borderRadius.lg, alignItems: 'center', borderWidth: 1.5, borderColor: colors.border },
  msgBtnTxt: { color: colors.textPrimary, fontWeight: typography.fontWeight.semibold },
  editBtn: { width: '100%', backgroundColor: colors.surfaceAlt, paddingVertical: spacing.md, borderRadius: borderRadius.lg, alignItems: 'center', borderWidth: 1.5, borderColor: colors.border },
  editBtnTxt: { color: colors.textPrimary, fontWeight: typography.fontWeight.semibold },
  interests: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, justifyContent: 'center' },
  interestTag: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: borderRadius.full, borderWidth: 1 },
  interestTxt: { fontSize: typography.fontSize.sm, fontWeight: '600', textTransform: 'capitalize' },
  tabs: { flexDirection: 'row', backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  tabBtn: { flex: 1, paddingVertical: spacing.lg, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabBtnActive: { borderBottomColor: colors.primary },
  tabTxt: { fontSize: typography.fontSize.md, color: colors.textMuted, fontWeight: typography.fontWeight.medium },
  tabTxtActive: { color: colors.primary, fontWeight: typography.fontWeight.black },
});

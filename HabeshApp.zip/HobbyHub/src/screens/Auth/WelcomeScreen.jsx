// src/screens/Auth/WelcomeScreen.jsx — Premium v2
import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  SafeAreaView, StatusBar, Dimensions, Animated,
} from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';

const { width: W, height: H } = Dimensions.get('window');

const INTEREST_PILLS = [
  { label: '📸 Photography', color: '#9B5DE5' },
  { label: '🎮 Gaming',      color: '#00BBF9' },
  { label: '🍳 Cooking',     color: '#F15BB5' },
  { label: '🎵 Music',       color: '#FF4D6D' },
  { label: '✈️ Travel',      color: '#FFB703' },
  { label: '🎨 Art',         color: '#FF6B6B' },
  { label: '📚 Reading',     color: '#845EC2' },
  { label: '💻 Tech',        color: '#48CAE4' },
  { label: '🌿 Nature',      color: '#06D6A0' },
  { label: '🏋️ Fitness',     color: '#4CC9F0' },
];

export default function WelcomeScreen({ navigation }) {
  const fadeIn    = useRef(new Animated.Value(0)).current;
  const slideUp   = useRef(new Animated.Value(50)).current;
  const btnScale  = useRef(new Animated.Value(0.85)).current;
  const orb1Float = useRef(new Animated.Value(0)).current;
  const orb2Float = useRef(new Animated.Value(0)).current;
  const orb3Float = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Entry
    Animated.sequence([
      Animated.delay(150),
      Animated.parallel([
        Animated.timing(fadeIn,  { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.spring(slideUp, { toValue: 0, tension: 55, friction: 11, useNativeDriver: true }),
        Animated.spring(btnScale,{ toValue: 1, tension: 55, friction: 11, delay: 350, useNativeDriver: true }),
      ]),
    ]).start();

    // Orb floats
    const float = (anim, delay) => Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(anim, { toValue: 1, duration: 4500, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 4500, useNativeDriver: true }),
      ])
    ).start();

    float(orb1Float, 0);
    float(orb2Float, 1200);
    float(orb3Float, 2400);
  }, []);

  const makeOrbStyle = (anim, dy = -20) => ({
    opacity: anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.2, 0.5, 0.2] }),
    transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [0, dy] }) }],
  });

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" />

      {/* Mesh orbs */}
      <Animated.View style={[s.orb, s.orb1, makeOrbStyle(orb1Float, -30)]} />
      <Animated.View style={[s.orb, s.orb2, makeOrbStyle(orb2Float, -20)]} />
      <Animated.View style={[s.orb, s.orb3, makeOrbStyle(orb3Float, -15)]} />

      {/* Subtle grid lines */}
      <View style={s.gridOverlay} />

      <SafeAreaView style={s.safe}>
        {/* Logo area */}
        <Animated.View style={[s.hero, { opacity: fadeIn, transform: [{ translateY: slideUp }] }]}>
          <View style={s.badge}>
            <Text style={s.badgeEmoji}>🌐</Text>
          </View>
          <Text style={s.logoMark}>Habesha</Text>
          <View style={s.accentLine} />
          <Text style={s.sub}>ኢትዮጵያዊ · Connect. Share. Belong.</Text>
        </Animated.View>

        {/* Pill rows */}
        <Animated.View style={[s.pillsSection, { opacity: fadeIn }]}>
          <View style={s.pillRow}>
            {INTEREST_PILLS.slice(0, 5).map((p) => (
              <View key={p.label} style={[s.pill, { backgroundColor: p.color + '22', borderColor: p.color + '55' }]}>
                <Text style={[s.pillTxt, { color: p.color }]}>{p.label}</Text>
              </View>
            ))}
          </View>
          <View style={[s.pillRow, { paddingLeft: spacing.xxl }]}>
            {INTEREST_PILLS.slice(5).map((p) => (
              <View key={p.label} style={[s.pill, { backgroundColor: p.color + '22', borderColor: p.color + '55' }]}>
                <Text style={[s.pillTxt, { color: p.color }]}>{p.label}</Text>
              </View>
            ))}
          </View>
        </Animated.View>

        {/* Stats bar */}
        <Animated.View style={[s.stats, { opacity: fadeIn }]}>
          {[['2M+', 'Members'], ['50K+', 'Groups'], ['∞', 'Passions']].map(([n, l], i) => (
            <React.Fragment key={l}>
              <View style={s.stat}>
                <Text style={s.statN}>{n}</Text>
                <Text style={s.statL}>{l}</Text>
              </View>
              {i < 2 && <View style={s.statDiv} />}
            </React.Fragment>
          ))}
        </Animated.View>

        {/* Buttons */}
        <Animated.View style={[s.actions, { opacity: fadeIn, transform: [{ scale: btnScale }] }]}>
          <TouchableOpacity
            style={s.primaryBtn}
            onPress={() => navigation.navigate('Register')}
            activeOpacity={0.88}
          >
            <View style={s.btnSheen} />
            <Text style={s.primaryBtnTxt}>Get Started Free</Text>
            <Text style={s.btnChevron}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={s.ghostBtn}
            onPress={() => navigation.navigate('Login')}
            activeOpacity={0.8}
          >
            <Text style={s.ghostBtnTxt}>Already have an account</Text>
          </TouchableOpacity>

          <Text style={s.legalTxt}>By continuing you agree to our Terms & Privacy Policy</Text>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  safe: { flex: 1, paddingHorizontal: spacing.xl, justifyContent: 'space-between', paddingBottom: spacing.xxl },
  orb: { position: 'absolute', borderRadius: 999 },
  orb1: { width: 350, height: 350, top: -100, left: -100, backgroundColor: colors.primary, opacity: 0.3 },
  orb2: { width: 280, height: 280, top: H * 0.3, right: -120, backgroundColor: colors.accent, opacity: 0.2 },
  orb3: { width: 200, height: 200, bottom: 80, left: 20, backgroundColor: colors.tertiary, opacity: 0.2 },
  gridOverlay: { ...StyleSheet.absoluteFillObject, opacity: 0.02 },

  hero: { alignItems: 'center', paddingTop: spacing.xxxl, gap: spacing.lg },
  badge: {
    width: 88, height: 88, borderRadius: 24, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
    ...shadows.glow,
    borderWidth: 1, borderColor: colors.primaryLight + '40',
  },
  badgeEmoji: { fontSize: 42 },
  logoMark: {
    fontSize: typography.fontSize.hero, fontWeight: typography.fontWeight.black,
    color: colors.textPrimary, fontFamily: typography.fontFamily.display,
    letterSpacing: -2,
  },
  accentLine: { width: 48, height: 3, backgroundColor: colors.primary, borderRadius: 2 },
  sub: { fontSize: typography.fontSize.lg, color: colors.textSecondary, textAlign: 'center' },

  pillsSection: { gap: spacing.sm, overflow: 'hidden' },
  pillRow: { flexDirection: 'row', gap: spacing.sm, flexWrap: 'nowrap' },
  pill: { paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: borderRadius.full, borderWidth: 1 },
  pillTxt: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold },

  stats: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.xl,
    paddingVertical: spacing.lg, borderWidth: 1, borderColor: colors.border,
  },
  stat: { flex: 1, alignItems: 'center' },
  statN: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.primary },
  statL: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 2, textTransform: 'uppercase', letterSpacing: 1 },
  statDiv: { width: 1, height: 32, backgroundColor: colors.border },

  actions: { gap: spacing.md },
  primaryBtn: {
    backgroundColor: colors.primary, paddingVertical: spacing.lg + 2,
    borderRadius: borderRadius.lg, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: spacing.sm, overflow: 'hidden',
    ...shadows.glow,
  },
  btnSheen: {
    position: 'absolute', top: 0, left: '15%', right: '15%', height: 1.5,
    backgroundColor: 'rgba(255,255,255,0.45)',
  },
  primaryBtnTxt: { color: '#fff', fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.black },
  btnChevron: { color: 'rgba(255,255,255,0.75)', fontSize: 20 },
  ghostBtn: {
    paddingVertical: spacing.lg, borderRadius: borderRadius.lg,
    borderWidth: 1.5, borderColor: colors.border, alignItems: 'center',
  },
  ghostBtnTxt: { color: colors.textSecondary, fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.semibold },
  legalTxt: { fontSize: typography.fontSize.xs, color: colors.textMuted, textAlign: 'center' },
});

// src/screens/Auth/LoginScreen.jsx
// Contains: LoginScreen (default), RegisterScreen, ForgotPasswordScreen

import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, KeyboardAvoidingView, Platform, Alert,
  ActivityIndicator, Animated, ScrollView, StatusBar,
} from 'react-native';
import { loginUser, registerUser, resetPassword } from '../../firebase/auth';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { BRAND, STATUS_ICONS } from '../../theme/icons';
import { haptic } from '../../utils/haptics';

// ─── Shared animated background ────────────────────────────────────
const AuthBackground = () => (
  <>
    <View style={bg.orb1} />
    <View style={bg.orb2} />
    <View style={bg.orb3} />
  </>
);

const bg = StyleSheet.create({
  orb1: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: colors.primary, top: -160, right: -90, opacity: 0.13 },
  orb2: { position: 'absolute', width: 220, height: 220, borderRadius: 110, backgroundColor: colors.accent,   bottom: 20, left: -80, opacity: 0.10 },
  orb3: { position: 'absolute', width: 140, height: 140, borderRadius: 70,  backgroundColor: colors.tertiary, top: '45%', left: -40, opacity: 0.07 },
});

// ─── Field component ────────────────────────────────────────────────
const Field = ({ label, icon, value, onChange, placeholder, secure, keyboard, autoCapitalize, rightElement, error }) => {
  const [focused, setFocused] = useState(false);
  return (
    <View style={f.wrap}>
      <Text style={f.label}>{label}</Text>
      <View style={[f.row, focused && f.rowFocused, error && f.rowError]}>
        <Text style={f.icon}>{icon}</Text>
        <TextInput
          style={f.input}
          value={value}
          onChangeText={onChange}
          placeholder={placeholder}
          placeholderTextColor={colors.textMuted}
          keyboardType={keyboard || 'default'}
          autoCapitalize={autoCapitalize || 'none'}
          secureTextEntry={!!secure}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          autoCorrect={false}
        />
        {rightElement}
      </View>
      {error ? <Text style={f.errorTxt}>{STATUS_ICONS.error} {error}</Text> : null}
    </View>
  );
};

const f = StyleSheet.create({
  wrap: { gap: spacing.xs },
  label: { fontSize: typography.fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginLeft: spacing.xs },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceAlt, borderWidth: 1.5, borderColor: colors.border, borderRadius: borderRadius.md, paddingHorizontal: spacing.md },
  rowFocused: { borderColor: colors.primary },
  rowError:   { borderColor: colors.error },
  icon: { fontSize: 18, marginRight: spacing.sm },
  input: { flex: 1, paddingVertical: spacing.md, fontSize: typography.fontSize.md, color: colors.textPrimary },
  errorTxt: { fontSize: typography.fontSize.xs, color: colors.error, marginLeft: spacing.xs },
});

// ─── Password strength meter ────────────────────────────────────────
const PasswordStrength = ({ password }) => {
  const getStrength = (p) => {
    if (!p) return { score: 0, label: '', color: 'transparent' };
    let score = 0;
    if (p.length >= 8)          score++;
    if (/[A-Z]/.test(p))        score++;
    if (/[0-9]/.test(p))        score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    if (score <= 1) return { score: 1, label: 'Weak',   color: colors.error   };
    if (score === 2) return { score: 2, label: 'Fair',   color: colors.warning };
    if (score === 3) return { score: 3, label: 'Good',   color: colors.accent  };
    return               { score: 4, label: 'Strong', color: colors.success };
  };
  const { score, label, color } = getStrength(password);
  if (!password) return null;
  return (
    <View style={ps.wrap}>
      <View style={ps.bars}>
        {[1,2,3,4].map((i) => (
          <View key={i} style={[ps.bar, { backgroundColor: i <= score ? color : colors.border }]} />
        ))}
      </View>
      <Text style={[ps.label, { color }]}>{label}</Text>
    </View>
  );
};

const ps = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.xs },
  bars: { flexDirection: 'row', gap: 4, flex: 1 },
  bar: { flex: 1, height: 4, borderRadius: 2 },
  label: { fontSize: typography.fontSize.xs, fontWeight: '700', width: 44, textAlign: 'right' },
});

// ─── Eye toggle button ──────────────────────────────────────────────
const EyeToggle = ({ show, onToggle }) => (
  <TouchableOpacity onPress={onToggle} style={{ padding: spacing.sm }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
    <Text style={{ fontSize: 18 }}>{show ? '🙈' : '👁️'}</Text>
  </TouchableOpacity>
);

// ═══════════════════════════════════════════════════════════════════
// ── LOGIN SCREEN ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
export default function LoginScreen({ navigation }) {
  const [email, setEmail]     = useState('');
  const [password, setPass]   = useState('');
  const [showPass, setShowP]  = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors]   = useState({});
  const fadeIn  = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(32)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn,  { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 65, friction: 12, useNativeDriver: true }),
    ]).start();
  }, []);

  const validate = () => {
    const e = {};
    if (!email.trim())   e.email    = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Enter a valid email';
    if (!password)       e.password = 'Password is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) { haptic.error(); return; }
    setLoading(true);
    haptic.medium();
    try {
      await loginUser({ email: email.trim().toLowerCase(), password });
      haptic.success();
    } catch (err) {
      haptic.error();
      const msgs = {
        'auth/wrong-password':     'Incorrect password. Try again or reset it.',
        'auth/user-not-found':     'No account found with this email.',
        'auth/invalid-email':      'Please enter a valid email address.',
        'auth/too-many-requests':  'Too many failed attempts. Please wait a few minutes.',
        'auth/user-disabled':      'This account has been disabled. Contact support.',
        'auth/network-request-failed': 'Network error. Check your connection.',
      };
      Alert.alert('Sign in failed', msgs[err.code] || err.message);
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.container}>
      <StatusBar barStyle="light-content" />
      <AuthBackground />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.kav}>
        <ScrollView
          contentContainerStyle={s.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>

            {/* Back button */}
            <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
              <Text style={s.backTxt}>← Back</Text>
            </TouchableOpacity>

            {/* Header */}
            <View style={s.header}>
              <Text style={s.bigEmoji}>{BRAND.logo}</Text>
              <Text style={s.title}>Welcome back</Text>
              <Text style={s.subtitle}>Sign in to continue your journey</Text>
            </View>

            {/* Form */}
            <View style={s.form}>
              <Field
                label="Email address"
                icon="📧"
                value={email}
                onChange={(v) => { setEmail(v); setErrors((e) => ({ ...e, email: '' })); }}
                placeholder="you@example.com"
                keyboard="email-address"
                error={errors.email}
              />

              <Field
                label="Password"
                icon="🔐"
                value={password}
                onChange={(v) => { setPass(v); setErrors((e) => ({ ...e, password: '' })); }}
                placeholder="Your password"
                secure={!showPass}
                error={errors.password}
                rightElement={<EyeToggle show={showPass} onToggle={() => setShowP((v) => !v)} />}
              />

              {/* Forgot password */}
              <TouchableOpacity
                style={s.forgotBtn}
                onPress={() => navigation.navigate('ForgotPassword')}
              >
                <Text style={s.forgotTxt}>Forgot your password? →</Text>
              </TouchableOpacity>

              {/* Sign in button */}
              <TouchableOpacity
                style={[s.primaryBtn, loading && s.primaryBtnOff]}
                onPress={handleLogin}
                disabled={loading}
                activeOpacity={0.88}
              >
                <View style={s.btnSheen} />
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.primaryBtnTxt}>Sign In</Text>
                }
              </TouchableOpacity>
            </View>

            {/* Divider */}
            <View style={s.divider}>
              <View style={s.dividerLine} />
              <Text style={s.dividerTxt}>or continue with</Text>
              <View style={s.dividerLine} />
            </View>

            {/* Social sign in buttons */}
            <View style={s.socialRow}>
              <TouchableOpacity
                style={s.socialBtn}
                onPress={() => Alert.alert('Google Sign-In', 'Add expo-auth-session and configure Google OAuth to enable this.\n\nSee: docs.expo.dev/guides/authentication')}
                activeOpacity={0.8}
              >
                <Text style={s.socialIcon}>🇬</Text>
                <Text style={s.socialTxt}>Google</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={s.socialBtn}
                onPress={() => Alert.alert('Apple Sign-In', 'Add expo-apple-authentication to enable this.\n\nSee: docs.expo.dev/versions/latest/sdk/apple-authentication')}
                activeOpacity={0.8}
              >
                <Text style={s.socialIcon}>🍎</Text>
                <Text style={s.socialTxt}>Apple</Text>
              </TouchableOpacity>
            </View>

            {/* Switch to register */}
            <TouchableOpacity style={s.switchRow} onPress={() => navigation.navigate('Register')}>
              <Text style={s.switchTxt}>Don't have an account? </Text>
              <Text style={s.switchLink}>Create one →</Text>
            </TouchableOpacity>

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ── REGISTER SCREEN ─────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
export function RegisterScreen({ navigation }) {
  const [form, setForm]       = useState({ displayName: '', email: '', password: '', confirmPassword: '' });
  const [showPass, setShowP]  = useState(false);
  const [showConf, setShowC]  = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors]   = useState({});
  const [agreedTerms, setAgreed] = useState(false);
  const fadeIn  = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(32)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn,  { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 65, friction: 12, useNativeDriver: true }),
    ]).start();
  }, []);

  const set = (k, v) => {
    setForm((prev) => ({ ...prev, [k]: v }));
    setErrors((prev) => ({ ...prev, [k]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.displayName.trim())      e.displayName = 'Name is required';
    else if (form.displayName.length < 2) e.displayName = 'Name must be at least 2 characters';
    if (!form.email.trim())            e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.password)                e.password = 'Password is required';
    else if (form.password.length < 6) e.password = 'Password must be at least 6 characters';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match';
    if (!agreedTerms)                  e.terms = 'You must agree to the Terms of Service';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) { haptic.error(); return; }
    setLoading(true);
    haptic.medium();
    try {
      await registerUser({
        displayName: form.displayName.trim(),
        email:       form.email.trim().toLowerCase(),
        password:    form.password,
      });
      haptic.success();
      // Auth state change → OnboardingScreen automatically
    } catch (err) {
      haptic.error();
      const msgs = {
        'auth/email-already-in-use': 'An account already exists with this email.',
        'auth/invalid-email':        'Please enter a valid email address.',
        'auth/weak-password':        'Password is too weak. Use at least 6 characters.',
        'auth/network-request-failed': 'Network error. Check your connection.',
      };
      Alert.alert('Registration failed', msgs[err.code] || err.message);
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.container}>
      <StatusBar barStyle="light-content" />
      <AuthBackground />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.kav}>
        <ScrollView
          contentContainerStyle={s.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>

            <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
              <Text style={s.backTxt}>← Back</Text>
            </TouchableOpacity>

            <View style={s.header}>
              <Text style={s.bigEmoji}>{BRAND.logo}</Text>
              <Text style={s.title}>Create account</Text>
              <Text style={s.subtitle}>Join the Habesha community today</Text>
            </View>

            <View style={s.form}>
              {/* Full name */}
              <Field
                label="Full Name"
                icon="🪪"
                value={form.displayName}
                onChange={(v) => set('displayName', v)}
                placeholder="Your name"
                autoCapitalize="words"
                error={errors.displayName}
              />

              {/* Email */}
              <Field
                label="Email address"
                icon="📧"
                value={form.email}
                onChange={(v) => set('email', v)}
                placeholder="you@example.com"
                keyboard="email-address"
                error={errors.email}
              />

              {/* Password + strength */}
              <Field
                label="Password"
                icon="🔐"
                value={form.password}
                onChange={(v) => set('password', v)}
                placeholder="Min. 6 characters"
                secure={!showPass}
                error={errors.password}
                rightElement={<EyeToggle show={showPass} onToggle={() => setShowP((v) => !v)} />}
              />
              <PasswordStrength password={form.password} />

              {/* Confirm password */}
              <Field
                label="Confirm Password"
                icon="🔒"
                value={form.confirmPassword}
                onChange={(v) => set('confirmPassword', v)}
                placeholder="Repeat your password"
                secure={!showConf}
                error={errors.confirmPassword}
                rightElement={
                  form.confirmPassword && form.password === form.confirmPassword
                    ? <Text style={{ fontSize: 18 }}>✅</Text>
                    : <EyeToggle show={showConf} onToggle={() => setShowC((v) => !v)} />
                }
              />

              {/* Terms checkbox */}
              <TouchableOpacity
                style={[s.termsRow, errors.terms && s.termsRowError]}
                onPress={() => { setAgreed((v) => !v); haptic.light(); setErrors((e) => ({ ...e, terms: '' })); }}
                activeOpacity={0.7}
              >
                <View style={[s.checkbox, agreedTerms && s.checkboxChecked]}>
                  {agreedTerms && <Text style={s.checkboxTick}>✓</Text>}
                </View>
                <Text style={s.termsTxt}>
                  I agree to the{' '}
                  <Text style={s.termsLink} onPress={() => Alert.alert('Terms of Service', 'Available at habesha.app/terms')}>
                    Terms of Service
                  </Text>
                  {' '}and{' '}
                  <Text style={s.termsLink} onPress={() => Alert.alert('Privacy Policy', 'Available at habesha.app/privacy')}>
                    Privacy Policy
                  </Text>
                </Text>
              </TouchableOpacity>
              {errors.terms && <Text style={f.errorTxt}>{STATUS_ICONS.error} {errors.terms}</Text>}

              {/* Create account button */}
              <TouchableOpacity
                style={[s.primaryBtn, (!agreedTerms || loading) && s.primaryBtnOff]}
                onPress={handleRegister}
                disabled={!agreedTerms || loading}
                activeOpacity={0.88}
              >
                <View style={s.btnSheen} />
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.primaryBtnTxt}>Create Account</Text>
                }
              </TouchableOpacity>
            </View>

            {/* Divider */}
            <View style={s.divider}>
              <View style={s.dividerLine} />
              <Text style={s.dividerTxt}>or sign up with</Text>
              <View style={s.dividerLine} />
            </View>

            <View style={s.socialRow}>
              <TouchableOpacity style={s.socialBtn} onPress={() => Alert.alert('Google Sign-Up', 'Configure expo-auth-session to enable Google sign-up.')} activeOpacity={0.8}>
                <Text style={s.socialIcon}>🇬</Text>
                <Text style={s.socialTxt}>Google</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.socialBtn} onPress={() => Alert.alert('Apple Sign-Up', 'Configure expo-apple-authentication to enable Apple sign-up.')} activeOpacity={0.8}>
                <Text style={s.socialIcon}>🍎</Text>
                <Text style={s.socialTxt}>Apple</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={s.switchRow} onPress={() => navigation.navigate('Login')}>
              <Text style={s.switchTxt}>Already have an account? </Text>
              <Text style={s.switchLink}>Sign in →</Text>
            </TouchableOpacity>

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ── FORGOT PASSWORD SCREEN ──────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
export function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail]     = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent]       = useState(false);
  const [error, setError]     = useState('');
  const fadeIn  = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(32)).current;
  const successScale = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn,  { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 65, friction: 12, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleReset = async () => {
    if (!email.trim()) { setError('Email is required'); haptic.error(); return; }
    if (!/\S+@\S+\.\S+/.test(email)) { setError('Enter a valid email address'); haptic.error(); return; }

    setLoading(true);
    setError('');
    haptic.medium();
    try {
      await resetPassword(email.trim().toLowerCase());
      setSent(true);
      haptic.success();
      Animated.spring(successScale, { toValue: 1, tension: 120, friction: 10, useNativeDriver: true }).start();
    } catch (err) {
      haptic.error();
      const msgs = {
        'auth/user-not-found':     'No account found with this email address.',
        'auth/invalid-email':      'Please enter a valid email address.',
        'auth/too-many-requests':  'Too many requests. Please wait a moment.',
        'auth/network-request-failed': 'Network error. Check your connection.',
      };
      setError(msgs[err.code] || err.message);
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.container}>
      <StatusBar barStyle="light-content" />
      <AuthBackground />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.kav}>
        <ScrollView
          contentContainerStyle={s.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>

            <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
              <Text style={s.backTxt}>← Back</Text>
            </TouchableOpacity>

            {!sent ? (
              <>
                {/* Header */}
                <View style={s.header}>
                  <Text style={s.bigEmoji}>🔑</Text>
                  <Text style={s.title}>Reset password</Text>
                  <Text style={s.subtitle}>
                    Enter your email and we'll send you a link to reset your password.
                  </Text>
                </View>

                <View style={s.form}>
                  <Field
                    label="Email address"
                    icon="📧"
                    value={email}
                    onChange={(v) => { setEmail(v); setError(''); }}
                    placeholder="you@example.com"
                    keyboard="email-address"
                    error={error}
                  />

                  <TouchableOpacity
                    style={[s.primaryBtn, loading && s.primaryBtnOff]}
                    onPress={handleReset}
                    disabled={loading}
                    activeOpacity={0.88}
                  >
                    <View style={s.btnSheen} />
                    {loading
                      ? <ActivityIndicator color="#fff" />
                      : <Text style={s.primaryBtnTxt}>Send Reset Link</Text>
                    }
                  </TouchableOpacity>
                </View>

                <TouchableOpacity style={s.switchRow} onPress={() => navigation.navigate('Login')}>
                  <Text style={s.switchTxt}>Remember your password? </Text>
                  <Text style={s.switchLink}>Sign in →</Text>
                </TouchableOpacity>
              </>
            ) : (
              /* Success state */
              <Animated.View style={[s.successCard, { transform: [{ scale: successScale }] }]}>
                <Text style={s.successEmoji}>✅</Text>
                <Text style={s.successTitle}>Email sent!</Text>
                <Text style={s.successBody}>
                  We sent a password reset link to{'\n'}
                  <Text style={{ color: colors.primary, fontWeight: '700' }}>{email}</Text>
                  {'\n\n'}
                  Check your inbox and spam folder. The link expires in 1 hour.
                </Text>

                <TouchableOpacity
                  style={s.primaryBtn}
                  onPress={() => navigation.navigate('Login')}
                  activeOpacity={0.88}
                >
                  <View style={s.btnSheen} />
                  <Text style={s.primaryBtnTxt}>Back to Sign In</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={s.resendBtn}
                  onPress={() => { setSent(false); }}
                >
                  <Text style={s.resendTxt}>Didn't get it? Try again</Text>
                </TouchableOpacity>
              </Animated.View>
            )}

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─── Shared styles ──────────────────────────────────────────────────
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  kav: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: spacing.xl, paddingTop: spacing.xl, paddingBottom: spacing.xxxl, justifyContent: 'center', gap: spacing.xl },

  backBtn: { alignSelf: 'flex-start' },
  backTxt: { color: colors.primary, fontSize: typography.fontSize.md, fontWeight: '600' },

  header: { alignItems: 'center', gap: spacing.sm },
  bigEmoji: { fontSize: 56 },
  title: { fontSize: typography.fontSize.xxxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, letterSpacing: -1, textAlign: 'center' },
  subtitle: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 22 },

  form: { gap: spacing.lg },

  forgotBtn: { alignSelf: 'flex-end' },
  forgotTxt: { color: colors.primary, fontSize: typography.fontSize.sm, fontWeight: '600' },

  primaryBtn: {
    backgroundColor: colors.primary, paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg, alignItems: 'center',
    overflow: 'hidden', ...shadows.glow,
  },
  primaryBtnOff: { opacity: 0.45 },
  btnSheen: { position: 'absolute', top: 0, left: '15%', right: '15%', height: 1.5, backgroundColor: 'rgba(255,255,255,0.4)' },
  primaryBtnTxt: { color: '#fff', fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.black },

  divider: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerTxt: { fontSize: typography.fontSize.xs, color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 1 },

  socialRow: { flexDirection: 'row', gap: spacing.md },
  socialBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, paddingVertical: spacing.md,
    backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.lg,
    borderWidth: 1.5, borderColor: colors.border,
  },
  socialIcon: { fontSize: 20 },
  socialTxt: { color: colors.textSecondary, fontWeight: '600', fontSize: typography.fontSize.md },

  switchRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap' },
  switchTxt: { color: colors.textMuted, fontSize: typography.fontSize.md },
  switchLink: { color: colors.primary, fontWeight: typography.fontWeight.bold, fontSize: typography.fontSize.md },

  termsRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md, padding: spacing.md, backgroundColor: colors.surfaceAlt, borderRadius: borderRadius.md, borderWidth: 1, borderColor: colors.border },
  termsRowError: { borderColor: colors.error + '60' },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: colors.border, backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center', marginTop: 1, flexShrink: 0 },
  checkboxChecked: { backgroundColor: colors.primary, borderColor: colors.primary },
  checkboxTick: { color: '#fff', fontSize: 13, fontWeight: '900' },
  termsTxt: { flex: 1, fontSize: typography.fontSize.sm, color: colors.textSecondary, lineHeight: 20 },
  termsLink: { color: colors.primary, fontWeight: '700' },

  // Success state
  successCard: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.xxl, alignItems: 'center', gap: spacing.lg, borderWidth: 1, borderColor: colors.border },
  successEmoji: { fontSize: 64 },
  successTitle: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  successBody: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 24 },
  resendBtn: { paddingVertical: spacing.sm },
  resendTxt: { color: colors.primary, fontSize: typography.fontSize.sm, fontWeight: '600' },
});

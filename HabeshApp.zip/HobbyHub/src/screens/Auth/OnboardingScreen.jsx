// src/screens/Auth/OnboardingScreen.jsx — Premium dark v2
import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  TouchableOpacity, ActivityIndicator, Alert, Dimensions, Animated,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { updateUserProfile } from '../../firebase/firestore';
import { claimUsername } from '../../firebase/usernames';
import UsernamePicker from '../../components/UsernamePicker';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { TOPIC_ICONS, BRAND, STATUS_ICONS } from '../../theme/icons';
import { haptic } from '../../utils/haptics';

const { width: W } = Dimensions.get('window');

const INTERESTS = [
  { id: 'photography', label: 'Photography', color: '#9B5DE5' },
  { id: 'cooking',     label: 'Cooking',     color: '#F15BB5' },
  { id: 'gaming',      label: 'Gaming',      color: '#00BBF9' },
  { id: 'fitness',     label: 'Fitness',     color: '#06D6A0' },
  { id: 'music',       label: 'Music',       color: '#FF4D6D' },
  { id: 'travel',      label: 'Travel',      color: '#FFB703' },
  { id: 'art',         label: 'Art & Design',color: '#FF6B6B' },
  { id: 'reading',     label: 'Reading',     color: '#845EC2' },
  { id: 'tech',        label: 'Tech',        color: '#48CAE4' },
  { id: 'nature',      label: 'Nature',      color: '#06D6A0' },
  { id: 'film',        label: 'Film & TV',   color: '#F72585' },
  { id: 'sports',      label: 'Sports',      color: '#4CC9F0' },
  { id: 'fashion',     label: 'Fashion',     color: '#A855F7' },
  { id: 'pets',        label: 'Pets',        color: '#14B8A6' },
  { id: 'diy',         label: 'DIY & Crafts',color: '#84CC16' },
  { id: 'food',        label: 'Food & Drink',color: '#FB923C' },
];

const MIN = 3;

export default function OnboardingScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [step, setStep]         = useState(0);
  const [username, setUsername] = useState('');
  const [uValid, setUValid]     = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [saving, setSaving]     = useState(false);
  const slideAnim               = useRef(new Animated.Value(0)).current;

  const goStep = (n) => {
    haptic.medium();
    Animated.spring(slideAnim, { toValue: n, tension: 80, friction: 14, useNativeDriver: true }).start();
    setStep(n);
  };

  const toggleInterest = (id) => {
    haptic.light();
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleFinish = async () => {
    if (selected.size < MIN) return;
    setSaving(true);
    try {
      await claimUsername(user.uid, username);
      await updateUserProfile(user.uid, { interests: Array.from(selected), onboardingComplete: true });
      haptic.success();
      await refreshProfile();
    } catch (e) {
      haptic.error();
      Alert.alert('Error', e.message || 'Something went wrong.');
    } finally { setSaving(false); }
  };

  const CARD = (W - spacing.xl * 2 - spacing.md * 2) / 3;

  // ── Step 0: Welcome ──────────────────────────────────────────
  if (step === 0) {
    return (
      <SafeAreaView style={s.container}>
        <View style={s.orb1} /><View style={s.orb2} />
        <View style={s.welcomeContent}>
          <Text style={s.bigEmoji}>{BRAND.logo}</Text>
          <Text style={s.welcomeTitle}>Welcome to{'\n'}Habesha! 🎉</Text>
          <Text style={s.welcomeSub}>Set up your profile in 2 quick steps to get a personalized experience.</Text>
          <View style={s.featureList}>
            {[['🏷️', 'Claim your unique @username'], ['🎯', 'Curated feed for your interests'], ['🧑‍🤝‍🧑', 'Find people who share your hobbies']].map(([icon, txt]) => (
              <View key={txt} style={s.featureRow}>
                <Text style={s.featureIcon}>{icon}</Text>
                <Text style={s.featureTxt}>{txt}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity style={s.primaryBtn} onPress={() => goStep(1)}>
            <View style={s.btnSheen} />
            <Text style={s.primaryBtnTxt}>Let's Go →</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ── Step 1: Username ─────────────────────────────────────────
  if (step === 1) {
    return (
      <SafeAreaView style={s.container}>
        <View style={s.orb1} />
        <View style={s.stepHeader}>
          <Text style={s.stepLabel}>Step 1 of 2</Text>
          <View style={s.progress}><View style={[s.progressFill, { width: '50%' }]} /></View>
          <Text style={s.stepTitle}>Claim your @username</Text>
          <Text style={s.stepSub}>How people find and mention you</Text>
        </View>
        <ScrollView contentContainerStyle={{ padding: spacing.xl, gap: spacing.xl }}>
          <UsernamePicker value={username} onChange={(v, ok) => { setUsername(v); setUValid(ok); }} />
          {username.length >= 3 && (
            <View style={s.previewCard}>
              <View style={s.previewAvatar}><Text style={s.previewAvatarTxt}>{profile?.displayName?.[0]?.toUpperCase()}</Text></View>
              <View>
                <Text style={s.previewName}>{profile?.displayName}</Text>
                <Text style={s.previewHandle}>@{username}</Text>
              </View>
            </View>
          )}
        </ScrollView>
        <View style={s.footer}>
          <TouchableOpacity style={[s.primaryBtn, !uValid && s.btnOff]} onPress={() => goStep(2)} disabled={!uValid}>
            <View style={s.btnSheen} />
            <Text style={s.primaryBtnTxt}>Continue →</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ── Step 2: Interests ────────────────────────────────────────
  const pct = Math.min(50 + (selected.size / MIN) * 50, 100);
  return (
    <SafeAreaView style={s.container}>
      <View style={s.stepHeader}>
        <Text style={s.stepLabel}>Step 2 of 2</Text>
        <View style={s.progress}><View style={[s.progressFill, { width: `${pct}%` }]} /></View>
        <Text style={s.stepTitle}>What are you into?</Text>
        <Text style={s.stepSub}>Pick at least {MIN} · {selected.size} selected</Text>
      </View>
      <ScrollView contentContainerStyle={s.grid} showsVerticalScrollIndicator={false}>
        {INTERESTS.map((item) => {
          const on = selected.has(item.id);
          return (
            <TouchableOpacity
              key={item.id}
              style={[s.chip, on && { borderColor: item.color, borderWidth: 2.5, backgroundColor: item.color + '18' }]}
              onPress={() => toggleInterest(item.id)}
              activeOpacity={0.75}
            >
              {on && <View style={[s.chipCheck, { backgroundColor: item.color }]}><Text style={s.chipCheckTxt}>✓</Text></View>}
              <View style={[s.chipEmoji, { backgroundColor: item.color + '22' }]}>
                <Text style={{ fontSize: 26 }}>{TOPIC_ICONS[item.id]}</Text>
              </View>
              <Text style={[s.chipLabel, on && { color: item.color, fontWeight: '700' }]}>{item.label}</Text>
            </TouchableOpacity>
          );
        })}
        <View style={{ height: 120 }} />
      </ScrollView>
      <View style={s.footer}>
        <Text style={s.footerHint}>
          {selected.size < MIN ? `Select ${MIN - selected.size} more to continue` : `${STATUS_ICONS.success} Great picks!`}
        </Text>
        <TouchableOpacity
          style={[s.primaryBtn, selected.size < MIN && s.btnOff]}
          onPress={handleFinish}
          disabled={saving || selected.size < MIN}
        >
          <View style={s.btnSheen} />
          {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.primaryBtnTxt}>Finish & Explore →</Text>}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const CARD_W = (W - spacing.xl * 2 - spacing.md * 2) / 3;
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  orb1: { position: 'absolute', width: 280, height: 280, borderRadius: 140, backgroundColor: colors.primary, top: -140, left: -80, opacity: 0.15 },
  orb2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: colors.accent, bottom: 60, right: -60, opacity: 0.12 },
  welcomeContent: { flex: 1, paddingHorizontal: spacing.xl, justifyContent: 'center', alignItems: 'center', gap: spacing.xl },
  bigEmoji: { fontSize: 72 },
  welcomeTitle: { fontSize: typography.fontSize.xxxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, textAlign: 'center', letterSpacing: -1 },
  welcomeSub: { fontSize: typography.fontSize.md, color: colors.textSecondary, textAlign: 'center', lineHeight: 24 },
  featureList: { width: '100%', gap: spacing.md },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  featureIcon: { fontSize: 24, width: 36, textAlign: 'center' },
  featureTxt: { fontSize: typography.fontSize.md, color: colors.textPrimary, flex: 1 },
  stepHeader: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  stepLabel: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginBottom: spacing.xs },
  progress: { height: 4, backgroundColor: colors.border, borderRadius: 2, marginBottom: spacing.md },
  progressFill: { height: 4, backgroundColor: colors.primary, borderRadius: 2 },
  stepTitle: { fontSize: typography.fontSize.xxl, fontWeight: typography.fontWeight.black, color: colors.textPrimary, letterSpacing: -0.5 },
  stepSub: { fontSize: typography.fontSize.sm, color: colors.textSecondary, marginTop: spacing.xs },
  previewCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  previewAvatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
  previewAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  previewName: { fontWeight: typography.fontWeight.bold, color: colors.textPrimary },
  previewHandle: { fontSize: typography.fontSize.sm, color: colors.textMuted, marginTop: 2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.xl, paddingTop: spacing.lg, gap: spacing.md },
  chip: { width: CARD_W, aspectRatio: 1, backgroundColor: colors.surface, borderRadius: borderRadius.xl, justifyContent: 'center', alignItems: 'center', gap: spacing.sm, borderWidth: 2, borderColor: colors.border, position: 'relative', ...shadows.sm },
  chipCheck: { position: 'absolute', top: 7, right: 7, width: 20, height: 20, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  chipCheckTxt: { color: '#fff', fontSize: 11, fontWeight: '800' },
  chipEmoji: { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  chipLabel: { fontSize: typography.fontSize.xs, fontWeight: typography.fontWeight.medium, color: colors.textSecondary, textAlign: 'center' },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border, paddingHorizontal: spacing.xl, paddingTop: spacing.md, paddingBottom: spacing.xxxl, gap: spacing.sm },
  footerHint: { fontSize: typography.fontSize.sm, color: colors.textSecondary, textAlign: 'center' },
  primaryBtn: { backgroundColor: colors.primary, paddingVertical: spacing.lg, borderRadius: borderRadius.lg, alignItems: 'center', overflow: 'hidden', ...shadows.glow },
  btnOff: { opacity: 0.4 },
  btnSheen: { position: 'absolute', top: 0, left: '15%', right: '15%', height: 1.5, backgroundColor: 'rgba(255,255,255,0.4)' },
  primaryBtnTxt: { color: '#fff', fontSize: typography.fontSize.lg, fontWeight: typography.fontWeight.black },
});

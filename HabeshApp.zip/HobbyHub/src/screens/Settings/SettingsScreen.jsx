// src/screens/Settings/SettingsScreen.jsx — Premium dark theme v2
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView,
  TouchableOpacity, Switch, Alert, ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { logoutUser } from '../../firebase/auth';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { SETTINGS_ICONS, BRAND } from '../../theme/icons';

const Section = ({ title, children }) => (
  <View style={s.section}>
    {title && <Text style={s.sectionTitle}>{title}</Text>}
    <View style={s.card}>{children}</View>
  </View>
);

const Row = ({ icon, label, value, onPress, danger, toggle, toggleValue, onToggle, last, subtitle }) => (
  <TouchableOpacity
    style={[s.row, last && s.rowLast]}
    onPress={onPress}
    activeOpacity={toggle ? 1 : 0.7}
  >
    <View style={[s.rowIconWrap, danger && s.rowIconDanger]}>
      <Text style={s.rowIcon}>{icon}</Text>
    </View>
    <View style={s.rowContent}>
      <Text style={[s.rowLabel, danger && s.danger]}>{label}</Text>
      {subtitle && <Text style={s.rowSub}>{subtitle}</Text>}
    </View>
    {value && <Text style={s.rowValue}>{value}</Text>}
    {toggle
      ? <Switch value={toggleValue} onValueChange={onToggle} trackColor={{ true: colors.primary }} thumbColor={colors.textPrimary} />
      : <Text style={s.chevron}>›</Text>
    }
  </TouchableOpacity>
);

export default function SettingsScreen({ navigation }) {
  const { user, profile } = useAuth();
  const [loggingOut, setLO] = useState(false);

  const handleLogout = () => {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: async () => { setLO(true); await logoutUser(); } },
    ]);
  };

  return (
    <SafeAreaView style={s.container}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={s.backBtn}>← Back</Text>
        </TouchableOpacity>
        <Text style={s.title}>Settings</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 60 }}>
        {/* Account */}
        <Section title="Account">
          <Row icon={SETTINGS_ICONS.account}  label="Edit Profile"      onPress={() => navigation.navigate('Profile')} />
          <Row icon={SETTINGS_ICONS.username} label="Change Username"   subtitle={profile?.username ? `@${profile.username}` : 'Not set'} onPress={() => navigation.navigate('ChangeUsername')} />
          <Row icon={SETTINGS_ICONS.password} label="Change Password"   onPress={() => navigation.navigate('ChangePassword')} />
          <Row icon={SETTINGS_ICONS.email}    label="Email"             value={user?.email} toggle={false} last />
        </Section>

        {/* Privacy */}
        <Section title="Privacy & Safety">
          <Row icon={SETTINGS_ICONS.privacy}        label="Privacy Settings"   onPress={() => navigation.navigate('PrivacySettings')} />
          <Row icon={SETTINGS_ICONS.blocked}        label="Blocked Users"      onPress={() => navigation.navigate('BlockedUsers')} />
          <Row icon={SETTINGS_ICONS.muted}          label="Muted Words"        subtitle="Filter content from your feed" onPress={() => {}} last />
        </Section>

        {/* Notifications */}
        <Section title="Notifications">
          <Row icon={SETTINGS_ICONS.notifications} label="Notification Preferences" onPress={() => navigation.navigate('NotificationSettings')} last />
        </Section>

        {/* Appearance */}
        <Section title="Appearance">
          <Row icon={SETTINGS_ICONS.theme}    label="Theme"     value="Dark"   onPress={() => {}} />
          <Row icon={SETTINGS_ICONS.textSize} label="Text Size"               onPress={() => {}} last />
        </Section>

        {/* Premium */}
        <Section title="Subscription">
          <Row
            icon={SETTINGS_ICONS.subscription}
            label="Habesha Premium"
            subtitle={profile?.isPremium ? '✨ Active subscription' : 'Unlock all premium features'}
            onPress={() => navigation.navigate('Paywall')}
            last
          />
        </Section>

        {/* Support */}
        <Section title="Support & Legal">
          <Row icon={SETTINGS_ICONS.help}           label="Help Center"      onPress={() => {}} />
          <Row icon={SETTINGS_ICONS.bug}            label="Report a Bug"     onPress={() => {}} />
          <Row icon={SETTINGS_ICONS.privacy_policy} label="Privacy Policy"   onPress={() => {}} />
          <Row icon={SETTINGS_ICONS.terms}          label="Terms of Service" onPress={() => {}} />
          <Row icon={SETTINGS_ICONS.version}        label="App Version"      value="1.0.0" toggle={false} last />
        </Section>

        {/* Danger zone */}
        <Section title="Account Actions">
          <Row
            icon={SETTINGS_ICONS.signout}
            label={loggingOut ? 'Signing out…' : 'Sign Out'}
            onPress={handleLogout}
            danger
            toggle={false}
          />
          <Row
            icon={SETTINGS_ICONS.danger}
            label="Delete Account"
            subtitle="Permanently removes all your data"
            onPress={() => navigation.navigate('DeleteAccount')}
            danger
            last
          />
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  backBtn: { color: colors.primary, fontSize: typography.fontSize.md, fontWeight: '600', width: 60 },
  title: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  section: { paddingHorizontal: spacing.xl, paddingTop: spacing.xl },
  sectionTitle: { fontSize: 11, fontWeight: typography.fontWeight.black, color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: spacing.sm },
  card: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.md },
  rowLast: { borderBottomWidth: 0 },
  rowIconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center' },
  rowIconDanger: { backgroundColor: colors.error + '20' },
  rowIcon: { fontSize: 18 },
  rowContent: { flex: 1 },
  rowLabel: { fontSize: typography.fontSize.md, color: colors.textPrimary, fontWeight: typography.fontWeight.medium },
  rowSub: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 2 },
  rowValue: { fontSize: typography.fontSize.sm, color: colors.textMuted, marginRight: spacing.sm },
  chevron: { color: colors.textMuted, fontSize: 22 },
  danger: { color: colors.error },
});

// src/screens/Settings/AccountSettings.jsx — Premium dark theme v2
import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, ScrollView, Switch, Alert, ActivityIndicator,
} from 'react-native';
import {
  updatePassword, reauthenticateWithCredential,
  EmailAuthProvider, deleteUser,
} from 'firebase/auth';
import { auth } from '../../firebase/config';
import { changeUsername } from '../../firebase/usernames';
import { updateUserProfile } from '../../firebase/firestore';
import { logoutUser } from '../../firebase/auth';
import { getBlockedUsers, unblockUser } from '../../firebase/moderation';
import { useAuth } from '../../context/AuthContext';
import UsernamePicker from '../../components/UsernamePicker';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { SETTINGS_ICONS, STATUS_ICONS } from '../../theme/icons';

// ── Shared styles ──────────────────────────────────────────────
const sh = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.xl, paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border },
  title: { fontSize: typography.fontSize.xl, fontWeight: typography.fontWeight.black, color: colors.textPrimary },
  body: { padding: spacing.xl, gap: spacing.lg },
  label: { fontSize: typography.fontSize.sm, fontWeight: typography.fontWeight.semibold, color: colors.textSecondary, marginBottom: spacing.xs, marginLeft: spacing.xs },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surfaceAlt, borderWidth: 1.5, borderColor: colors.border, borderRadius: borderRadius.md, paddingHorizontal: spacing.md },
  inputIcon: { fontSize: 18, marginRight: spacing.sm },
  input: { flex: 1, paddingVertical: spacing.md, fontSize: typography.fontSize.md, color: colors.textPrimary },
  eyeBtn: { padding: spacing.sm },
  btn: { backgroundColor: colors.primary, paddingVertical: spacing.lg, borderRadius: borderRadius.lg, alignItems: 'center', ...shadows.glow },
  btnDisabled: { opacity: 0.4 },
  btnTxt: { color: '#fff', fontWeight: typography.fontWeight.black, fontSize: typography.fontSize.lg },
  dangerBtn: { backgroundColor: colors.error, paddingVertical: spacing.lg, borderRadius: borderRadius.lg, alignItems: 'center' },
  card: { backgroundColor: colors.surface, borderRadius: borderRadius.xl, padding: spacing.lg, borderWidth: 1, borderColor: colors.border },
  hint: { fontSize: typography.fontSize.sm, color: colors.textMuted, lineHeight: 20 },
});

// ── Change Password ────────────────────────────────────────────
export function ChangePasswordScreen({ navigation }) {
  const [current, setCurrent] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCurr, setShowCurr] = useState(false);
  const [showNew, setShowNew]   = useState(false);
  const [loading, setLoading]   = useState(false);

  const valid = current && newPass.length >= 6 && newPass === confirm;

  const handle = async () => {
    setLoading(true);
    try {
      const cred = EmailAuthProvider.credential(auth.currentUser.email, current);
      await reauthenticateWithCredential(auth.currentUser, cred);
      await updatePassword(auth.currentUser, newPass);
      Alert.alert(`${STATUS_ICONS.success} Password changed`, 'Your password has been updated.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (e) {
      Alert.alert('Error', e.code === 'auth/wrong-password' ? 'Current password is incorrect.' : e.message);
    } finally { setLoading(false); }
  };

  const fields = [
    { label: 'Current Password', val: current, set: setCurrent, show: showCurr, toggle: () => setShowCurr(v => !v) },
    { label: 'New Password',     val: newPass, set: setNewPass, show: showNew,  toggle: () => setShowNew(v => !v)  },
    { label: 'Confirm Password', val: confirm, set: setConfirm, show: showNew,  toggle: () => setShowNew(v => !v)  },
  ];

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={sh.title}>Change Password</Text></View>
      <ScrollView contentContainerStyle={sh.body}>
        {fields.map(({ label, val, set, show, toggle }) => (
          <View key={label}>
            <Text style={sh.label}>{label}</Text>
            <View style={sh.inputWrap}>
              <Text style={sh.inputIcon}>{SETTINGS_ICONS.password}</Text>
              <TextInput style={sh.input} value={val} onChangeText={set} secureTextEntry={!show} placeholderTextColor={colors.textMuted} placeholder="••••••••" />
              <TouchableOpacity onPress={toggle} style={sh.eyeBtn}><Text style={{ fontSize: 18 }}>{show ? '🙈' : '👁️'}</Text></TouchableOpacity>
            </View>
          </View>
        ))}
        {newPass && confirm && newPass !== confirm && (
          <Text style={{ color: colors.error, fontSize: typography.fontSize.sm }}>{STATUS_ICONS.error} Passwords don't match</Text>
        )}
        <TouchableOpacity style={[sh.btn, !valid && sh.btnDisabled]} onPress={handle} disabled={!valid || loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={sh.btnTxt}>Update Password</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Change Username ────────────────────────────────────────────
export function ChangeUsernameScreen({ navigation }) {
  const { user, profile, refreshProfile } = useAuth();
  const [username, setUsername]   = useState(profile?.username || '');
  const [valid, setValid]         = useState(false);
  const [loading, setLoading]     = useState(false);
  const unchanged = username === profile?.username;

  const handle = async () => {
    if (!valid || unchanged) return;
    setLoading(true);
    try {
      await changeUsername(user.uid, profile?.username, username);
      await refreshProfile();
      Alert.alert(`${STATUS_ICONS.success} Username updated`, `You're now @${username}`, [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (e) { Alert.alert('Error', e.message); }
    finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={sh.title}>Change Username</Text></View>
      <ScrollView contentContainerStyle={sh.body}>
        <View style={sh.card}>
          <Text style={[sh.hint, { marginBottom: spacing.md }]}>
            Current: <Text style={{ color: colors.primary, fontWeight: '700' }}>@{profile?.username || 'not set'}</Text>
          </Text>
          <UsernamePicker value={username} onChange={(v, ok) => { setUsername(v); setValid(ok); }} />
        </View>
        <Text style={sh.hint}>{STATUS_ICONS.info} Your old username becomes available for others immediately.</Text>
        <TouchableOpacity
          style={[sh.btn, (!valid || unchanged) && sh.btnDisabled]}
          onPress={handle} disabled={!valid || unchanged || loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={sh.btnTxt}>Save Username</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Privacy Settings ───────────────────────────────────────────
export function PrivacySettingsScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [settings, setSettings] = useState({
    privateAccount:   profile?.privateAccount    || false,
    showActivity:     profile?.showActivity      !== false,
    allowTagging:     profile?.allowTagging      !== false,
    showOnlineStatus: profile?.showOnlineStatus  !== false,
  });

  const toggle = async (key) => {
    const next = { ...settings, [key]: !settings[key] };
    setSettings(next);
    await updateUserProfile(user.uid, next);
    await refreshProfile();
  };

  const rows = [
    { key: 'privateAccount',   icon: SETTINGS_ICONS.privacy,       label: 'Private Account',  sub: 'Only approved followers see your posts' },
    { key: 'showActivity',     icon: '⚡',                           label: 'Activity Status',  sub: 'Show when you were last active' },
    { key: 'allowTagging',     icon: SETTINGS_ICONS.username,       label: 'Allow Tagging',    sub: 'Let others tag you in posts' },
    { key: 'showOnlineStatus', icon: '🟢',                           label: 'Online Status',    sub: "Show when you're online in messages" },
  ];

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={sh.title}>Privacy Settings</Text></View>
      <ScrollView contentContainerStyle={{ padding: spacing.xl }}>
        <View style={{ backgroundColor: colors.surface, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
          {rows.map((r, i) => (
            <View key={r.key} style={[row.wrap, i < rows.length - 1 && row.border]}>
              <View style={row.iconWrap}><Text style={row.icon}>{r.icon}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={row.label}>{r.label}</Text>
                <Text style={row.sub}>{r.sub}</Text>
              </View>
              <Switch value={settings[r.key]} onValueChange={() => toggle(r.key)} trackColor={{ true: colors.primary }} thumbColor={colors.textPrimary} />
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Notification Settings ──────────────────────────────────────
export function NotificationSettingsScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [prefs, setPrefs] = useState({
    likes: true, comments: true, follows: true,
    messages: true, groupPosts: true, stories: false,
    ...profile?.notifPrefs,
  });

  const toggle = async (key) => {
    const next = { ...prefs, [key]: !prefs[key] };
    setPrefs(next);
    await updateUserProfile(user.uid, { notifPrefs: next });
    await refreshProfile();
  };

  const rows = [
    { key: 'likes',      icon: '❤️',  label: 'Likes',        sub: 'When someone reacts to your post' },
    { key: 'comments',   icon: '💬',  label: 'Comments',     sub: 'When someone comments on your post' },
    { key: 'follows',    icon: '🫂',  label: 'New Followers', sub: 'When someone follows you' },
    { key: 'messages',   icon: '✉️',  label: 'Messages',     sub: 'Direct messages' },
    { key: 'groupPosts', icon: '🏘️',  label: 'Group Posts',  sub: 'New posts in your groups' },
    { key: 'stories',    icon: '📖',  label: 'Stories',      sub: 'When people you follow post stories' },
  ];

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={sh.title}>Notifications</Text></View>
      <ScrollView contentContainerStyle={{ padding: spacing.xl }}>
        <View style={{ backgroundColor: colors.surface, borderRadius: borderRadius.xl, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
          {rows.map((r, i) => (
            <View key={r.key} style={[row.wrap, i < rows.length - 1 && row.border]}>
              <View style={row.iconWrap}><Text style={row.icon}>{r.icon}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={row.label}>{r.label}</Text>
                <Text style={row.sub}>{r.sub}</Text>
              </View>
              <Switch value={prefs[r.key]} onValueChange={() => toggle(r.key)} trackColor={{ true: colors.primary }} thumbColor={colors.textPrimary} />
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Blocked Users ──────────────────────────────────────────────
export function BlockedUsersScreen() {
  const { user }            = useAuth();
  const [blocked, setB]     = useState([]);
  const [loading, setL]     = useState(true);

  useEffect(() => {
    getBlockedUsers(user.uid).then((ids) => { setB(ids); setL(false); });
  }, []);

  const handleUnblock = (id) => {
    Alert.alert('Unblock?', 'They can see your profile and contact you again.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Unblock', onPress: async () => { await unblockUser(user.uid, id); setB((p) => p.filter((b) => b !== id)); } },
    ]);
  };

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={sh.title}>Blocked Users</Text></View>
      {loading
        ? <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} />
        : blocked.length === 0
          ? (
            <View style={{ alignItems: 'center', paddingTop: 80, gap: spacing.md }}>
              <Text style={{ fontSize: 48 }}>{SETTINGS_ICONS.blocked}</Text>
              <Text style={{ fontSize: typography.fontSize.lg, fontWeight: '700', color: colors.textPrimary }}>No blocked users</Text>
            </View>
          ) : (
            <ScrollView contentContainerStyle={sh.body}>
              {blocked.map((id) => (
                <View key={id} style={[sh.card, { flexDirection: 'row', alignItems: 'center', gap: spacing.md }]}>
                  <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.surfaceHigh, justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ fontSize: 20 }}>{SETTINGS_ICONS.blocked}</Text>
                  </View>
                  <Text style={{ flex: 1, color: colors.textMuted, fontSize: typography.fontSize.sm }}>{id.slice(0, 16)}…</Text>
                  <TouchableOpacity onPress={() => handleUnblock(id)} style={{ backgroundColor: colors.surfaceAlt, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: borderRadius.full, borderWidth: 1, borderColor: colors.border }}>
                    <Text style={{ color: colors.textPrimary, fontSize: typography.fontSize.sm, fontWeight: '600' }}>Unblock</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )
      }
    </SafeAreaView>
  );
}

// ── Delete Account ─────────────────────────────────────────────
export function DeleteAccountScreen({ navigation }) {
  const { user }                  = useAuth();
  const [password, setPassword]   = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [loading, setLoading]     = useState(false);

  const handle = async () => {
    if (!confirmed || !password) return;
    Alert.alert('⚡ Final Warning', 'This permanently deletes your account. Cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete Forever', style: 'destructive', onPress: async () => {
          setLoading(true);
          try {
            const cred = EmailAuthProvider.credential(user.email, password);
            await reauthenticateWithCredential(auth.currentUser, cred);
            await deleteUser(auth.currentUser);
          } catch (e) {
            Alert.alert('Error', e.code === 'auth/wrong-password' ? 'Incorrect password.' : e.message);
            setLoading(false);
          }
        }
      },
    ]);
  };

  return (
    <SafeAreaView style={sh.container}>
      <View style={sh.header}><Text style={[sh.title, { color: colors.error }]}>Delete Account</Text></View>
      <ScrollView contentContainerStyle={sh.body}>
        <View style={[sh.card, { borderColor: colors.error + '40', borderWidth: 1.5 }]}>
          <Text style={{ fontSize: typography.fontSize.lg, fontWeight: '800', color: colors.error, marginBottom: spacing.sm }}>{STATUS_ICONS.warning} This is permanent</Text>
          <Text style={sh.hint}>{'Deleting your account will:\n\n• Remove your profile forever\n• Delete all your posts and stories\n• Remove all your messages\n• Cancel any active subscription\n\nThis action cannot be undone.'}</Text>
        </View>
        <View>
          <Text style={sh.label}>Enter your password to confirm</Text>
          <View style={sh.inputWrap}>
            <Text style={sh.inputIcon}>{SETTINGS_ICONS.password}</Text>
            <TextInput style={sh.input} value={password} onChangeText={setPassword} secureTextEntry placeholder="Your password" placeholderTextColor={colors.textMuted} />
          </View>
        </View>
        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }} onPress={() => setConfirmed((v) => !v)}>
          <View style={{ width: 22, height: 22, borderRadius: 5, borderWidth: 2, borderColor: confirmed ? colors.error : colors.border, backgroundColor: confirmed ? colors.error : 'transparent', justifyContent: 'center', alignItems: 'center' }}>
            {confirmed && <Text style={{ color: '#fff', fontSize: 13, fontWeight: '800' }}>✓</Text>}
          </View>
          <Text style={[sh.hint, { flex: 1 }]}>I understand this is permanent and cannot be undone</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[sh.dangerBtn, (!confirmed || !password) && sh.btnDisabled]} onPress={handle} disabled={!confirmed || !password || loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={sh.btnTxt}>Delete My Account Forever</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const row = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md, gap: spacing.md },
  border: { borderBottomWidth: 1, borderBottomColor: colors.border },
  iconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.surfaceAlt, justifyContent: 'center', alignItems: 'center' },
  icon: { fontSize: 18 },
  label: { fontSize: typography.fontSize.md, fontWeight: typography.fontWeight.medium, color: colors.textPrimary },
  sub: { fontSize: typography.fontSize.xs, color: colors.textMuted, marginTop: 2 },
});

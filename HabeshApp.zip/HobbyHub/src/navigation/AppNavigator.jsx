// src/navigation/AppNavigator.jsx — v3 complete
import React, { useEffect } from 'react';
import { NavigationContainer, useNavigationContainerRef } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useAuth } from '../context/AuthContext';
import { ActivityIndicator, View } from 'react-native';
import { registerForPushNotifications, useNotificationNavigation } from '../firebase/messaging';
import { useDeepLinks, trackSession, maybeRequestReview } from '../utils/appUtils';
import { colors } from '../theme';

// Auth
import WelcomeScreen        from '../screens/Auth/WelcomeScreen';
import LoginScreen, { RegisterScreen, ForgotPasswordScreen } from '../screens/Auth/LoginScreen';
import OnboardingScreen     from '../screens/Auth/OnboardingScreen';

// Main
import TabNavigator         from './TabNavigator';
import { ChatScreen }       from '../screens/Main/MessagesScreen';
import UserProfileScreen    from '../screens/Main/UserProfileScreen';
import { BookmarksScreen }  from '../firebase/bookmarks';
import CreateStoryScreen    from '../screens/Main/CreateStoryScreen';
import PostAnalyticsScreen  from '../screens/Main/PostAnalyticsScreen';

// Groups
import GroupDetailScreen    from '../screens/Groups/GroupDetailScreen';
import CreateGroupScreen    from '../screens/Groups/CreateGroupScreen';
import GroupAdminScreen     from '../screens/Groups/GroupAdminScreen';

// Hashtags
import { HashtagScreen }    from '../firebase/hashtags';

// Settings
import SettingsScreen       from '../screens/Settings/SettingsScreen';
import {
  ChangePasswordScreen, ChangeUsernameScreen,
  PrivacySettingsScreen, NotificationSettingsScreen,
  DeleteAccountScreen, BlockedUsersScreen,
} from '../screens/Settings/AccountSettings';

const Stack = createStackNavigator();

const headerTheme = {
  headerStyle: { backgroundColor: colors.surface },
  headerTintColor: colors.textPrimary,
  headerTitleStyle: { fontWeight: '700', color: colors.textPrimary },
  headerShadowVisible: false,
  headerBackTitleVisible: false,
};

export default function AppNavigator() {
  const { user, profile, loading } = useAuth();
  const navigationRef = useNavigationContainerRef();

  useNotificationNavigation(navigationRef);
  useDeepLinks(navigationRef);

  useEffect(() => {
    if (user?.uid) {
      registerForPushNotifications(user.uid);
      trackSession();
      // Prompt for review after a few sessions
      setTimeout(maybeRequestReview, 3000);
    }
  }, [user?.uid]);

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  const isLoggedIn     = !!user;
  const needsOnboarding = isLoggedIn && !profile?.onboardingComplete;

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false, ...headerTheme }}>
        {!isLoggedIn ? (
          <>
            <Stack.Screen name="Welcome"  component={WelcomeScreen} />
            <Stack.Screen name="Login"    component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} options={{ headerShown: true, title: 'Reset Password', headerStyle: { backgroundColor: colors.surface }, headerTintColor: colors.textPrimary }} />
          </>
        ) : needsOnboarding ? (
          <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        ) : (
          <>
            <Stack.Screen name="Main"          component={TabNavigator} />
            <Stack.Screen name="Chat"          component={ChatScreen}          options={{ headerShown: true, ...headerTheme }} />
            <Stack.Screen name="UserProfile"   component={UserProfileScreen}   options={{ headerShown: true, title: '', ...headerTheme }} />
            <Stack.Screen name="GroupDetail"   component={GroupDetailScreen}   options={{ headerShown: true, title: '', ...headerTheme }} />
            <Stack.Screen name="CreateGroup"   component={CreateGroupScreen}   />
            <Stack.Screen name="GroupAdmin"    component={GroupAdminScreen}    options={{ headerShown: true, title: 'Admin Panel', ...headerTheme }} />
            <Stack.Screen name="Bookmarks"     component={BookmarksScreen}     options={{ headerShown: true, title: 'Bookmarks', ...headerTheme }} />
            <Stack.Screen name="CreateStory"   component={CreateStoryScreen}   options={{ presentation: 'fullScreenModal' }} />
            <Stack.Screen name="PostAnalytics" component={PostAnalyticsScreen} options={{ headerShown: true, title: 'Analytics', ...headerTheme }} />
            <Stack.Screen name="Hashtag"       component={HashtagScreen}       options={({ route }) => ({ headerShown: true, title: `#${route.params?.tag}`, ...headerTheme })} />
            <Stack.Screen name="Settings"      component={SettingsScreen} />
            <Stack.Screen name="ChangePassword"      component={ChangePasswordScreen}      options={{ headerShown: true, title: 'Change Password',    ...headerTheme }} />
            <Stack.Screen name="ChangeUsername"      component={ChangeUsernameScreen}      options={{ headerShown: true, title: 'Change Username',    ...headerTheme }} />
            <Stack.Screen name="PrivacySettings"     component={PrivacySettingsScreen}     options={{ headerShown: true, title: 'Privacy',            ...headerTheme }} />
            <Stack.Screen name="NotificationSettings"component={NotificationSettingsScreen}options={{ headerShown: true, title: 'Notifications',      ...headerTheme }} />
            <Stack.Screen name="BlockedUsers"        component={BlockedUsersScreen}        options={{ headerShown: true, title: 'Blocked Users',      ...headerTheme }} />
            <Stack.Screen name="DeleteAccount"       component={DeleteAccountScreen}       options={{ headerShown: true, title: 'Delete Account',     ...headerTheme }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

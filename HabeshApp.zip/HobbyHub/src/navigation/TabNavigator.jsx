// src/navigation/TabNavigator.jsx — v3 with icon registry
import React, { useRef, useEffect } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { colors, typography, spacing, borderRadius } from '../theme';
import { TAB_ICONS } from '../theme/icons';

import FeedScreen     from '../screens/Main/FeedScreen';
import ExploreScreen  from '../screens/Main/ExploreScreen';
import ReelsScreen    from '../screens/Main/ReelsScreen';
import MessagesScreen from '../screens/Main/MessagesScreen';
import ProfileScreen  from '../screens/Main/ProfileScreen';

const Tab = createBottomTabNavigator();

const TABS = [
  { name: 'Feed',     label: 'Home',     icon: TAB_ICONS.feed     },
  { name: 'Explore',  label: 'Explore',  icon: TAB_ICONS.explore  },
  { name: 'Reels',    label: 'Reels',    icon: TAB_ICONS.reels    },
  { name: 'Messages', label: 'Messages', icon: TAB_ICONS.messages },
  { name: 'Profile',  label: 'Me',       icon: TAB_ICONS.profile  },
];

const TabButton = ({ item, focused, onPress }) => {
  const scale = useRef(new Animated.Value(1)).current;
  const glow  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scale, { toValue: focused ? 1.18 : 1, tension: 320, useNativeDriver: true }),
      Animated.timing(glow,  { toValue: focused ? 1 : 0, duration: 180, useNativeDriver: true }),
    ]).start();
  }, [focused]);

  return (
    <TouchableOpacity style={s.btn} onPress={onPress} activeOpacity={0.7}>
      {focused && <Animated.View style={[s.pill, { opacity: glow }]} />}
      <Animated.Text style={[s.icon, { transform: [{ scale }] }]}>{item.icon}</Animated.Text>
      <Text style={[s.label, focused && s.labelActive]}>{item.label}</Text>
    </TouchableOpacity>
  );
};

function CustomTabBar({ state, navigation }) {
  return (
    <View style={s.bar}>
      <View style={s.barBg} />
      {state.routes.map((route, i) => {
        const item = TABS.find((t) => t.name === route.name) || TABS[0];
        const focused = state.index === i;
        return (
          <TabButton
            key={route.key} item={item} focused={focused}
            onPress={() => { if (!focused) navigation.navigate(route.name); }}
          />
        );
      })}
    </View>
  );
}

export default function TabNavigator() {
  return (
    <Tab.Navigator tabBar={(p) => <CustomTabBar {...p} />} screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Feed"     component={FeedScreen}     />
      <Tab.Screen name="Explore"  component={ExploreScreen}  />
      <Tab.Screen name="Reels"    component={ReelsScreen}    />
      <Tab.Screen name="Messages" component={MessagesScreen} />
      <Tab.Screen name="Profile"  component={ProfileScreen}  />
    </Tab.Navigator>
  );
}

const s = StyleSheet.create({
  bar: {
    flexDirection: 'row', backgroundColor: colors.surface,
    borderTopWidth: 1, borderTopColor: colors.border,
    paddingBottom: 22, paddingTop: spacing.sm, paddingHorizontal: spacing.xs,
  },
  barBg: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(18,18,26,0.97)' },
  btn: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingVertical: spacing.sm, position: 'relative' },
  pill: { position: 'absolute', top: 0, bottom: 0, left: 6, right: 6, backgroundColor: colors.primaryGlow, borderRadius: borderRadius.lg },
  icon: { fontSize: 22 },
  label: { fontSize: 10, color: colors.textMuted, fontWeight: '500', letterSpacing: 0.2 },
  labelActive: { color: colors.primary, fontWeight: '800' },
});

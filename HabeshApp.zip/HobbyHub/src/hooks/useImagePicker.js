// src/hooks/useImagePicker.js
import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Platform } from 'react-native';

export const useImagePicker = () => {
  const [picking, setPicking] = useState(false);

  const requestPermission = async () => {
    if (Platform.OS !== 'web') {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission needed',
          'Please allow access to your photo library to upload images.',
        );
        return false;
      }
    }
    return true;
  };

  const pickImage = async (options = {}) => {
    const hasPermission = await requestPermission();
    if (!hasPermission) return null;

    setPicking(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: options.aspect || [1, 1],
        quality: options.quality || 0.8,
        ...options,
      });

      if (!result.canceled && result.assets?.length > 0) {
        return result.assets[0].uri;
      }
      return null;
    } finally {
      setPicking(false);
    }
  };

  const takePhoto = async (options = {}) => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow camera access.');
      return null;
    }

    setPicking(true);
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: options.aspect || [1, 1],
        quality: options.quality || 0.8,
        ...options,
      });

      if (!result.canceled && result.assets?.length > 0) {
        return result.assets[0].uri;
      }
      return null;
    } finally {
      setPicking(false);
    }
  };

  const showPickerOptions = () => {
    return new Promise((resolve) => {
      Alert.alert('Add Photo', 'Choose a source', [
        { text: 'Camera', onPress: async () => resolve(await takePhoto()) },
        { text: 'Photo Library', onPress: async () => resolve(await pickImage()) },
        { text: 'Cancel', style: 'cancel', onPress: () => resolve(null) },
      ]);
    });
  };

  return { pickImage, takePhoto, showPickerOptions, picking };
};


// src/components/AvatarUpload.jsx
import React, { useState } from 'react';
import {
  View, Text, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator,
} from 'react-native';
import { useImagePicker } from '../hooks/useImagePicker';
import { uploadAvatar } from '../firebase/storage';
import { updateUserProfile } from '../firebase/firestore';
import { updateProfile } from 'firebase/auth';
import { auth } from '../firebase/config';
import { colors, typography, borderRadius } from '../theme';

export const AvatarUpload = ({ user, profile, onUpdated, size = 80 }) => {
  const { showPickerOptions } = useImagePicker();
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleUpload = async () => {
    const uri = await showPickerOptions();
    if (!uri) return;

    setUploading(true);
    setProgress(0);
    try {
      const downloadURL = await uploadAvatar(user.uid, uri, setProgress);
      await updateUserProfile(user.uid, { photoURL: downloadURL });
      await updateProfile(auth.currentUser, { photoURL: downloadURL });
      onUpdated?.(downloadURL);
    } catch (e) {
      console.error('Avatar upload failed:', e);
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const initials = profile?.displayName?.[0]?.toUpperCase() || '?';
  const photoURL = profile?.photoURL;

  return (
    <TouchableOpacity
      onPress={handleUpload}
      disabled={uploading}
      activeOpacity={0.8}
      style={[styles.wrap, { width: size, height: size, borderRadius: size / 2 }]}
    >
      {photoURL ? (
        <Image
          source={{ uri: photoURL }}
          style={{ width: size, height: size, borderRadius: size / 2 }}
        />
      ) : (
        <View style={[styles.placeholder, { width: size, height: size, borderRadius: size / 2 }]}>
          <Text style={[styles.initials, { fontSize: size * 0.35 }]}>{initials}</Text>
        </View>
      )}

      {uploading ? (
        <View style={styles.overlay}>
          <ActivityIndicator color="#fff" size="small" />
          <Text style={styles.progressText}>{progress}%</Text>
        </View>
      ) : (
        <View style={styles.editBadge}>
          <Text style={styles.editIcon}>📷</Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  wrap: { position: 'relative' },
  placeholder: {
    backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  initials: { color: '#fff', fontWeight: '700' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
    borderRadius: 999,
    justifyContent: 'center', alignItems: 'center',
    gap: 2,
  },
  progressText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  editBadge: {
    position: 'absolute', bottom: 0, right: 0,
    width: 26, height: 26, borderRadius: 13,
    backgroundColor: colors.surface,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: colors.background,
  },
  editIcon: { fontSize: 12 },
});

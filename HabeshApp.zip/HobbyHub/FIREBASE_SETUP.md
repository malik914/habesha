# Habesha — Complete Firebase Setup Guide
## Step-by-step from zero to deployed

---

## Step 1 — Create Firebase Project

1. Go to **https://console.firebase.google.com**
2. Click **"Create a project"**
3. Name it: `habesha` (or your preferred name)
4. Enable Google Analytics → yes (free, useful)
5. Wait for project creation (~30 seconds)

---

## Step 2 — Enable Firebase Services

### Authentication
1. Left sidebar → **Authentication** → **Get started**
2. **Sign-in method** tab → Enable:
   - ✅ Email/Password
   - ✅ Google (optional — requires OAuth setup)
   - ✅ Apple (optional — requires Apple Developer account)

### Firestore Database
1. Left sidebar → **Firestore Database** → **Create database**
2. Choose **"Start in production mode"** (our rules handle security)
3. Location: choose closest to your users (e.g. `us-central1`, `europe-west1`)
4. Click **Enable**

### Firebase Storage
1. Left sidebar → **Storage** → **Get started**
2. Choose **"Start in production mode"**
3. Same location as Firestore
4. Click **Done**

### Cloud Messaging (FCM)
1. Left sidebar → **Project Settings** → **Cloud Messaging** tab
2. FCM is enabled by default — no action needed
3. Note your **Server key** (needed for manual push sends if not using Cloud Functions)

---

## Step 3 — Get Your App Credentials

### 3.1 Web/React Native credentials
1. **Project Settings** → **General** tab → scroll to **"Your apps"**
2. Click **"Add app"** → choose **Web** (⚛️ React Native uses the web SDK)
3. App nickname: `Habesha RN`
4. **Don't** check "Firebase Hosting" (unless you want it)
5. Click **Register app**
6. Copy the `firebaseConfig` object — paste into `src/firebase/config.js`:

```javascript
// src/firebase/config.js
const firebaseConfig = {
  apiKey:            "AIzaSy...",         // ← paste here
  authDomain:        "habesha.firebaseapp.com",
  projectId:         "habesha",
  storageBucket:     "habesha.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123456789:web:abc123",
};
```

### 3.2 Android credentials
1. **Project Settings** → **Add app** → choose **Android**
2. Android package name: `com.yourname.habesha` (match your app.json)
3. Download `google-services.json`
4. Place at: `android/app/google-services.json`

### 3.3 iOS credentials
1. **Project Settings** → **Add app** → choose **iOS**
2. iOS bundle ID: `com.yourname.habesha` (match your app.json)
3. Download `GoogleService-Info.plist`
4. Place at: `ios/GoogleService-Info.plist`

---

## Step 4 — Deploy Security Rules & Indexes

### Install Firebase CLI
```bash
npm install -g firebase-tools
firebase login
```

### Link your project
```bash
# In your Habesha root directory
firebase use YOUR_PROJECT_ID
# or
firebase use --add  # interactive selector
```

### Update .firebaserc
```json
{
  "projects": {
    "default": "YOUR_PROJECT_ID"  ← replace this
  }
}
```

### Deploy rules and indexes
```bash
# Deploy everything at once
firebase deploy --only firestore:rules,firestore:indexes,storage

# Or individually
firebase deploy --only firestore:rules
firebase deploy --only firestore:indexes
firebase deploy --only storage
```

⚠️ **Indexes take 5–15 minutes to build** after deployment. Your app will throw errors on compound queries until they're ready. Check status at:
**Firebase Console → Firestore → Indexes** tab

---

## Step 5 — Deploy Cloud Functions

```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

This deploys:
- `onNotificationCreated` — sends push when notifications are created
- `onMessageCreated` — sends push for direct messages
- `grantVerifiedBadge` — admin-only callable to grant ✅ badges
- `cleanupExpiredStories` — runs hourly, deletes 24h-old stories
- `cleanupOldNotifications` — daily, removes 30-day-old notifications
- `updateHashtagTrending` — daily, recalculates trending hashtag scores
- `onReportCreated` — auto-flags content with 3+ reports
- `onPostEngagement` — updates author total likes count
- `onUserDeleted` — cleans up storage when account is deleted

---

## Step 6 — Seed Initial Data

```bash
# Get your service account key:
# Firebase Console → Project Settings → Service Accounts → Generate new private key
# Save as: scripts/service-account-key.json  (NEVER commit this to git!)

cd scripts
npm install firebase-admin
node seed.js
```

This creates:
- 30 interest groups (photography, gaming, cooking, etc.)
- 10 sample posts to make the app feel alive
- 12 trending hashtags
- The @habesha system account

---

## Step 7 — Update Expo Project ID

1. Create account at **https://expo.dev** (free)
2. Create a new project or find your existing one
3. Note your **Project ID** (looks like `abc12345-1234-...`)
4. Update in `src/firebase/messaging.js`:

```javascript
const tokenData = await Notifications.getExpoPushTokenAsync({
  projectId: 'YOUR_EXPO_PROJECT_ID',  // ← paste here
});
```

Also update `app.json`:
```json
{
  "expo": {
    "name": "Habesha",
    "slug": "habesha",
    "extra": {
      "eas": {
        "projectId": "YOUR_EXPO_PROJECT_ID"
      }
    }
  }
}
```

---

## Step 8 — Configure RevenueCat (Payments)

1. Create account at **https://app.revenuecat.com** (free tier available)
2. Create a new project → Add app (iOS + Android)
3. Connect your App Store Connect and Google Play accounts
4. Create **Entitlement**: `premium`
5. Create **Products** in App Store Connect and Google Play console
6. Add products to RevenueCat
7. Get your API keys → update `src/payments/RevenueCat.js`:

```javascript
const API_KEYS = {
  ios:     'appl_YOUR_IOS_KEY',      // ← paste here
  android: 'goog_YOUR_ANDROID_KEY',  // ← paste here
};
```

---

## Step 9 — Test the Full Setup

```bash
# Start the app
npx expo start

# In another terminal, watch Firebase emulator logs
firebase emulators:start --only firestore,auth,storage
```

**Checklist:**
- [ ] Register a new account
- [ ] Go through onboarding (username + interests)
- [ ] Feed loads without errors
- [ ] Can create a post
- [ ] Notifications appear when someone likes
- [ ] Messages send and receive in real-time
- [ ] Stories upload and expire
- [ ] Settings all work

---

## Step 10 — Monitor in Production

### Firebase Console dashboards to watch:
- **Authentication** → user signups over time
- **Firestore** → read/write counts (watch free tier limits)
- **Storage** → storage used
- **Functions** → execution counts and errors
- **Crashlytics** → install `expo-firebase-crashlytics` for crash reporting

### Free tier limits (Spark plan):
| Service | Free Limit | Action at limit |
|---------|-----------|-----------------|
| Firestore reads | 50K/day | Upgrade to Blaze |
| Firestore writes | 20K/day | Upgrade to Blaze |
| Storage | 5GB total | Upgrade to Blaze |
| Functions | 2M calls/month | Upgrade to Blaze |
| Auth | Unlimited | Never hits limit |

**Upgrade to Blaze (pay-as-you-go) only when needed. Typical cost at 1,000 DAU: $5–15/month.**

---

## Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `Missing or insufficient permissions` | Security rules not deployed — run `firebase deploy --only firestore:rules` |
| `The query requires an index` | Indexes not built yet — wait 10 min after `firebase deploy --only firestore:indexes` |
| `Firebase: Error (auth/configuration-not-found)` | Wrong credentials in `config.js` — double check your `firebaseConfig` |
| `Push notifications not working` | Check `expoPushToken` is being saved to Firestore, check Functions logs |
| `Storage upload fails` | Storage rules not deployed — run `firebase deploy --only storage` |
| `Functions deploy fails` | Run `cd functions && npm install` first |

---

## Quick Deploy Reference

```bash
# Deploy everything
firebase deploy

# Deploy specific parts
firebase deploy --only firestore:rules
firebase deploy --only firestore:indexes
firebase deploy --only storage
firebase deploy --only functions
firebase deploy --only hosting

# Watch function logs
firebase functions:log --follow

# Open Firebase console for this project
firebase open
```
